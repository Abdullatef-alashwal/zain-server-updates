// server-supabase.js
const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');
const { createClient } = require('@supabase/supabase-js');
const os = require('os');
const crypto = require('crypto');

const { promisify } = require('util');
const execAsync = promisify(exec);
// ===== حل دعم WebSocket =====
try {
    const WebSocket = require('ws');
    global.WebSocket = WebSocket;
    // console.log('✅ WebSocket تم توفيره يدوياً');
} catch (e) {
    console.warn('⚠️ WebSocket غير متاح');
}

const SUPABASE_URL = 'https://thlxbogpanvklcwsqert.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRobHhib2dwYW52a2xjd3NxZXJ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ4NzIyMzYsImV4cCI6MjA5MDQ0ODIzNn0.MHij6tO9tdZdTGk3JoMNvXrZB9F3gpveH7Gd3hHuZm8';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
// console.log('✅ Data Base Is Cinnected Ok');

// ... باقي الكود (دالة getMotherboardSerial وغيرها)

// ============================================
// ===== الحصول على سريال الماذربورد =====
// ============================================




async function getMotherboardSerial() {
    try {
        // ✅ الطريقة الأولى: PowerShell (يعمل على Windows 10/11)
        try {
            const { stdout } = await execAsync(
                'powershell -Command "Get-CimInstance -ClassName Win32_BaseBoard | Select-Object -ExpandProperty SerialNumber"',
                { timeout: 5000 }
            );
            
            let serial = stdout.trim();
            if (serial && serial.length > 0 && 
                serial !== 'To be filled by O.E.M.' && 
                serial !== 'SerialNumber' && 
                !serial.includes(' ')) {
                // console.log(`✅ سريال اللوحة الأم: ${serial}`);
                return serial;
            }
        } catch (error) {
            // console.log('⚠️ فشل PowerShell (Get-CimInstance):', error.message);
        }

        // ✅ الطريقة الثانية: WMIC (للإصدارات القديمة)
        try {
            const { stdout } = await execAsync('wmic baseboard get serialnumber', { timeout: 5000 });
            const lines = stdout.trim().split('\n');
            if (lines.length > 1) {
                const serial = lines[1].trim();
                if (serial && serial.length > 0 && 
                    serial !== 'To be filled by O.E.M.' && 
                    serial !== 'SerialNumber') {
                    // console.log(`✅ سريال اللوحة الأم (WMIC): ${serial}`);
                    return serial;
                }
            }
        } catch (error) {
            // console.log('⚠️ فشل WMIC:', error.message);
        }

        // ✅ الطريقة الثالثة: إنشاء معرف فريد من Hostname + MAC + Platform
        try {
            const networkInterfaces = os.networkInterfaces();
            let macAddress = '';
            
            // الحصول على أول MAC address غير داخلي
            for (const interfaceName in networkInterfaces) {
                const interfaces = networkInterfaces[interfaceName];
                for (const iface of interfaces) {
                    if (!iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
                        macAddress = iface.mac;
                        break;
                    }
                }
                if (macAddress) break;
            }
            
            const hostname = os.hostname();
            const platform = os.platform();
            const uniqueString = `${hostname}_${macAddress}_${platform}`;
            const hash = crypto.createHash('sha256').update(uniqueString).digest('hex');
            const uniqueId = hash.substring(0, 16).toUpperCase();
            
            // console.log(`✅ المعرف الفريد (بديل): ${uniqueId}`);
            return uniqueId;
            
        } catch (error) {
            // console.log('⚠️ فشل إنشاء المعرف الفريد:', error.message);
        }

        // ✅ الطريقة الرابعة: استخدام Hostname + Timestamp
        try {
            const hostname = os.hostname();
            const timestamp = Date.now().toString(36).toUpperCase();
            const uniqueId = `HOST_${hostname}_${timestamp}`;
            // console.log(`✅ المعرف المؤقت: ${uniqueId}`);
            return uniqueId;
        } catch (error) {
            // console.log('⚠️ فشل إنشاء المعرف المؤقت:', error.message);
        }

        // 🚨 الحل الأخير
        console.error('❌ فشل جميع الطرق، استخدام معرف عشوائي');
        return `NODE_${Date.now().toString(36).toUpperCase()}`;
        
    } catch (error) {
        console.error('❌ خطأ في الحصول على السريال:', error);
        return `ERROR_${Date.now().toString(36).toUpperCase()}`;
    }
}

// تصدير الدالة



// ============================================
// ===== 1. التحقق من وجود الاستراحة =====
// ============================================

async function checkBreakExists(serial) {
    try {
      //  // console.log('🔍 التحقق من وجود الاستراحة للسريال:', serial);
        
        if (!serial) {
          //  // console.log('⚠️ السريال فارغ');
            return { exists: false };
        }

        const { data, error } = await supabase
            .from('break')
            .select('id, name_break, phone_num, bay, name, password')
            .eq('serial_motherboard', serial)
            .maybeSingle();

        if (error) {
            console.error('❌ خطأ في التحقق:', error);
            return { exists: false, error: error.message };
        }

        if (data) {
           // // console.log('✅ تم العثور على الاستراحة:', data.id);
            return { exists: true, breakData: data };
        }

     //   // console.log('ℹ️ لا توجد استراحة مسجلة لهذا الجهاز');
        return { exists: false };
    } catch (error) {
        console.error('❌ خطأ في التحقق من وجود الاستراحة:', error);
        return { exists: false, error: error.message };
    }
}

// ============================================
// ===== 2. إنشاء استراحة جديدة =====
// ============================================

async function createBreak(breakData) {
    try {
      //  // console.log('📝 إنشاء استراحة جديدة:', breakData);
        
        const insertData = {
            name_break: breakData.name_break || 'استراحة',
            phone_num: breakData.phone_num || '',
            serial_motherboard: breakData.serial_motherboard || 'UNKNOWN',
            bay: false,
            info: breakData.info || '',
            name: breakData.name || 'admin',
            password: breakData.password || 'admin123'
        };

      //  // console.log('📝 بيانات الإدراج:', insertData);

        const { data, error } = await supabase
            .from('break')
            .insert(insertData)
            .select()
            .single();

        if (error) {
            console.error('❌ خطأ في إنشاء الاستراحة (Supabase):', error);
            return { success: false, error: error.message };
        }

       // // console.log('✅ تم إنشاء الاستراحة:', data);
        return { success: true, breakData: data };
    } catch (error) {
        console.error('❌ خطأ في إنشاء الاستراحة:', error);
        return { success: false, error: error.message };
    }
}

// ===== 3. التحقق من صحة المفتاح =====
async function checkLicenseKey(key) {
    try {
      // // console.log('🔍 التحقق من المفتاح:', key);
        
        if (!key || key.trim() === '') {
            return { valid: false, error: 'المفتاح فارغ' };
        }
        
        const cleanKey = key.trim();
        
        // البحث عن المفتاح
        const { data: keyData, error: keyError } = await supabase
            .from('keys')
            .select('*')
            .eq('key', cleanKey);

        if (keyError) {
            console.error('❌ خطأ في البحث عن المفتاح:', keyError);
            return { valid: false, error: 'خطأ في قاعدة البيانات: ' + keyError.message };
        }

        if (!keyData || keyData.length === 0) {
          //  // console.log('❌ المفتاح غير موجود');
            return { valid: false, error: 'المفتاح غير موجود' };
        }

        const keyRecord = keyData[0];
       // // console.log('✅ تم العثور على المفتاح:', keyRecord.id);
       // // console.log('📅 تاريخ الانتهاء:', keyRecord.exp_date);
      //  // console.log('✅ حالة التفعيل:', keyRecord.active);

        // التحقق من أن المفتاح مفعل
        if (!keyRecord.active) {
          //  // console.log('❌ المفتاح غير مفعل');
            return { valid: false, error: 'المفتاح غير مفعل' };
        }

        // التحقق من تاريخ الانتهاء
        const today = new Date();
        const expDate = new Date(keyRecord.exp_date);
        today.setHours(0, 0, 0, 0);
        expDate.setHours(0, 0, 0, 0);
        
        if (expDate < today) {
         //   // console.log('❌ المفتاح منتهي الصلاحية');
            return { valid: false, error: 'انتهت صلاحية المفتاح' };
        }

        // التحقق من أن المفتاح غير مستخدم من قبل
        const { data: activeData, error: activeError } = await supabase
            .from('break_active')
            .select('*')
            .eq('sub_id_key', keyRecord.id);

        if (activeError) {
            console.error('❌ خطأ في التحقق من الاستخدام:', activeError);
            return { valid: false, error: 'خطأ في التحقق' };
        }

        if (activeData && activeData.length > 0) {
           // // console.log('❌ المفتاح مستخدم بالفعل');
            return { valid: false, error: 'المفتاح مستخدم بالفعل' };
        }

        //// console.log('✅ المفتاح صالح');
        return { 
            valid: true, 
            keyData: keyRecord
        };
    } catch (error) {
        console.error('❌ خطأ في التحقق من المفتاح:', error);
        return { valid: false, error: 'خطأ في التحقق: ' + error.message };
    }
}

// ============================================
// ===== 4. ربط المفتاح بالاستراحة =====
// ============================================

async function linkKeyToBreak(breakId, keyId) {
    try {
       // // console.log('🔗 ربط المفتاح بالاستراحة:', { breakId, keyId });
        
        const { error } = await supabase
            .from('break_active')
            .insert({
                sub_id_name_break: breakId,
                sub_id_key: keyId
            });

        if (error) {
            console.error('❌ خطأ في ربط المفتاح:', error);
            return { success: false, error: error.message };
        }

       // // console.log('✅ تم ربط المفتاح بنجاح');
        return { success: true };
    } catch (error) {
        console.error('❌ خطأ في ربط المفتاح:', error);
        return { success: false, error: error.message };
    }
}

// ============================================
// ===== 5. التحقق من صلاحية الاستراحة =====
// ============================================

async function checkBreakLicense(breakId) {
    try {
      //  // console.log('🔍 التحقق من صلاحية الاستراحة:', breakId);
        
        const { data: activeData, error: activeError } = await supabase
            .from('break_active')
            .select('sub_id_key')
            .eq('sub_id_name_break', breakId)
            .maybeSingle();

        if (activeError || !activeData) {
         //   // console.log('❌ لا يوجد مفتاح مرتبط');
            return { 
                valid: false, 
                error: 'لا يوجد مفتاح مرتبط',
                message: '❌ هذه الاستراحة غير مفعلة'
            };
        }

        const { data: keyData, error: keyError } = await supabase
            .from('keys')
            .select('*')
            .eq('id', activeData.sub_id_key)
            .maybeSingle();

        if (keyError || !keyData) {
          //  // console.log('❌ المفتاح غير موجود');
            return { 
                valid: false, 
                error: 'المفتاح غير موجود',
                message: '❌ المفتاح غير موجود'
            };
        }

        const today = new Date();
        const expDate = new Date(keyData.exp_date);
        today.setHours(0, 0, 0, 0);
        expDate.setHours(0, 0, 0, 0);
        
        const diffTime = expDate - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (!keyData.active) {
            return { 
                valid: false, 
                error: 'المفتاح غير مفعل',
                message: '❌ المفتاح غير مفعل',
                daysRemaining: diffDays
            };
        }

        if (expDate < today) {
            return { 
                valid: false, 
                error: 'انتهت الصلاحية',
                message: `❌ انتهت الصلاحية منذ ${Math.abs(diffDays)} يوم`,
                daysRemaining: diffDays,
                expired: true,
                expDate: expDate
            };
        }

        return {
            valid: true,
            message: keyData.message || `✅ صلاحية سارية (${diffDays} يوم متبقي)`,
            daysRemaining: diffDays,
            keyData: keyData,
            expDate: expDate
        };

    } catch (error) {
        console.error('❌ خطأ في التحقق من الصلاحية:', error);
        return { 
            valid: false, 
            error: error.message,
            message: '❌ خطأ في التحقق من الصلاحية'
        };
    }
}


// ============================================
// ===== 6. تحديث المفتاح =====
// ============================================

async function updateBreakKey(breakId, newKey) {
    try {
       // // console.log('🔄 تحديث المفتاح للاستراحة:', breakId);
      //  // console.log('🔑 المفتاح الجديد:', newKey);
        
        if (!breakId) {
            return { success: false, error: 'معرف الاستراحة مطلوب' };
        }
        
        if (!newKey) {
            return { success: false, error: 'المفتاح الجديد مطلوب' };
        }
        
        const keyCheck = await checkLicenseKey(newKey);
       // // console.log('🔍 نتيجة التحقق من المفتاح:', keyCheck);
        
        if (!keyCheck.valid) {
            return { success: false, error: keyCheck.error || 'المفتاح غير صالح' };
        }

        // حذف المفتاح القديم
        const { error: deleteError } = await supabase
            .from('break_active')
            .delete()
            .eq('sub_id_name_break', breakId);

        if (deleteError) {
            console.error('❌ خطأ في حذف المفتاح القديم:', deleteError);
            return { success: false, error: 'فشل حذف المفتاح القديم: ' + deleteError.message };
        }

        // إضافة المفتاح الجديد
        const { error: insertError } = await supabase
            .from('break_active')
            .insert({
                sub_id_name_break: breakId,
                sub_id_key: keyCheck.keyData.id
            });

        if (insertError) {
            console.error('❌ خطأ في إضافة المفتاح الجديد:', insertError);
            return { success: false, error: 'فشل إضافة المفتاح الجديد: ' + insertError.message };
        }

       // // console.log('✅ تم تحديث المفتاح بنجاح');
        return { 
            success: true, 
            keyData: keyCheck.keyData,
            message: `✅ تم تحديث المفتاح بنجاح - صلاحية حتى ${new Date(keyCheck.keyData.exp_date).toLocaleDateString('ar-EG')}`
        };

    } catch (error) {
        console.error('❌ خطأ في تحديث المفتاح:', error);
        return { success: false, error: error.message };
    }
}

// ============================================
// ===== 7. إنشاء مفتاح جديد =====
// ============================================

async function createNewKey(keyData) {
    try {
       // // console.log('🔄 إنشاء مفتاح جديد:', keyData);
        
        const { data, error } = await supabase
            .from('keys')
            .insert({
                key: keyData.key,
                start_date: keyData.start_date,
                exp_date: keyData.exp_date,
                active: true,
                message: keyData.message || ''
            })
            .select()
            .single();

        if (error) {
            console.error('❌ خطأ في إنشاء المفتاح:', error);
            return { success: false, error: error.message };
        }

      //  // console.log('✅ تم إنشاء المفتاح:', data);
        return { success: true, keyData: data };
    } catch (error) {
        console.error('❌ خطأ في إنشاء المفتاح:', error);
        return { success: false, error: error.message };
    }
}

// ============================================
// ===== تصدير الدوال =====
// ============================================

module.exports = {
    supabase,
    getMotherboardSerial,
    checkBreakExists,
    createBreak,
    checkLicenseKey,
    linkKeyToBreak,
    checkBreakLicense,
    updateBreakKey,  // ✅ تأكد من وجود هذا
    createNewKey
};


// ============================================
// ===== تشغيل سيرفر التحقق (اختياري) =====
// ============================================

if (require.main === module) {
    app.use(cors());
    app.use(express.json());

    // ===== API: التحقق من حالة النظام =====
    app.get('/api/system/status', async (req, res) => {
        try {
            const serial = await getMotherboardSerial();
            const check = await checkBreakExists(serial);

            if (check.exists) {
                const license = await checkBreakLicense(check.breakData.id);
                res.json({
                    success: true,
                    status: 'existing',
                    breakData: check.breakData,
                    license: license,
                    serial: serial
                });
            } else {
                res.json({
                    success: true,
                    status: 'new',
                    serial: serial,
                    message: 'جهاز جديد - يرجى التسجيل'
                });
            }
        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    });

    // ===== API: تسجيل استراحة جديدة =====
    app.post('/api/system/register', async (req, res) => {
        try {
            const { name_break, phone_num, info, name, password, licenseKey } = req.body;

            if (!phone_num || !licenseKey) {
                return res.status(400).json({
                    success: false,
                    error: 'رقم الهاتف ومفتاح الترخيص مطلوبان'
                });
            }

            // 1. التحقق من المفتاح
            const keyCheck = await checkLicenseKey(licenseKey);
            if (!keyCheck.valid) {
                return res.status(400).json({ success: false, error: keyCheck.error });
            }

            // 2. الحصول على سريال الماذربورد
            const serial = await getMotherboardSerial();

            // 3. التحقق من عدم تسجيل الجهاز
            const check = await checkBreakExists(serial);
            if (check.exists) {
                return res.status(400).json({
                    success: false,
                    error: 'هذا الجهاز مسجل بالفعل'
                });
            }

            // 4. إنشاء الاستراحة
            const breakResult = await createBreak({
                name_break: name_break || 'استراحة',
                phone_num: phone_num,
                serial_motherboard: serial,
                info: info || '',
                name: name || 'admin',
                password: password || 'admin123'
            });

            if (!breakResult.success) {
                return res.status(500).json({ success: false, error: breakResult.error });
            }

            // 5. ربط المفتاح بالاستراحة
            const linkResult = await linkKeyToBreak(breakResult.breakData.id, keyCheck.keyData.id);
            if (!linkResult.success) {
                return res.status(500).json({ success: false, error: linkResult.error });
            }

            res.json({
                success: true,
                message: '✅ تم تسجيل الاستراحة بنجاح',
                breakData: breakResult.breakData,
                keyData: keyCheck.keyData
            });

        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    });

    // ===== API: تحديث المفتاح =====
    app.post('/api/system/update-key', async (req, res) => {
        try {
            const { licenseKey } = req.body;

            if (!licenseKey) {
                return res.status(400).json({
                    success: false,
                    error: 'مفتاح الترخيص مطلوب'
                });
            }

            const serial = await getMotherboardSerial();
            const check = await checkBreakExists(serial);

            if (!check.exists) {
                return res.status(404).json({
                    success: false,
                    error: 'الجهاز غير مسجل'
                });
            }

            const result = await updateBreakKey(check.breakData.id, licenseKey);

            if (!result.success) {
                return res.status(400).json({ success: false, error: result.error });
            }

            res.json({
                success: true,
                message: result.message,
                keyData: result.keyData
            });

        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    });

    // ===== API: معلومات الصلاحية =====
    app.get('/api/system/license-info', async (req, res) => {
        try {
            const serial = await getMotherboardSerial();
            const check = await checkBreakExists(serial);

            if (!check.exists) {
                return res.json({
                    success: true,
                    exists: false,
                    message: 'الجهاز غير مسجل'
                });
            }

            const license = await checkBreakLicense(check.breakData.id);

            res.json({
                success: true,
                exists: true,
                breakData: check.breakData,
                license: license
            });

        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    });

    // ===== API: إنشاء مفتاح جديد (للمدير) =====
    app.post('/api/system/keys/create', async (req, res) => {
        try {
            const { key, start_date, exp_date, message } = req.body;

            if (!key || !start_date || !exp_date) {
                return res.status(400).json({
                    success: false,
                    error: 'المفتاح وتاريخ البدء وتاريخ الانتهاء مطلوبون'
                });
            }

            const result = await createNewKey({
                key: key,
                start_date: start_date,
                exp_date: exp_date,
                message: message || ''
            });

            if (!result.success) {
                return res.status(400).json({ success: false, error: result.error });
            }

            res.json({
                success: true,
                message: '✅ تم إنشاء المفتاح بنجاح',
                key: result.keyData
            });

        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    });
// ===== 2. إنشاء استراحة جديدة =====
async function createBreak(breakData) {
    try {
        const { data, error } = await supabase
            .from('break')
            .insert({
                name_break: breakData.name_break || 'استراحة',
                phone_num: breakData.phone_num,
                serial_motherboard: breakData.serial_motherboard,
                bay: false,
                info: breakData.info || '',
                name: breakData.name || 'admin',
                password: breakData.password || 'admin123'
            })
            .select()
            .single();

        if (error) {
            console.error('❌ خطأ في إنشاء الاستراحة:', error);
            return { success: false, error: error.message };
        }

      //  // console.log('✅ تم إنشاء الاستراحة:', data.id);
        return { success: true, breakData: data };
    } catch (error) {
        console.error('❌ خطأ في إنشاء الاستراحة:', error);
        return { success: false, error: error.message };
    }
}
    const PORT = 3001;
    app.listen(PORT, () => {
        // console.log(`\n🔐 نظام التحقق يعمل على: http://localhost:${PORT}`);
        // console.log('\n📡 نقاط API:');
        // console.log('   GET  /api/system/status');
        // console.log('   POST /api/system/register');
        // console.log('   POST /api/system/update-key');
        // console.log('   GET  /api/system/license-info');
        // console.log('   POST /api/system/keys/create');
        // console.log('\n🔑 استخدم المفتاح التجريبي: DEMO-2026-TEST-KEY-001\n');
    });
}