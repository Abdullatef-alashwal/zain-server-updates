// ============================================
// ===== استيراد المكتبات =====
// ============================================

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const mime = require('mime-types');
const axios = require('axios');
const { Worker } = require('worker_threads');
const { createReadStream } = require('fs');
const { spawn } = require('child_process');
// ============================================
// ===== تعريف المتغيرات الأساسية =====
// ============================================

const app = express();
const EXEC_DIR = path.dirname(process.execPath);
const DATA_DIR = path.join(EXEC_DIR, 'data');
const PUBLIC_DIR = path.join(process.cwd(), 'public');
const BASE_DIR = process.cwd();
const SUPABASE_TIMEOUT = 5000;
// ===== كاش صور المجلدات مع فهرس سريع =====
let folderImagesCache = {};
let folderImagesIndex = new Map(); // اسم المجلد → المسار الكامل
let folderImagesCacheLoaded = false;
let folderImagesCacheTimestamp = 0;
let viewsWriteLock = false;
const FOLDER_CACHE_TTL = 5 * 60 * 1000; // 5 دقائق
// ============================================
// ===== إعدادات التحديث المتقدمة =====
// ============================================
const UPDATE_CONFIG_FILE = getDataPath('update_config.json');
const UPDATE_CACHE_FILE = getDataPath('update_cache.json');
const NOTIFICATIONS_CACHE_FILE = getDataPath('notifications_cache.json');

// مسارات التحديث
const SETUP_DIR = path.dirname(process.execPath);
const UPDATES_DIR = path.join(SETUP_DIR, 'updates');
const CACHE_DIR = path.join(SETUP_DIR, 'cache');
const LAUNCHER_EXE = path.join(SETUP_DIR, 'launcher.exe');


const DEFAULT_UPDATE_CONFIG = {
  updateServerUrl: 'https://your-update-server.com/api',
  currentVersion: '1.0.0',
  
  // ===== الفحص =====
  autoCheck: true,
  checkInterval: 3600000, // كل ساعة
  
  // ===== التنزيل =====
  autoDownload: false,
  
  // ===== التثبيت =====
  autoInstall: false,
  installDelay: 5000, // تأخير قبل التثبيت (مللي)
  
  // ===== إعادة التشغيل =====
  autoRestart: false,
  restartDelay: 3000,
  
  // ===== الجدولة =====
  scheduledUpdates: {
    enabled: false,
    days: [0, 1, 2, 3, 4, 5, 6], // 0=الأحد ... 6=السبت
    timeStart: '03:00', // وقت البدء
    timeEnd: '05:00'    // وقت الانتهاء
  },
  
  // ===== الإشعارات =====
  notifications: {
    enabled: true,
    sound: true,
    desktop: true,
    showBadge: true,
    showToast: true,
    notifyOnNewVersion: true,
    notifyOnDownloadComplete: true,
    notifyOnInstallComplete: true
  },
  
  // ===== التراجع =====
  autoBackupBeforeUpdate: true,
  keepBackups: 3, // عدد النسخ الاحتياطية المحفوظة
  
  // ===== متقدم =====
  skipVersions: [],
  onlyStableReleases: true, // تجاهل الإصدارات التجريبية
  bandwidthLimit: 0, // حد سرعة التنزيل (0 = غير محدود)
  lastCheck: null,
  lastUpdate: null
};

let updateConfig = loadUpdateConfig();
let updateCheckInterval = null;
let availableUpdate = null;
let isDownloading = false;
let downloadProgress = 0;
let isInstalling = false;
let installProgress = 0;
let autoUpdateTimer = null;
let restartTimer = null;
// ============================================
// ===== إعدادات التحديث - الدوال المفقودة =====
// ============================================



// عملاء الإشعارات (SSE)
const notificationClients = new Set();




// ============================================
// ===== نظام تحويل الفيديو =====
// ============================================

const CONVERTIBLE_EXTS = ['.avi', '.mkv', '.mov', '.wmv', '.flv', '.mpeg', '.mpg'];
let convertState = {
  status: 'idle',
  queue: [],
  currentIndex: 0,
  currentFile: null,
  completed: 0,
  failed: 0,
  total: 0,
  results: [],
  cancelRequested: false,
  process: null
};
const VIDEO_EXTENSIONS = [
'.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm',
'.m4v', '.mpg', '.mpeg', '.3gp', '.ogv', '.ts', '.mts',
'.m2ts', '.vob', '.divx', '.xvid', '.mp4v', '.m4p', '.m4b'];


const IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg', '.tiff', '.ico'];
const AUDIO_EXTENSIONS = ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a', '.wma', '.opus'];

const FILE_TYPES = {
  video: {
    extensions: ['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v', '.mpg', '.mpeg', '.3gp', '.ogv', '.ts', '.mts', '.m2ts', '.vob', '.divx', '.xvid'],
    icon: '🎬',
    name: 'فيديو'
  },
  audio: {
    extensions: ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a', '.wma', '.opus', '.webm'],
    icon: '🎵',
    name: 'صوت'
  },
  image: {
    extensions: ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg', '.tiff', '.ico'],
    icon: '🖼️',
    name: 'صورة'
  },
  all: {
    extensions: [],
    icon: '📋',
    name: 'الكل'
  }
};
// ============================================
// ===== دالة الحصول على مسار الملف (تعمل مع pkg) =====
// ============================================

function getDataPath(filename) {try {
    // في بيئة pkg، نستخدم مساراً قابلاً للكتابة
    if (process.pkg) {
      // استخدام مجلد البيانات في نفس مكان الملف التنفيذي
      const exeDir = path.dirname(process.execPath);
      const dataDir = path.join(exeDir, 'data');

      // إنشاء مجلد البيانات إذا لم يكن موجوداً
      if (!fs.existsSync(dataDir)) {
        try {fs.mkdirSync(dataDir, { recursive: true });} catch (e) {}
      }

      return path.join(dataDir, filename);
    }

    // في بيئة التطوير، استخدم المسار الحالي
    return path.join(__dirname, filename);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}
// ============================================
// ===== استيراد دوال Supabase =====
// ============================================

const {
  supabase,
  getMotherboardSerial,
  checkBreakExists,
  checkBreakLicense,
  updateBreakKey,
  createBreak,
  checkLicenseKey,
  linkKeyToBreak
} = require('./server-supabase');

// ============================================
// ===== متغيرات التحقق والترخيص =====
// ============================================

let licenseValid = false;
let licenseCheckResult = null;
let serverShuttingDown = false;
let cachedTime = null;
let cachedTimeTimestamp = 0;
const TIME_CACHE_DURATION = 600000;

let serverLocked = false;
let licenseCheckInterval = null;
const LICENSE_CHECK_INTERVAL = 50000;

// ============================================
// ===== متغيرات إعادة التحقق عند عودة الإنترنت =====
// ============================================

let reconnectAttempts = 0;
let maxReconnectAttempts = 10;
let reconnectInterval = null;
let isCheckingConnectivity = false;
let lastSuccessfulCheck = null;
const CONNECTIVITY_CHECK_INTERVAL = 30000; // 30 ثانية
let isRevalidateInProgress = false;

// ============================================
// ===== نظام سرعة التحميل =====
// ============================================

const userSpeedLimits = new Map();

const SPEED_CONFIG = {
  defaultSpeed: 1,
  maxSpeed: 100,
  enabled: true,
  totalBandwidthLimit: 0
};

const SPEED_CONFIG_FILE = getDataPath('speed_config.json');

// ============================================
// ===== ملفات النظام =====
// ============================================

const CONFIG_FILE = getDataPath('config.json');
const RESTRICTIONS_FILE = getDataPath('restrictions.json');
const CHANNELS_FILE = getDataPath('channels.json');
const EXCLUSIVE_FILE = getDataPath('exclusive.json');
const USERS_FILE = getDataPath('users.json');
const INFO_FILE = getDataPath('info.json');
const MESSAGES_FILE = getDataPath('messages.json');
const WATCH_HISTORY_FILE = getDataPath('watch_history.json');
const BACKUP_FILE = getDataPath('backup_full.json');
const SYNC_CACHE_FILE = getDataPath('sync_cache.json');
const FOLDER_IMAGES_CACHE_FILE = getDataPath('folder_images_cache.json');
const CONVERSION_CONFIG_FILE = getDataPath('conversion_config.json');
const SCAN_RESULTS_FILE = getDataPath('scan_results.json');
const METADATA_CACHE_FILE = path.join(DATA_DIR, 'metadata_cache.json');
const PAGE_VIEWS_FILE = getDataPath('page_views.json');
// ============================================
// ===== دالة الصورة الافتراضية =====
// ============================================
function saveSyncCache(cache) {
  try {
    fs.writeFileSync(SYNC_CACHE_FILE, JSON.stringify(cache, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ كاش المزامنة:', error);
    return false;
  }
}
function saveMetadataCache(cache) {
  try {
    fs.writeFileSync(METADATA_CACHE_FILE, JSON.stringify(cache, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ كاش الميتاداتا:', error);
    return false;
  }
}
// ============================================
// دوال حفظ الملفات الإضافية للنسخ الاحتياطي
// ============================================

function saveAllMessages(messages) {
  try {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ الرسائل:', error);
    return false;
  }
}

function saveFolderImagesCache(cache) {
  try {
    fs.writeFileSync(FOLDER_IMAGES_CACHE_FILE, JSON.stringify(cache, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ كاش صور المجلدات:', error);
    return false;
  }
}

function saveScanResults(data) {
  try {
    fs.writeFileSync(SCAN_RESULTS_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ نتائج المسح:', error);
    return false;
  }
}

function saveConversionConfig(config) {
  try {
    fs.writeFileSync(CONVERSION_CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ إعدادات التحويل:', error);
    return false;
  }
}
const DEFAULT_IMAGE_PATH = path.join(PUBLIC_DIR, 'fav.png');
const TRANSPARENT_PIXEL = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
  'base64'
);

/**
 * ترسل صورة افتراضية (fav.png إن وجدت، وإلا صورة شفافة)
 * @param {Response} res - كائن الاستجابة من Express
 * @param {string} mimeType - نوع MIME (افتراضي image/png)
 */
function sendDefaultImage(res, mimeType = 'image/png') {try {
    if (fs.existsSync(DEFAULT_IMAGE_PATH)) {
      res.setHeader('Content-Type', mimeType);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      return fs.createReadStream(DEFAULT_IMAGE_PATH).pipe(res);
    } else {
      // صورة شفافة 1×1 بكسل
      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Cache-Control', 'no-cache');
      res.send(TRANSPARENT_PIXEL);
    }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}
// ============================================
// ===== تحميل الإعدادات =====
// ============================================

let config = loadConfig();
let restrictions = loadRestrictions();
let channels = loadChannelsFromFile();
let exclusiveContent = loadExclusiveContent();
let users = loadUsersFromFile();
let speedConfig = loadSpeedConfig();

//  //////console.log('📂 تم تحميل الإعدادات');
//  //////console.log(`📁 عدد الأقسام: ${config.categories?.length || 0}`);
//  //////console.log(`🔒 تم تحميل إعدادات المنع`);
//  //////console.log(`📺 عدد القنوات: ${channels?.length || 0}`);
//  //////console.log(`⭐ عدد المحتوى الحصري: ${exclusiveContent?.length || 0}`);
//  //////console.log(`👤 عدد المستخدمين: ${users?.length || 0}`);
//  //////console.log(`⚡ تم تحميل إعدادات السرعة`);

// ============================================
// ===== دوال تحميل وحفظ الإعدادات =====
// ============================================
// ============================================
// ===== بث الفيديو عبر FFmpeg (تحويل على الطاير) =====
// ============================================

// ============================================
// ===== بث الفيديو عبر FFmpeg (تحويل على الطاير) =====
// ============================================

const TRANSCODE_EXTS = ['.avi', '.mkv', '.mov', '.wmv', '.flv', '.mpeg', '.mpg', '.ts', '.mts', '.m2ts', '.vob', '.divx', '.xvid', '.ogv', '.3gp'];


// ============================================
// ===== بث الفيديو عبر FFmpeg مع دعم Range =====
// ============================================
const VIEWS_FILE = getDataPath('views.json');




function saveViews(views) {
    try {
        if (!views || typeof views !== 'object') {
            views = {};
        }
        
        // ✅ إنشاء نسخة احتياطية قبل الكتابة
        if (fs.existsSync(VIEWS_FILE)) {
            try {
                const backupPath = VIEWS_FILE + '.backup';
                fs.copyFileSync(VIEWS_FILE, backupPath);
            } catch (e) {}
        }
        
        // ✅ كتابة ذرية (Atomic Write) لتجنب التلف
        const tempPath = VIEWS_FILE + '.tmp';
        fs.writeFileSync(tempPath, JSON.stringify(views, null, 2), 'utf8');
        fs.renameSync(tempPath, VIEWS_FILE);  // نقل ذري
        
        return true;
    } catch (e) { 
        console.error('❌ خطأ في حفظ المشاهدات:', e); 
        return false; 
    }
}
function loadViews() {
    try {
        if (fs.existsSync(VIEWS_FILE)) {
            const data = fs.readFileSync(VIEWS_FILE, 'utf8');
            
            if (!data || data.trim() === '') {
                // ⚠️ لا ترجع {} مباشرة! حاول استرجاع النسخة الاحتياطية
                console.warn('⚠️ ملف المشاهدات فارغ، محاولة استرجاع النسخة الاحتياطية...');
                return tryRestoreViewsBackup();
            }
            
            const parsed = JSON.parse(data);
            
            // التحقق من البنية
            if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
                console.warn('⚠️ بنية ملف المشاهدات غير صحيحة، محاولة استرجاع النسخة الاحتياطية...');
                return tryRestoreViewsBackup();
            }
            
            return parsed;
        }
    } catch (e) { 
        console.error('❌ خطأ في تحميل المشاهدات:', e);
        // ⚠️ لا ترجع {} مباشرة! حاول استرجاع النسخة الاحتياطية
        return tryRestoreViewsBackup();
    }
    return {};
}
// ✅ دالة استرجاع النسخة الاحتياطية
function tryRestoreViewsBackup() {
    const backupPath = VIEWS_FILE + '.backup';
    try {
        if (fs.existsSync(backupPath)) {
            const backupData = fs.readFileSync(backupPath, 'utf8');
            if (backupData && backupData.trim()) {
                const parsed = JSON.parse(backupData);
                console.log('✅ تم استرجاع النسخة الاحتياطية بنجاح من views.json.backup');
                // استعادة الملف الأصلي
                fs.writeFileSync(VIEWS_FILE, backupData, 'utf8');
                return parsed;
            }
        }
    } catch (e) {
        console.error('❌ فشل استرجاع النسخة الاحتياطية:', e);
    }
    console.warn('⚠️ لا توجد نسخة احتياطية، سيتم البدء من جديد');
    return {};
}

function transcodeAndStream(inputPath, req, res) {
  const ffmpegPath = getFfmpegPath();
  const startTime = parseFloat(req.query.start) || 0;

  // رؤوس محسنة
  res.setHeader('Content-Type', 'video/mp4');
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Accept-Ranges, Content-Length, Content-Type');

  // ✅ تحسين دعم التقديم والرجاع باستخدام -ss قبل -i
  const args = [
    '-hide_banner',
    '-loglevel', 'error'
  ];

  // ✅ وضع -ss قبل -i للبحث السريع (Fast Seek)
  if (startTime > 0) {
    args.push('-ss', String(startTime));
  }

  args.push(
    '-i', inputPath,
    '-c:v', 'libx264',
    '-preset', 'veryfast',  // ✅ أسرع إعداد
    '-tune', 'zerolatency', // ✅ لتقليل التأخير
    '-crf', '23',
    '-pix_fmt', 'yuv420p',
    '-c:a', 'aac',
    '-b:a', '128k',
    '-movflags', '+faststart+frag_keyframe+empty_moov', // ✅ دعم التقديم
    '-f', 'mp4',
    'pipe:1'
  );

  // إضافة حد أقصى للبت لتقليل التأخير
  args.push('-maxrate', '2M');
  args.push('-bufsize', '4M');

  const proc = spawn(ffmpegPath, args, { windowsHide: true });

  let started = false;
  let dataBuffer = [];
  let bufferSize = 0;
  const MAX_BUFFER_SIZE = 1024 * 1024;

  proc.stdout.on('data', (chunk) => {
    if (!started) {
      started = true;
      res.writeHead(200);
    }

    dataBuffer.push(chunk);
    bufferSize += chunk.length;

    if (bufferSize >= 256 * 1024) {
      const data = Buffer.concat(dataBuffer);
      res.write(data);
      dataBuffer = [];
      bufferSize = 0;
    }
  });

  proc.stdout.on('end', () => {
    if (dataBuffer.length > 0) {
      const data = Buffer.concat(dataBuffer);
      res.write(data);
      dataBuffer = [];
    }
    if (!res.writableEnded) {
      try { res.end(); } catch (e) {}
    }
  });

  let errorLog = '';
  proc.stderr.on('data', (data) => {
    errorLog += data.toString();
  });

  proc.on('close', (code) => {
    if (code !== 0 && code !== null) {
      console.error(`❌ FFmpeg انتهى بالكود ${code}`);
    }
    if (!res.writableEnded) {
      try {
        if (dataBuffer.length > 0) {
          res.write(Buffer.concat(dataBuffer));
        }
        res.end();
      } catch (e) {}
    }
  });

  proc.on('error', (err) => {
    console.error('❌ خطأ FFmpeg:', err);
    if (!res.headersSent) {
      res.status(500).json({
        error: 'فشل تحويل الفيديو',
        details: err.message
      });
    } else {
      try { res.end(); } catch (e) {}
    }
  });

  req.on('close', () => {
    try {
      if (proc && !proc.killed) {
        proc.kill('SIGKILL');
      }
      dataBuffer = [];
      bufferSize = 0;
    } catch (e) {}
  });
}
// ============================================
// ===== دعم مسارات الشبكة (Network Paths) =====
// ============================================

// ===== التحقق من وجود المسار (يدعم الشبكة) =====
function checkPathExists(path) {
  if (!path) return false;

  try {
    // إذا كان مساراً شبكياً، لا نتحقق من وجوده عند الإضافة (قد لا يكون متصلاً الآن)
    if (path.startsWith('//') || path.startsWith('\\\\')) {
      // فقط نتحقق من صياغته
      const parts = path.replace(/^\/+/, '').split('/');
      return parts.length >= 2;
    }

    // مسار محلي - نتحقق من وجوده
    return fs.existsSync(path);
  } catch (e) {
    return false;
  }
}

// ===== دالة موحدة للوصول إلى المسار (تدعم الشبكة) =====
function normalizePathForAccess(path) {try {
    if (!path) return path;

    // تحويل مسار الشبكة إلى صيغة مناسبة
    let normalized = path.replace(/\\/g, '/');

    // إذا كان مسار شبكي يبدأ بـ //، نحافظ عليه
    if (normalized.startsWith('//')) {
      return normalized;
    }

    // إذا كان مسار Windows يبدأ بحرف، نضيف :/
    if (normalized.match(/^[A-Za-z]:[^\\/]/)) {
      normalized = normalized.replace(/^([A-Za-z]):([^\\/])/, '$1:/$2');
    }

    return normalized;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ===== دالة مسح مجلد تدعم الشبكة =====
function scanNetworkDirectory(dir, categoryId, driveIndex, drivePath, depth = 0, maxDepth = 10) {
  const results = [];

  if (depth > maxDepth) {
    return results;
  }

  try {
    // محاولة الوصول إلى المسار (يدعم الشبكة)
    let normalizedDir = normalizePathForAccess(dir);

    // التحقق من وجود المسار
    if (!fs.existsSync(normalizedDir)) {
      // إذا كان مساراً شبكياً، قد يكون غير متصل حالياً
      if (dir.startsWith('//') || dir.startsWith('\\\\')) {
        ////console.log(`⚠️ مسار شبكي غير متصل: ${dir}`);
        return results;
      }
      return results;
    }

    const stat = fs.statSync(normalizedDir);
    if (!stat.isDirectory()) {
      return results;
    }

    const items = fs.readdirSync(normalizedDir);

    const videoExtensions = [
    '.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm',
    '.m4v', '.mpg', '.mpeg', '.3gp', '.ogv', '.ts', '.mts',
    '.m2ts', '.vob', '.divx', '.xvid'];


    const folderFiles = [];

    for (const item of items) {
      if (item.startsWith('.')) continue;
      if (item.startsWith('$')) continue;
      if (item === 'System Volume Information') continue;
      if (item === '$RECYCLE.BIN') continue;
      if (item === 'desktop.ini') continue;
      if (item === 'Thumbs.db') continue;

      const fullPath = path.join(normalizedDir, item);

      try {
        const itemStat = fs.statSync(fullPath);

        if (itemStat.isDirectory()) {
          const subResults = scanNetworkDirectory(
            fullPath,
            categoryId,
            driveIndex,
            drivePath,
            depth + 1,
            maxDepth
          );
          results.push(...subResults);
        } else {
          const ext = path.extname(item).toLowerCase();
          if (videoExtensions.includes(ext)) {
            folderFiles.push({
              name: item,
              fullPath: fullPath,
              modified: itemStat.mtime,
              size: itemStat.size,
              extension: ext,
              categoryId: categoryId,
              driveIndex: driveIndex,
              isDirectory: false,
              depth: depth
            });
          }
        }
      } catch (e) {

        // تجاهل الأخطاء
      }}

    if (folderFiles.length > 0) {
      folderFiles.sort((a, b) => {try {return new Date(b.modified) - new Date(a.modified);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
      const latestFile = folderFiles[0];

      const relativePath = getSmartRelativePath(latestFile.fullPath, drivePath);

      const posterPath = findFirstImageInFolder(normalizedDir);

      results.push({
        name: latestFile.name,
        path: relativePath,
        fullPath: latestFile.fullPath,
        modified: latestFile.modified,
        size: latestFile.size,
        extension: latestFile.extension,
        categoryId: categoryId,
        driveIndex: driveIndex,
        isDirectory: false,
        posterPath: posterPath ? posterPath.replace(/\\/g, '/') : null,
        folderPath: normalizedDir,
        depth: depth,
        fromFolder: true
      });
    }

  } catch (error) {
    // تجاهل أخطاء المسارات الشبكية
    if (!dir.startsWith('//') && !dir.startsWith('\\\\')) {
      console.error(`❌ خطأ في قراءة ${dir}:`, error.message);
    }
  }

  return results;
}
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = fs.readFileSync(CONFIG_FILE, 'utf8');

      // ✅ التحقق من أن الملف ليس فارغاً
      if (!data || data.trim() === '') {
        console.warn('⚠️ ملف config.json فارغ، جاري إنشاء ملف جديد');
        const defaultConfig = createDefaultConfig();
        saveConfig(defaultConfig);
        return defaultConfig;
      }

      const config = JSON.parse(data);

      // ✅ التأكد من وجود categories
      if (!config.categories || !Array.isArray(config.categories)) {
        config.categories = [];
      }

      // ✅ تنظيف البيانات الفاسدة
      config.categories = config.categories.filter((cat) => {try {return cat && typeof cat === 'object' && cat.id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

      config.categories.forEach((cat) => {try {
          // ✅ التأكد من وجود paths
          if (!cat.paths || !Array.isArray(cat.paths)) {
            cat.paths = [];
          }

          // ✅ إزالة العناصر الفاسدة
          cat.paths = cat.paths.filter((p) => {try {return p && typeof p === 'object' && p.path;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

          // ✅ التأكد من وجود id و name
          cat.paths.forEach((p, idx) => {try {
              if (!p.id) {
                p.id = `path_${cat.id}_${idx}_${Date.now()}`;
              }
              if (!p.name) {
                p.name = path.basename(p.path) || 'مسار';
              }
              if (!p.type) {
                p.type = 'all';
              }
              if (p.isNetwork === undefined) {
                p.isNetwork = p.path.startsWith('//') || p.path.startsWith('\\\\');
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
      });

      // ✅ التأكد من وجود port
      if (!config.port) {
        config.port = 3000;
      }

      return config;
    }
  } catch (error) {
    console.error('❌ خطأ في قراءة الإعدادات:', error);

    // ✅ إذا كان الملف تالفاً، أعده إنشاء
    try {
      if (fs.existsSync(CONFIG_FILE)) {
        fs.unlinkSync(CONFIG_FILE);
        ////console.log('🗑️ تم حذف ملف config.json التالف');
      }
    } catch (e) {
      console.error('❌ فشل حذف الملف التالف:', e);
    }
  }

  // ✅ إنشاء ملف افتراضي
  const defaultConfig = createDefaultConfig();
  saveConfig(defaultConfig);
  return defaultConfig;
}

function createDefaultConfig() {try {
    return {
      categories: [{
        id: 'افلام_' + Date.now(),
        name: '🎬 أفلام',
        icon: '🎬',
        color: '#e74c3c',
        paths: [],
        enabled: true
      }],
      defaultCategory: null,
      port: 3000
    };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

app.post('/api/repair-config', (req, res) => {
  try {
    const fixed = repairConfig();
    if (fixed) {
      res.json({
        success: true,
        message: 'تم إصلاح config.json بنجاح',
        categories: fixed.categories.length
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'فشل إصلاح config.json'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

function repairConfig() {
  try {
    const config = loadConfig();

    // ✅ إصلاح كل قسم
    config.categories.forEach((cat) => {try {
        if (!cat.paths || !Array.isArray(cat.paths)) {
          cat.paths = [];
        }
        // ✅ إزالة العناصر الفاسدة
        cat.paths = cat.paths.filter((p) => {try {return p && typeof p === 'object' && p.path;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        // ✅ إضافة معرفات مفقودة
        cat.paths.forEach((p, idx) => {try {
            if (!p.id) {
              p.id = `path_${cat.id}_${idx}_${Date.now()}`;
            }
            if (!p.name) {
              p.name = path.basename(p.path) || 'مسار';
            }
            if (!p.type) {
              p.type = 'all';
            }
            if (p.isNetwork === undefined) {
              p.isNetwork = p.path.startsWith('//') || p.path.startsWith('\\\\');
            }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    saveConfig(config);
    ////console.log('✅ تم إصلاح config.json');
    return config;
  } catch (error) {
    console.error('❌ فشل إصلاح config.json:', error);
    return null;
  }
}

function saveConfig(config) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ الإعدادات:', error);
    return false;
  }
}

function loadRestrictions() {
  try {
    if (fs.existsSync(RESTRICTIONS_FILE)) {
      const data = fs.readFileSync(RESTRICTIONS_FILE, 'utf8');
      if (!data || data.trim() === '') {
        const defaultRestrictions = { downloadBlocked: [], pathRestrictions: [] };
        saveRestrictions(defaultRestrictions);
        return defaultRestrictions;
      }
      const parsed = JSON.parse(data);

      if (typeof parsed !== 'object' || parsed === null) {
        const defaultRestrictions = { downloadBlocked: [], pathRestrictions: [] };
        saveRestrictions(defaultRestrictions);
        return defaultRestrictions;
      }

      // ✅ تأكد من أن المصفوفات موجودة ونظيفة
      if (!Array.isArray(parsed.downloadBlocked)) parsed.downloadBlocked = [];
      if (!Array.isArray(parsed.pathRestrictions)) parsed.pathRestrictions = [];

      // ✅ إزالة العناصر الفاسدة (null أو غير كائنات)
      parsed.downloadBlocked = parsed.downloadBlocked.filter((r) => {try {return r && typeof r === 'object';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
      parsed.pathRestrictions = parsed.pathRestrictions.filter((r) => {try {return r && typeof r === 'object';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

      return parsed;
    }
  } catch (error) {
    console.error('❌ خطأ في تحميل إعدادات المنع:', error);
    try {
      if (fs.existsSync(RESTRICTIONS_FILE)) {
        fs.unlinkSync(RESTRICTIONS_FILE);
      }
    } catch (e) {}
  }

  const defaultRestrictions = { downloadBlocked: [], pathRestrictions: [] };
  saveRestrictions(defaultRestrictions);
  return defaultRestrictions;
}

function saveRestrictions(restrictions) {
  try {
    const jsonData = JSON.stringify(restrictions, null, 2);
    fs.writeFileSync(RESTRICTIONS_FILE, jsonData, 'utf8');
    //console.log('✅ تم حفظ إعدادات المنع بنجاح');
    return true;
  } catch (error) {
    console.error('❌ فشل حفظ إعدادات المنع:', error);
    return false;
  }
}

function loadChannelsFromFile() {
  try {
    if (fs.existsSync(CHANNELS_FILE)) {
      const data = fs.readFileSync(CHANNELS_FILE, 'utf8');
      if (data && data.trim()) {
        return JSON.parse(data);
      }
    }
  } catch (error) {
    console.error('❌ خطأ في تحميل القنوات:', error);
  }
  return [];
}

function saveChannelsToFile(channels) {
  try {
    fs.writeFileSync(CHANNELS_FILE, JSON.stringify(channels, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ القنوات:', error);
    return false;
  }
}

function loadExclusiveContent() {
  try {
    if (fs.existsSync(EXCLUSIVE_FILE)) {
      const data = fs.readFileSync(EXCLUSIVE_FILE, 'utf8');
      if (!data || data.trim() === '') {
        saveExclusiveContent([]);
        return [];
      }
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('❌ خطأ في تحميل المحتوى الحصري:', error);
  }
  return [];
}

function saveExclusiveContent(content) {
  try {
    fs.writeFileSync(EXCLUSIVE_FILE, JSON.stringify(content, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ المحتوى الحصري:', error);
    return false;
  }
}

function loadUsersFromFile() {
  try {
    if (fs.existsSync(USERS_FILE)) {
      const data = fs.readFileSync(USERS_FILE, 'utf8');
      if (data && data.trim()) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    }
  } catch (error) {
    console.error('❌ خطأ في تحميل المستخدمين:', error);
  }

  const defaultUsers = [{
    id: 'admin',
    username: 'admin',
    password: 'admin123',
    role: 'admin',
    created: Date.now(),
    lastLogin: null,
    updatedAt: null
  }];
  saveUsersToFile(defaultUsers);
  return defaultUsers;
}

function saveUsersToFile(users) {
  try {
    if (!Array.isArray(users)) {
      console.error('❌ البيانات ليست مصفوفة:', users);
      return false;
    }
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ المستخدمين:', error);
    return false;
  }
}

function loadInfoFromFile() {
  try {
    if (fs.existsSync(INFO_FILE)) {
      const data = fs.readFileSync(INFO_FILE, 'utf8');
      if (data && data.trim()) {
        return JSON.parse(data);
      }
    }
  } catch (error) {
    console.error('❌ خطأ في تحميل المعلومات:', error);
  }
  return {
    name: '🏠 استراحة العائلة',
    description: 'مرحباً بكم في استراحة العائلة - وجهتكم المفضلة للاسترخاء والترفيه',
    phone: '📞 0500000000',
    whatsapp: '📱 0500000000',
    email: '📧 info@example.com',
    socialMedia: {
      facebook: '',
      instagram: '',
      twitter: '',
      youtube: ''
    },
    updatedAt: Date.now()
  };
}

function saveInfoToFile(info) {
  try {
    info.updatedAt = Date.now();
    fs.writeFileSync(INFO_FILE, JSON.stringify(info, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ المعلومات:', error);
    return false;
  }
}

function loadSpeedConfig() {
  try {
    if (fs.existsSync(SPEED_CONFIG_FILE)) {
      const data = fs.readFileSync(SPEED_CONFIG_FILE, 'utf8');
      const config = JSON.parse(data);
      return { ...SPEED_CONFIG, ...config };
    }
  } catch (error) {
    console.error('❌ خطأ في قراءة إعدادات السرعة:', error);
  }
  saveSpeedConfig(SPEED_CONFIG);
  return SPEED_CONFIG;
}

function saveSpeedConfig(config) {
  try {
    fs.writeFileSync(SPEED_CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ إعدادات السرعة:', error);
    return false;
  }
}

function loadWatchHistory() {
  try {
    if (fs.existsSync(WATCH_HISTORY_FILE)) {
      const data = fs.readFileSync(WATCH_HISTORY_FILE, 'utf8');
      if (!data || data.trim() === '') {
        saveWatchHistory({});
        return {};
      }
      const parsed = JSON.parse(data);
      if (typeof parsed !== 'object' || parsed === null) {
        saveWatchHistory({});
        return {};
      }
      return parsed;
    }
  } catch (error) {
    console.error('❌ خطأ في تحميل سجل المشاهدة:', error);
    try {
      if (fs.existsSync(WATCH_HISTORY_FILE)) {
        fs.unlinkSync(WATCH_HISTORY_FILE);
      }
      saveWatchHistory({});
    } catch (e) {
      console.error('❌ فشل في إنشاء ملف جديد:', e);
    }
  }
  return {};
}

function saveWatchHistory(history) {
  try {
    if (!history || typeof history !== 'object') {
      history = {};
    }
    const jsonData = JSON.stringify(history, null, 2);
    fs.writeFileSync(WATCH_HISTORY_FILE, jsonData, 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ سجل المشاهدة:', error);
    return false;
  }
}

// ============================================
// ===== دوال مساعدة =====
// ============================================

function getPortFromConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = fs.readFileSync(CONFIG_FILE, 'utf8');
      const configData = JSON.parse(data);
      return configData.port || 3000;
    }
  } catch (error) {
    console.error('❌ خطأ في قراءة البورت:', error);
  }
  return 3000;
}

function savePortToConfig(port) {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = fs.readFileSync(CONFIG_FILE, 'utf8');
      const configData = JSON.parse(data);
      configData.port = port;

      if (!configData.categories) {
        configData.categories = [];
      }

      fs.writeFileSync(CONFIG_FILE, JSON.stringify(configData, null, 2), 'utf8');
      return true;
    } else {
      const defaultConfig = {
        categories: [],
        port: port,
        defaultCategory: null
      };
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(defaultConfig, null, 2), 'utf8');
      return true;
    }
  } catch (error) {
    console.error('❌ خطأ في حفظ البورت:', error);
    return false;
  }
}

function getValidCategories() {try {
    if (!config || !config.categories || !Array.isArray(config.categories)) {
      config = loadConfig();
    }
    return config.categories.filter((cat) => {try {return cat.enabled !== false;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

function isDownloadAllowed(pathId, filePath) {try {
    // ✅ التحقق من وجود restrictions
    //console.log(`🔍 التحقق من المنع: pathId=${pathId}, filePath=${filePath}`);
    //console.log('📋 restrictions.pathRestrictions:', restrictions.pathRestrictions)
    if (!restrictions || typeof restrictions !== 'object') {
      restrictions = { downloadBlocked: [], pathRestrictions: [] };
      saveRestrictions(restrictions);
      return true;
    }

    // ✅ تأكد من وجود المصفوفات
    if (!Array.isArray(restrictions.pathRestrictions)) {
      restrictions.pathRestrictions = [];
    }
    if (!Array.isArray(restrictions.downloadBlocked)) {
      restrictions.downloadBlocked = [];
    }

    // ✅ تنظيف العناصر الفاسدة
    restrictions.pathRestrictions = restrictions.pathRestrictions.filter((r) => {try {return r && typeof r === 'object';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
    restrictions.downloadBlocked = restrictions.downloadBlocked.filter((r) => {try {return r && typeof r === 'object';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

    // ✅ التحقق من منع المسار
    const pathRestriction = restrictions.pathRestrictions.find((r) => {try {return r.pathId === pathId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
    if (pathRestriction && pathRestriction.download === false) {
      return false;
    }

    // ✅ التحقق من منع ملف معين
    const fileRestriction = restrictions.downloadBlocked.find(
      (r) => {try {return r.pathId === pathId && r.filePath === filePath;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}
    );
    if (fileRestriction) {
      return false;
    }

    return true;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

function getUserId(req) {
  try {
    // ✅ الأولوية القصوى: من الهيدر
    const deviceId = req.headers['x-device-id'];
    if (deviceId) {
      return deviceId; // ← المشاهدة تستخدم هذا المعرف
    }

    // ✅ ثانياً: من ملفات تعريف الارتباط
    const cookieHeader = req.headers.cookie || '';
    const cookies = cookieHeader.split(';').reduce((acc, cookie) => {try {
        const [name, value] = cookie.trim().split('=');
        acc[name] = value;
        return acc;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    }, {});

    if (cookies['deviceId']) {
      return cookies['deviceId'];
    }

    // ✅ الحل الأخير
    const ip = req.headers['x-forwarded-for'] ||
    req.connection?.remoteAddress ||
    req.socket?.remoteAddress ||
    'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    return Buffer.from(ip + '|' + userAgent).toString('base64').substring(0, 20);
  } catch (error) {
    return 'guest_' + Date.now();
  }
}/**
 * تثبيت التحديث (مع نسخ احتياطي تلقائي)
 */
async function installUpdate(filePath, version) {
  try {
    console.log(`🔧 جاري تثبيت التحديث ${version}...`);

    if (!fs.existsSync(filePath)) {
      throw new Error('ملف التحديث غير موجود');
    }

    // 1. نسخة احتياطية تلقائية قبل التحديث
    if (updateConfig.autoBackupBeforeUpdate) {
      console.log('💾 إنشاء نسخة احتياطية قبل التحديث...');
      const backupResult = createPreUpdateBackup(version);
      
      if (!backupResult.success) {
        console.warn('⚠️ فشل النسخ الاحتياطي، الاستمرار بحذر...');
      }
    }

    // 2. استخراج الملف
    const extractDir = path.join(DATA_DIR, 'updates', 'extracted');
    
    if (fs.existsSync(extractDir)) {
      fs.rmSync(extractDir, { recursive: true, force: true });
    }
    fs.mkdirSync(extractDir, { recursive: true });

    console.log('📦 جاري استخراج الملفات...');
    
    const { execSync } = require('child_process');
    
    try {
      if (process.platform === 'win32') {
        execSync(`powershell -command "Expand-Archive -Path '${filePath}' -DestinationPath '${extractDir}' -Force"`, {
          windowsHide: true,
          timeout: 120000
        });
      } else {
        execSync(`unzip -o "${filePath}" -d "${extractDir}"`, {
          timeout: 120000
        });
      }
    } catch (extractError) {
      throw new Error(`فشل استخراج الملف: ${extractError.message}`);
    }

    // 3. نسخ الملفات
    const filesToUpdate = ['server.js', 'dashboard.js', 'package.json'];
    const publicFiles = ['dashboard.html', 'index.html', 'style.css', 'script.js'];
    
    let updatedFiles = [];

    for (const file of filesToUpdate) {
      const sourcePath = path.join(extractDir, file);
      const destPath = path.join(process.cwd(), file);
      
      if (fs.existsSync(sourcePath)) {
        fs.copyFileSync(sourcePath, destPath);
        updatedFiles.push(file);
        console.log(`✅ تم تحديث: ${file}`);
      }
    }

    const publicSourceDir = path.join(extractDir, 'public');
    if (fs.existsSync(publicSourceDir)) {
      for (const file of publicFiles) {
        const sourcePath = path.join(publicSourceDir, file);
        const destPath = path.join(PUBLIC_DIR, file);
        
        if (fs.existsSync(sourcePath)) {
          fs.copyFileSync(sourcePath, destPath);
          updatedFiles.push(`public/${file}`);
          console.log(`✅ تم تحديث: public/${file}`);
        }
      }
    }

    // 4. تحديث الإصدار
    const oldVersion = updateConfig.currentVersion;
    updateConfig.currentVersion = version;
    updateConfig.lastUpdate = Date.now();
    saveUpdateConfig(updateConfig);

    // 5. حذف الملف المؤقت
    try {
      fs.unlinkSync(filePath);
    } catch (e) {}

    // 6. تنظيف الكاش
    const cache = loadUpdateCache();
    cache.downloadedFile = null;
    cache.installedVersion = version;
    cache.installedAt = Date.now();
    cache.previousVersion = oldVersion;
    saveUpdateCache(cache);

    console.log(`✅ تم تثبيت التحديث ${version} بنجاح`);

    return {
      success: true,
      version,
      previousVersion: oldVersion,
      updatedFiles,
      message: 'تم تثبيت التحديث بنجاح'
    };

  } catch (error) {
    console.error('❌ خطأ في تثبيت التحديث:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
}
// ============================================
// ===== ضمان وجود ملف كاش البحث =====
// ============================================

function ensureSyncCacheFile() {
  try {
    if (!fs.existsSync(SYNC_CACHE_FILE)) {
      const defaultCache = {
        categories: {},
        lastSync: null,
        totalFiles: 0,
        totalPosters: 0,
        categoriesCount: 0,
        foldersScanned: 0,
        categoriesWithFiles: 0,
        maxDepth: 10
      };
      fs.writeFileSync(SYNC_CACHE_FILE, JSON.stringify(defaultCache, null, 2), 'utf8');
      ////console.log('📄 تم إنشاء ملف كاش البحث (sync_cache.json)');
      return true;
    }
    // التحقق من صحة الملف (غير فارغ)
    const data = fs.readFileSync(SYNC_CACHE_FILE, 'utf8');
    if (!data || data.trim() === '') {
      // إعادة إنشاء الملف إذا كان فارغاً
      const defaultCache = {
        categories: {},
        lastSync: null,
        totalFiles: 0,
        totalPosters: 0,
        categoriesCount: 0,
        foldersScanned: 0,
        categoriesWithFiles: 0,
        maxDepth: 10
      };
      fs.writeFileSync(SYNC_CACHE_FILE, JSON.stringify(defaultCache, null, 2), 'utf8');
      ////console.log('🔄 تم إعادة إنشاء ملف كاش البحث (كان فارغاً)');
    }
    return true;
  } catch (error) {
    console.error('❌ فشل إنشاء/التحقق من ملف كاش البحث:', error);
    return false;
  }
}
// ============================================
// ===== نظام تتبع المستخدمين =====
// ============================================

let activeSessions = [];
let totalSessions = 0;
let peakUsers = 0;
let sessionIdCounter = 0;

function getClientInfo(req) {try {
    const ip = req.headers['x-forwarded-for'] ||
    req.connection?.remoteAddress ||
    req.socket?.remoteAddress ||
    'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    let device = 'Unknown';
    if (userAgent.includes('Chrome')) device = 'Chrome';else
    if (userAgent.includes('Firefox')) device = 'Firefox';else
    if (userAgent.includes('Safari')) device = 'Safari';else
    if (userAgent.includes('Edge')) device = 'Edge';else
    if (userAgent.includes('Mobile')) device = 'Mobile';else
    if (userAgent.includes('Android')) device = 'Android';else
    if (userAgent.includes('iPhone')) device = 'iPhone';else
    if (userAgent.includes('iPad')) device = 'iPad';

    return { ip, device, userAgent };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

function trackSession(req, filePath = null) {try {
    const { ip, device } = getClientInfo(req);

    let session = activeSessions.find((s) => {try {return s.ip === ip && s.device === device;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

    if (!session) {
      sessionIdCounter++;
      session = {
        id: 'session_' + sessionIdCounter,
        ip: ip,
        device: device,
        username: 'زائر',
        connected: Date.now(),
        lastActivity: Date.now(),
        currentFile: null,
        progress: 0,
        speed: 0,
        isActive: true,
        bytesTransferred: 0,
        startTime: Date.now(),
        totalSize: 0
      };
      activeSessions.push(session);
      totalSessions++;

      if (activeSessions.length > peakUsers) {
        peakUsers = activeSessions.length;
      }
    }

    session.lastActivity = Date.now();
    if (filePath) {
      session.currentFile = path.basename(filePath);
    }

    return session;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

function updateSessionProgress(sessionId, bytes, totalSize) {try {
    const session = activeSessions.find((s) => {try {return s.id === sessionId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
    if (session) {
      session.bytesTransferred += bytes;
      session.totalSize = totalSize || session.totalSize;
      if (session.totalSize > 0) {
        session.progress = Math.min(100, Math.floor(session.bytesTransferred / session.totalSize * 100));
      }
      session.lastActivity = Date.now();

      const elapsed = (Date.now() - session.startTime) / 1000;
      if (elapsed > 0) {
        session.speed = parseFloat((session.bytesTransferred / elapsed / 1024 / 1024).toFixed(2));
      }
    }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

function cleanupSessions() {try {
    const timeout = 300000;
    const now = Date.now();
    const before = activeSessions.length;
    activeSessions = activeSessions.filter((s) => {try {return now - s.lastActivity < timeout;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
    if (activeSessions.length !== before) {

      //  //////console.log(`🧹 تم تنظيف الجلسات: ${before} → ${activeSessions.length}`);
    }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}

setInterval(cleanupSessions, 60000);

// ============================================
// ===== جلب الوقت من الإنترنت =====
// ============================================

async function fetchTimeFromGoogle() {try {
    const now = Date.now();
    if (cachedTime && now - cachedTimeTimestamp < TIME_CACHE_DURATION) {
      return cachedTime;
    }

    //  //////console.log('⏰ جاري جلب الوقت من الإنترنت...');

    const sources = [
    // ... 你原有的 sources ...
    {
      url: 'https://timeapi.world/api/timezone/Etc/UTC',
      timeout: 10000,
      getTimestamp: (data) => {try {return data?.unixtime ? data.unixtime * 1000 : null;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}
    },
    {
      url: 'https://time.now/developer/api/timezone/Etc/UTC',
      timeout: 10000,
      getTimestamp: (data) => {try {return data?.unixtime ? data.unixtime * 1000 : null;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}
    },
    {
      url: 'https://1.1.1.1/cdn-cgi/trace',
      timeout: 5000,
      getTimestamp: (data) => {try {
          // data 是纯文本字符串
          const match = data.match(/^ts=(\d+\.?\d*)/m);
          return match ? parseFloat(match[1]) * 1000 : null;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
      }
    }];


    for (const source of sources) {
      try {
        //  //////console.log(`📡 محاولة: ${source.url || 'وقت النظام'}`);

        let timestamp = null;

        if (source.getTimestamp) {
          if (source.url) {
            const response = await axios.get(source.url, {
              timeout: source.timeout,
              headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json',
                'Accept-Language': 'en-US,en;q=0.9',
                'Cache-Control': 'no-cache'
              }
            });

            if (response.status === 200 && response.data) {
              timestamp = source.getTimestamp(response.data);
            }
          } else {
            timestamp = source.getTimestamp();
          }
        }

        if (timestamp && timestamp > 0) {
          const minTime = new Date('2020-01-01').getTime();
          const maxTime = new Date('2030-01-01').getTime();

          if (timestamp >= minTime && timestamp <= maxTime) {
            cachedTime = timestamp;
            cachedTimeTimestamp = Date.now();
            //  //////console.log(`✅ الوقت من ${source.url || 'النظام'}: ${new Date(timestamp).toLocaleString('ar-EG')}`);
            return timestamp;
          }
        }
      } catch (error) {

        //  //////console.log(`⚠️ فشل ${source.url || 'النظام'}: ${error.message}`);
      }}

    console.error('❌ فشل جلب الوقت من جميع المصادر');
    return null;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== دوال الترخيص =====
// ============================================

async function validateLicenseAfterLoading() {
  try {
    //console.log('🔐 جاري التحقق من الترخيص والوقت...');
    const internetTime = await fetchTimeFromGoogle();
    if (!internetTime) {
      console.error('❌ فشل التحقق من الوقت من الإنترنت');
      return false;
    }
    //console.log(`✅ الوقت: ${new Date(internetTime).toLocaleString('ar-EG')}`);

    const serial = await getMotherboardSerial();
    if (!serial) {
      console.error('❌ فشل الحصول على سريال الجهاز');
      return false;
    }
    //console.log(`✅ سريال الجهاز: ${serial}`);

    const check = await checkBreakExists(serial);
    if (!check.exists) {
      console.error('❌ الجهاز غير مسجل');
      return false;
    }
    //console.log(`✅ الاستراحة: ${check.breakData.name_break}`);
    //console.log(`📞 رقم الهاتف: ${check.breakData.phone_num}`);

    const license = await checkBreakLicense(check.breakData.id);
    if (!license.valid) {
      console.error(`❌ ${license.message || 'الترخيص غير صالح'}`);
      return false;
    }

    if (license.expDate) {
      const expDate = new Date(license.expDate);
      const now = new Date(internetTime);
      if (expDate < now) {
        console.error(`❌ انتهت صلاحية الترخيص في: ${expDate.toLocaleDateString('ar-EG')}`);
        return false;
      }
      const daysLeft = Math.ceil((expDate - now) / (1000 * 60 * 60 * 24));
      //console.log(`✅ الترخيص صالح حتى: ${expDate.toLocaleDateString('ar-EG')}`);
      //console.log(`📅 المتبقي: ${daysLeft} يوم`);
      if (daysLeft <= 7) {
        console.warn(`⚠️ تحذير: يتبقى ${daysLeft} أيام على انتهاء الترخيص`);
      }
    }

    // ✅ تم التحقق بنجاح - تحديث المتغيرات العالمية
    licenseValid = true;
    serverLocked = false;
    licenseCheckResult = {
      valid: true,
      serial: serial,
      breakData: check.breakData,
      license: license,
      timestamp: internetTime
    };

    // ✅ حذف صفحة انتهاء الصلاحية إذا كانت موجودة
    const expiredPage = path.join(PUBLIC_DIR, 'license-expired.html');
    if (fs.existsSync(expiredPage)) {
      try {
        fs.unlinkSync(expiredPage);
        //console.log('🗑️ تم حذف صفحة انتهاء الصلاحية');
      } catch (e) {}
    }

    //console.log('================================================');
    //console.log('✅ ✅ ✅ جميع التحقيات اجتازت بنجاح ✅ ✅ ✅');
    //console.log('================================================');
    return true;

  } catch (error) {
    console.error('❌ خطأ في التحقق:', error);
    return false;
  }
}
// ============================================
// ===== دوال إنشاء ملفات data =====
// ============================================

/**
 * التحقق من وجود مجلد data وإنشائه إذا لم يكن موجوداً
 */
function ensureDataDirectory() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      //////console.log(`📁 تم إنشاء مجلد data: ${DATA_DIR}`);
      return true;
    }
    return true;
  } catch (error) {
    console.error(`❌ فشل إنشاء مجلد data: ${error.message}`);
    return false;
  }
}

/**
 * التحقق من وجود ملف وإنشائه بقيمة افتراضية إذا لم يكن موجوداً
 * @param {string} filePath - مسار الملف
 * @param {any} defaultContent - المحتوى الافتراضي (كائن أو مصفوفة أو نص)
 * @param {boolean} isJson - هل الملف بصيغة JSON؟
 * @returns {boolean} - نجاح العملية
 */
function ensureFileExists(filePath, defaultContent = null, isJson = true) {
  try {
    // التأكد من وجود المجلد
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    // إذا كان الملف غير موجود، نقوم بإنشائه
    if (!fs.existsSync(filePath)) {
      let content;
      if (defaultContent === null) {
        // إذا لم يتم تحديد محتوى افتراضي، نستخدم محتوى مناسب حسب نوع الملف
        if (isJson) {
          content = JSON.stringify({}, null, 2);
        } else {
          content = '';
        }
      } else if (typeof defaultContent === 'string') {
        content = defaultContent;
      } else {
        content = JSON.stringify(defaultContent, null, 2);
      }

      fs.writeFileSync(filePath, content, 'utf8');
      //////console.log(`📄 تم إنشاء الملف: ${path.basename(filePath)}`);
      return true;
    }

    // التحقق من صحة الملف JSON إذا كان مطلوباً
    if (isJson) {
      try {
        const data = fs.readFileSync(filePath, 'utf8');
        if (!data || data.trim() === '') {
          // الملف فارغ - نعيد إنشائه
          const content = defaultContent !== null ?
          typeof defaultContent === 'string' ? defaultContent : JSON.stringify(defaultContent, null, 2) :
          JSON.stringify({}, null, 2);
          fs.writeFileSync(filePath, content, 'utf8');
          //////console.log(`🔄 تم إعادة إنشاء الملف الفارغ: ${path.basename(filePath)}`);
          return true;
        }
        JSON.parse(data);
      } catch (e) {
        // الملف تالف - نعيد إنشائه
        console.warn(`⚠️ الملف ${path.basename(filePath)} تالف، جاري إعادة إنشائه...`);
        const content = defaultContent !== null ?
        typeof defaultContent === 'string' ? defaultContent : JSON.stringify(defaultContent, null, 2) :
        JSON.stringify({}, null, 2);
        fs.writeFileSync(filePath, content, 'utf8');
        //////console.log(`🔄 تم إعادة إنشاء الملف التالف: ${path.basename(filePath)}`);
        return true;
      }
    }

    return true;
  } catch (error) {
    console.error(`❌ فشل التحقق من الملف ${path.basename(filePath)}: ${error.message}`);
    return false;
  }
}

function ensureAllDataFiles() {try {
    ////console.log('\n📂 ================================================');
    ////console.log('📂 جاري التحقق من ملفات البيانات...');
    ////console.log('📂 ================================================\n');

    // 1. التأكد من وجود مجلد data
    if (!ensureDataDirectory()) {
      console.error('❌ فشل إنشاء مجلد data');
      return false;
    }

    // 2. تعريف جميع الملفات مع محتوياتها الافتراضية
    const filesToEnsure = [
    {
      path: CONFIG_FILE,
      defaultContent: {
        categories: [],
        defaultCategory: null,
        port: 3000
      },
      isJson: true
    },
    {
      path: RESTRICTIONS_FILE,
      defaultContent: {
        downloadBlocked: [],
        pathRestrictions: []
      },
      isJson: true
    },
    {
      path: CHANNELS_FILE,
      defaultContent: [
      {
        id: 'channel_' + Date.now() + '_1',
        name: 'القناة الأولى',
        url: 'https://example.com/stream.m3u8',
        description: 'قناة عامة',
        category: 'عامة',
        enabled: true,
        createdAt: Date.now(),
        views: 0
      }],

      isJson: true
    },
    {
      path: EXCLUSIVE_FILE,
      defaultContent: [],
      isJson: true
    },
    {
      path: USERS_FILE,
      defaultContent: [
      {
        id: 'admin',
        username: 'admin',
        password: 'admin123',
        role: 'admin',
        created: Date.now(),
        lastLogin: null,
        updatedAt: null
      }],

      isJson: true
    },
    {
      path: INFO_FILE,
      defaultContent: {
        name: '🏠 استراحة الشبكة',
        description: 'مرحباً بكم في استراحة العائلة - وجهتكم المفضلة للاسترخاء والترفيه',
        phone: '📞 774452081',
        whatsapp: '📱 774452081',
        email: '📧 info@example.com',
        socialMedia: {
          facebook: '',
          instagram: '',
          twitter: '',
          youtube: ''
        },
        updatedAt: Date.now()
      },
      isJson: true
    },
    {
      path: MESSAGES_FILE,
      defaultContent: {},
      isJson: true
    },
    {
      path: WATCH_HISTORY_FILE,
      defaultContent: {},
      isJson: true
    },
    {
      path: BACKUP_FILE,
      defaultContent: {
        timestamp: Date.now(),
        version: '1.0',
        data: {}
      },
      isJson: true
    },
    {
      path: SYNC_CACHE_FILE,
      defaultContent: {
        categories: {},
        lastSync: null,
        totalFiles: 0,
        totalPosters: 0,
        categoriesCount: 0,
        foldersScanned: 0,
        categoriesWithFiles: 0,
        maxDepth: 10
      },
      isJson: true
    },
    {
      path: SPEED_CONFIG_FILE,
      defaultContent: {
        defaultSpeed: 1,
        maxSpeed: 100,
        enabled: false,
        totalBandwidthLimit: 0
      },
      isJson: true
    },
    // ===== الملفات الجديدة =====
    {
  path: CONVERSION_CONFIG_FILE,
  defaultContent: {
    enabled: true,
    preserveOriginal: true,
    quality: "low",  // ✅ تغيير إلى low لتقليل الجودة
    videoCodec: "libx264",
    audioCodec: "aac",
    videoBitrate: "400k",    // ✅ تقليل معدل البت للفيديو (من 8000k إلى 400k)
    audioBitrate: "64k",     // ✅ تقليل معدل البت للصوت (من 192k إلى 64k)
    maxWidth: 640,           // ✅ عرض 640 بكسل (360p)
    maxHeight: 360,          // ✅ ارتفاع 360 بكسل
    threads: 1,              // ✅ استخدام خيط واحد لتقليل استهلاك المعالج
    formats: [
      ".avi", ".mkv", ".wmv", ".mov", ".flv",
      ".m4v", ".mpg", ".mpeg", ".3gp", ".ogv",
      ".divx", ".xvid"
    ],
    convertOnSync: false,
    maxFileSize: 0,
    autoDeleteOriginal: false,
    // ✅ إضافات جديدة للتحكم في الأداء
    preset: "ultrafast",     // أسرع إعداد
    crf: 30,                 // جودة منخفضة (0-51, أعلى = جودة أقل)
    tune: "fastdecode",      // تحسين لفك الترميز السريع
    profile: "baseline",     // أبسط ملف تعريف
    level: "3.0",           // مستوى منخفض للتوافق
    maxrate: "500k",        // الحد الأقصى لمعدل البت
    bufsize: "1000k"        // حجم المخزن المؤقت
  },
  isJson: true
},
    {
      path: SCAN_RESULTS_FILE,
      defaultContent: {
        totalFiles: 0,
        totalFolders: 0,
        totalDrives: 0,
        activeDrives: 0,
        filesByFormat: {},
        drives: [],
        files: [],
        scannedAt: null,
        errors: []
      },
      isJson: true
    },
    {
      path: METADATA_CACHE_FILE,
      defaultContent: {},
      isJson: true
    },
    {
      path: FOLDER_IMAGES_CACHE_FILE,
      defaultContent: {},
      isJson: true
    }];


    // 3. إنشاء جميع الملفات
    let successCount = 0;
    let failCount = 0;

    for (const file of filesToEnsure) {
      try {
        const result = ensureFileExists(file.path, file.defaultContent, file.isJson);
        if (result) {
          successCount++;
        } else {
          failCount++;
        }
      } catch (error) {
        console.error(`❌ خطأ في إنشاء الملف ${path.basename(file.path)}:`, error);
        failCount++;
      }
    }

    // 4. إنشاء المجلدات الفرعية للصور
    const imageDirs = [
    path.join(DATA_DIR, 'public'),
    path.join(DATA_DIR, 'public', 'category-images'),
    path.join(DATA_DIR, 'public', 'path-images'),
    path.join(DATA_DIR, 'public', 'channel-images'),
    path.join(DATA_DIR, 'public', 'exclusive-images')];


    for (const dir of imageDirs) {
      if (!fs.existsSync(dir)) {
        try {
          fs.mkdirSync(dir, { recursive: true });
          ////console.log(`📁 تم إنشاء المجلد: ${path.relative(DATA_DIR, dir)}`);
        } catch (error) {
          console.error(`❌ فشل إنشاء المجلد ${dir}:`, error);
        }
      }
    }

    ////console.log('\n📂 ================================================');
    ////console.log(`📂 ✅ تم التحقق من ${successCount} ملف بنجاح`);
    if (failCount > 0) {

      ////console.log(`📂 ❌ فشل في ${failCount} ملف`);
    } ////console.log('📂 ================================================\n');

    return failCount === 0;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}
// ============================================
// ===== إعدادات التحديث - الدوال المفقودة =====
// ============================================



// ============================================
// ===== مسارات التحديث =====
// ============================================



// ============================================
// ===== تحميل/حفظ إعدادات التحديث =====
// ============================================

function loadUpdateConfig() {
  try {
    if (fs.existsSync(UPDATE_CONFIG_FILE)) {
      const data = fs.readFileSync(UPDATE_CONFIG_FILE, 'utf8');
      if (data && data.trim()) {
        return { ...DEFAULT_UPDATE_CONFIG, ...JSON.parse(data) };
      }
    }
  } catch (error) {
    console.error('❌ خطأ في تحميل إعدادات التحديث:', error);
  }
  return { ...DEFAULT_UPDATE_CONFIG };
}

function saveUpdateConfig(config) {
  try {
    fs.writeFileSync(UPDATE_CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ إعدادات التحديث:', error);
    return false;
  }
}

// ============================================
// ===== التحقق من التحديثات (GitHub Releases) =====
// ============================================

async function checkForUpdates() {
  try {
    const url = updateConfig.updateServerUrl;
    if (!url) {
      return { success: false, error: 'لم يتم تكوين سيرفر التحديثات' };
    }

    const response = await axios.get(url, {
      timeout: 15000,
      headers: {
        'User-Agent': `ZainServer/${getCurrentVersion()}`,
        'Accept': 'application/vnd.github+json'
      }
    });

    // GitHub Releases API
    const releases = Array.isArray(response.data) ? response.data : (response.data.versions || []);
    const currentVersion = getCurrentVersion();

    const versions = releases.map(r => ({
      version: (r.tag_name || r.version || '').replace(/^v/, ''),
      name: r.name || r.tag_name || '',
      changelog: r.body || r.changelog || '',
      releaseDate: r.published_at || r.releaseDate || null,
      downloadUrl: (r.assets && r.assets[0] && r.assets[0].browser_download_url) || r.downloadUrl || '',
      size: (r.assets && r.assets[0] && r.assets[0].size) || r.size || 0,
      prerelease: r.prerelease || false
    })).filter(v => v.version && v.downloadUrl);

    // فلترة الإصدارات الأحدث
    let newerVersions = versions.filter(v => 
      compareVersions(v.version, currentVersion) > 0
    );

    // تجاهل الإصدارات التجريبية إذا كان مطلوباً
    if (updateConfig.onlyStableReleases) {
      newerVersions = newerVersions.filter(v => !v.prerelease);
    }

    // تجاهل الإصدارات في skipVersions
    if (updateConfig.skipVersions && updateConfig.skipVersions.length > 0) {
      newerVersions = newerVersions.filter(v => 
        !updateConfig.skipVersions.includes(v.version)
      );
    }

    // ترتيب تنازلي
    newerVersions.sort((a, b) => compareVersions(b.version, a.version));

    updateConfig.lastCheck = Date.now();
    saveUpdateConfig(updateConfig);

    return {
      success: true,
      hasUpdate: newerVersions.length > 0,
      currentVersion,
      latestVersion: newerVersions[0]?.version || null,
      availableVersions: newerVersions,
      allVersions: versions
    };
  } catch (error) {
    console.error('❌ خطأ في التحقق من التحديثات:', error.message);
    return { success: false, error: error.message };
  }
}

// ============================================
// ===== تنزيل التحديث إلى updates/ =====
// ============================================

async function downloadUpdate(version, downloadUrl) {
  if (isDownloading) {
    return { success: false, error: 'جاري التنزيل بالفعل' };
  }

  isDownloading = true;
  downloadProgress = 0;

  try {
    // ✅ تأكد من وجود مجلد updates
    if (!fs.existsSync(UPDATES_DIR)) {
      fs.mkdirSync(UPDATES_DIR, { recursive: true });
    }

    const zipPath = path.join(UPDATES_DIR, `update-${version}.zip`);

    console.log(`📥 تنزيل التحديث ${version} من ${downloadUrl}`);

    const response = await axios({
      method: 'GET',
      url: downloadUrl,
      responseType: 'stream',
      timeout: 300000,
      maxRedirects: 5,
      headers: {
        'User-Agent': `ZainServer/${getCurrentVersion()}`,
        'Accept': 'application/octet-stream'
      }
    });

    const totalSize = parseInt(response.headers['content-length'] || '0');
    let downloadedSize = 0;

    const writer = fs.createWriteStream(zipPath);
    response.data.on('data', (chunk) => {
      downloadedSize += chunk.length;
      if (totalSize > 0) {
        downloadProgress = Math.round((downloadedSize / totalSize) * 100);
      }
    });

    response.data.pipe(writer);

    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });

    console.log(`✅ تم تنزيل ${zipPath} (${(downloadedSize / 1024 / 1024).toFixed(2)} MB)`);

    // ✅ حفظ الإصدار في current.version
    fs.writeFileSync(path.join(UPDATES_DIR, 'current.version'), version, 'utf8');

    // ✅ استخراج الملفات من ZIP إلى updates/ مباشرة
    console.log('📦 استخراج الملفات...');
    await extractZipToUpdates(zipPath);

    isDownloading = false;
    downloadProgress = 100;

    return { success: true, version, zipPath };

  } catch (error) {
    isDownloading = false;
    downloadProgress = 0;
    console.error('❌ فشل تنزيل التحديث:', error.message);
    return { success: false, error: error.message };
  }
}

// ============================================
// ===== استخراج ZIP إلى updates/ =====
// ============================================

async function extractZipToUpdates(zipPath) {
  const { execSync } = require('child_process');

  try {
    // ✅ حذف المحتوى القديم (مع الاحتفاظ بـ current.version والـ zip)
    const filesToKeep = ['current.version', path.basename(zipPath)];
    for (const item of fs.readdirSync(UPDATES_DIR)) {
      if (filesToKeep.includes(item)) continue;
      const p = path.join(UPDATES_DIR, item);
      try {
        if (fs.statSync(p).isDirectory()) {
          fs.rmSync(p, { recursive: true, force: true });
        } else {
          fs.unlinkSync(p);
        }
      } catch (e) {}
    }

    // ✅ استخراج ZIP
    if (process.platform === 'win32') {
      execSync(
        `powershell -command "Expand-Archive -Path '${zipPath}' -DestinationPath '${UPDATES_DIR}' -Force"`,
        { windowsHide: true, timeout: 120000 }
      );
    } else {
      execSync(`unzip -o "${zipPath}" -d "${UPDATES_DIR}"`, { timeout: 120000 });
    }

    console.log('✅ تم استخراج الملفات إلى updates/');

    // ✅ التحقق من وجود الملفات المطلوبة
    const requiredFiles = ['server.js', 'package.json'];
    for (const file of requiredFiles) {
      if (!fs.existsSync(path.join(UPDATES_DIR, file))) {
        console.warn(`⚠️ تحذير: ${file} غير موجود بعد الاستخراج`);
      }
    }

    // ✅ إذا كان الملفات داخل مجلد فرعي، انقلها للأعلى
    // مثال: MediaServer-v1.1.0/server.js → server.js
    await flattenUpdatesFolder();

    // ✅ حذف ملف ZIP بعد الاستخراج
    try {
      fs.unlinkSync(zipPath);
      console.log('🗑️ تم حذف ملف ZIP');
    } catch (e) {}

    return { success: true };

  } catch (error) {
    console.error('❌ فشل استخراج ZIP:', error.message);
    return { success: false, error: error.message };
  }
}

// ============================================
// ===== نقل الملفات من مجلد فرعي إلى الأعلى =====
// ============================================

async function flattenUpdatesFolder() {
  const items = fs.readdirSync(UPDATES_DIR).filter(i => i !== 'current.version');

  // إذا كان هناك مجلد واحد فقط، انقل محتواه للأعلى
  if (items.length === 1) {
    const singleItem = path.join(UPDATES_DIR, items[0]);
    if (fs.statSync(singleItem).isDirectory()) {
      console.log(`📁 نقل محتوى ${items[0]}/ إلى الأعلى...`);
      
      const innerItems = fs.readdirSync(singleItem);
      for (const item of innerItems) {
        const src = path.join(singleItem, item);
        const dest = path.join(UPDATES_DIR, item);
        try {
          if (fs.existsSync(dest)) {
            fs.rmSync(dest, { recursive: true, force: true });
          }
          fs.renameSync(src, dest);
        } catch (e) {
          // إذا فشل rename، استخدم copy + delete
          if (fs.statSync(src).isDirectory()) {
            copyDirSync(src, dest);
            fs.rmSync(src, { recursive: true, force: true });
          } else {
            fs.copyFileSync(src, dest);
            fs.unlinkSync(src);
          }
        }
      }
      
      // حذف المجلد الفارغ
      try {
        fs.rmdirSync(singleItem);
      } catch (e) {}
    }
  }
}

function copyDirSync(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  for (const item of fs.readdirSync(src)) {
    const s = path.join(src, item);
    const d = path.join(dest, item);
    if (fs.statSync(s).isDirectory()) {
      copyDirSync(s, d);
    } else {
      fs.copyFileSync(s, d);
    }
  }
}

// ============================================
// ===== التحديث التلقائي الكامل =====
// ============================================

async function performAutoUpdate(version, downloadUrl) {
  try {
    console.log(`🤖 بدء التحديث التلقائي إلى ${version}...`);

    // 1. تنزيل + استخراج إلى updates/
    const downloadResult = await downloadUpdate(version, downloadUrl);
    if (!downloadResult.success) {
      console.error('❌ فشل التنزيل:', downloadResult.error);
      return;
    }

    if (updateConfig.notifications?.notifyOnDownloadComplete) {
      sendNotification('download_complete', { version });
    }

    // 2. إنشاء نسخة احتياطية
    if (updateConfig.autoBackupBeforeUpdate) {
      console.log('💾 إنشاء نسخة احتياطية...');
      createPreUpdateBackup(version);
    }

    // 3. تشغيل launcher.exe لبناء التحديث
    console.log('🚀 تشغيل launcher.exe للبناء...');
    
    if (!fs.existsSync(LAUNCHER_EXE)) {
      throw new Error('launcher.exe غير موجود في setup');
    }

    // ✅ تشغيل launcher.exe منفصلاً
    const { spawn } = require('child_process');
    spawn(LAUNCHER_EXE, [], {
      detached: true,
      stdio: 'ignore',
      cwd: SETUP_DIR,
      windowsHide: false
    }).unref();

    console.log('✅ تم تشغيل launcher.exe - سيتم إغلاق السيرفر الحالي');

    // ✅ إغلاق السيرفر الحالي بعد ثانيتين (ليتمكن launcher من استبدال EXE)
    setTimeout(() => {
      process.exit(0);
    }, 2000);

  } catch (error) {
    console.error('❌ خطأ في التحديث التلقائي:', error);
  }
}

function scheduleAutoUpdate(version, downloadUrl) {
  const schedule = updateConfig.scheduledUpdates;
  if (!schedule?.enabled) return;

  const now = new Date();
  const [startHour, startMin] = (schedule.timeStart || '03:00').split(':').map(Number);
  const target = new Date();
  target.setHours(startHour, startMin, 0, 0);

  if (target <= now) {
    target.setDate(target.getDate() + 1);
  }

  const delay = target.getTime() - now.getTime();
  console.log(`📅 جدولة التحديث بعد ${Math.round(delay / 60000)} دقيقة`);

  if (autoUpdateTimer) clearTimeout(autoUpdateTimer);
  autoUpdateTimer = setTimeout(() => {
    performAutoUpdate(version, downloadUrl);
  }, delay);
}

async function rollbackUpdate(version) {
  try {
    const backupsDir = path.join(DATA_DIR, 'updates', 'backups');
    if (!fs.existsSync(backupsDir)) {
      return { success: false, error: 'لا توجد نسخ احتياطية' };
    }

    const backups = fs.readdirSync(backupsDir)
      .filter(f => f.startsWith(`backup_v${version}_`))
      .sort()
      .reverse();

    if (backups.length === 0) {
      return { success: false, error: `لا توجد نسخة احتياطية للإصدار ${version}` };
    }

    const backupPath = path.join(backupsDir, backups[0]);
    console.log(`🔄 التراجع من النسخة: ${backupPath}`);

    // استخراج النسخة الاحتياطية واستعادتها
    // ... (حسب هيكل النسخة الاحتياطية)

    return { success: true, version };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

function createPreUpdateBackup(version) {
  try {
    const backupsDir = path.join(DATA_DIR, 'updates', 'backups');
    if (!fs.existsSync(backupsDir)) {
      fs.mkdirSync(backupsDir, { recursive: true });
    }

    const timestamp = Date.now();
    const backupName = `backup_v${version}_${timestamp}.zip`;
    const backupPath = path.join(backupsDir, backupName);

    // نسخ الملفات المهمة
    const filesToBackup = ['server.js', 'package.json', 'dashboard.js'];
    const tempDir = path.join(DATA_DIR, 'updates', 'temp_backup');
    
    if (fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
    fs.mkdirSync(tempDir, { recursive: true });

    for (const file of filesToBackup) {
      const src = path.join(process.cwd(), file);
      if (fs.existsSync(src)) {
        fs.copyFileSync(src, path.join(tempDir, file));
      }
    }

    // ضغط باستخدام PowerShell
    const { execSync } = require('child_process');
    if (process.platform === 'win32') {
      execSync(`powershell -command "Compress-Archive -Path '${tempDir}\\*' -DestinationPath '${backupPath}' -Force"`, {
        windowsHide: true,
        timeout: 60000
      });
    }

    fs.rmSync(tempDir, { recursive: true, force: true });

    // حذف النسخ القديمة
    const keepBackups = updateConfig.keepBackups || 3;
    const allBackups = fs.readdirSync(backupsDir)
      .filter(f => f.startsWith('backup_'))
      .map(f => ({ name: f, time: fs.statSync(path.join(backupsDir, f)).mtime.getTime() }))
      .sort((a, b) => b.time - a.time);

    for (let i = keepBackups; i < allBackups.length; i++) {
      try {
        fs.unlinkSync(path.join(backupsDir, allBackups[i].name));
      } catch (e) {}
    }

    console.log(`✅ تم إنشاء نسخة احتياطية: ${backupName}`);
    return { success: true, path: backupPath };
  } catch (error) {
    console.error('❌ فشل إنشاء النسخة الاحتياطية:', error);
    return { success: false, error: error.message };
  }
}

async function prepareCache() {
  try {
    if (!fs.existsSync(CACHE_DIR)) {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
    }

    // نسخ server.js و package.json إلى cache
    const filesToCopy = ['server.js', 'package.json'];
    for (const file of filesToCopy) {
      const src = path.join(process.cwd(), file);
      if (fs.existsSync(src)) {
        fs.copyFileSync(src, path.join(CACHE_DIR, file));
      }
    }

    // نسخ public
    const publicSrc = path.join(process.cwd(), 'public');
    const publicDest = path.join(CACHE_DIR, 'public');
    if (fs.existsSync(publicSrc)) {
      if (!fs.existsSync(publicDest)) {
        fs.mkdirSync(publicDest, { recursive: true });
      }
      // نسخ بسيط
      const copyRecursive = (src, dest) => {
        for (const item of fs.readdirSync(src)) {
          const s = path.join(src, item);
          const d = path.join(dest, item);
          if (fs.statSync(s).isDirectory()) {
            if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
            copyRecursive(s, d);
          } else {
            fs.copyFileSync(s, d);
          }
        }
      };
      copyRecursive(publicSrc, publicDest);
    }

    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function startLauncher() {
  try {
    if (!fs.existsSync(LAUNCHER_EXE)) {
      throw new Error('launcher.exe غير موجود');
    }

    const { spawn } = require('child_process');
    spawn(LAUNCHER_EXE, [], {
      detached: true,
      stdio: 'ignore',
      windowsHide: false
    }).unref();

    // إغلاق السيرفر الحالي
    setTimeout(() => process.exit(0), 1000);

    return { success: true };
  } catch (error) {
    console.error('❌ فشل تشغيل launcher:', error);
    return { success: false, error: error.message };
  }
}
/**
 * إعادة تعيين جميع ملفات data (حذف وإعادة إنشاء)
 * @param {boolean} confirm - تأكيد الحذف (للأمان)
 */
function resetAllDataFiles(confirm = false) {
  if (!confirm) {
    console.warn('⚠️ تم استدعاء resetAllDataFiles بدون تأكيد. استخدم confirm: true');
    return false;
  }

  //////console.log('\n🔄 ================================================');
  //////console.log('🔄 جاري إعادة تعيين جميع ملفات البيانات...');
  //////console.log('🔄 ================================================\n');

  try {
    // حذف مجلد data بالكامل إذا كان موجوداً
    if (fs.existsSync(DATA_DIR)) {
      // حذف الملفات أولاً
      const files = fs.readdirSync(DATA_DIR);
      for (const file of files) {
        const filePath = path.join(DATA_DIR, file);
        try {
          if (fs.statSync(filePath).isDirectory()) {
            fs.rmSync(filePath, { recursive: true, force: true });
          } else {
            fs.unlinkSync(filePath);
          }
          //////console.log(`🗑️ تم حذف: ${file}`);
        } catch (e) {
          console.warn(`⚠️ فشل حذف ${file}:`, e.message);
        }
      }
    }

    // إعادة إنشاء جميع الملفات
    const result = ensureAllDataFiles();

    //////console.log('\n🔄 ================================================');
    //////console.log(result ? '✅ ✅ تم إعادة تعيين جميع الملفات بنجاح' : '❌ فشل في إعادة تعيين بعض الملفات');
    //////console.log('🔄 ================================================\n');

    return result;
  } catch (error) {
    console.error('❌ خطأ في إعادة تعيين الملفات:', error);
    return false;
  }
}

/**
 * التحقق من صحة جميع ملفات data وإصلاحها إذا لزم الأمر
 */
function validateAndRepairDataFiles() {try {
    //////console.log('\n🔧 ================================================');
    //////console.log('🔧 جاري التحقق من صحة ملفات البيانات...');
    //////console.log('🔧 ================================================\n');

    let issuesFound = 0;

    // قائمة الملفات المطلوبة
    const requiredFiles = [
    CONFIG_FILE,
    RESTRICTIONS_FILE,
    CHANNELS_FILE,
    EXCLUSIVE_FILE,
    USERS_FILE,
    INFO_FILE,
    MESSAGES_FILE,
    WATCH_HISTORY_FILE,
    SPEED_CONFIG_FILE];


    for (const filePath of requiredFiles) {
      const fileName = path.basename(filePath);

      if (!fs.existsSync(filePath)) {
        console.warn(`⚠️ الملف غير موجود: ${fileName}`);
        issuesFound++;
        continue;
      }

      try {
        const data = fs.readFileSync(filePath, 'utf8');
        if (!data || data.trim() === '') {
          console.warn(`⚠️ الملف فارغ: ${fileName}`);
          issuesFound++;
          continue;
        }

        // محاولة تحليل JSON
        JSON.parse(data);
        //////console.log(`✅ الملف صحيح: ${fileName}`);
      } catch (e) {
        console.warn(`⚠️ الملف تالف: ${fileName} - ${e.message}`);
        issuesFound++;
      }
    }

    if (issuesFound > 0) {
      //////console.log(`\n🔧 تم العثور على ${issuesFound} مشكلة، جاري الإصلاح...`);
      const result = ensureAllDataFiles();
      if (result) {

        //////console.log('✅ ✅ تم إصلاح جميع الملفات بنجاح');
      } else {console.error('❌ فشل إصلاح بعض الملفات');
      }
      return result;
    } else {
      //////console.log('\n✅ جميع الملفات سليمة');
      return true;
    }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== دالة التهيئة الكاملة =====
// ============================================

/**
 * التهيئة الكاملة للنظام (يتم استدعاؤها عند بدء التشغيل)
 */
function initializeDataSystem() {try {
    //////console.log('\n🚀 ================================================');
    //////console.log('🚀 تهيئة نظام البيانات...');
    //////console.log('🚀 ================================================\n');

    // 1. التحقق من صحة الملفات
    const isValid = validateAndRepairDataFiles();

    if (!isValid) {
      //////console.log('⚠️ بعض الملفات تحتاج إلى إعادة إنشاء...');
      const result = ensureAllDataFiles();
      if (result) {

        //////console.log('✅ تم تهيئة جميع الملفات بنجاح');
      } else {console.error('❌ فشل تهيئة الملفات');
      }
      return result;
    }

    return true;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== دالة مساعدة لحذف ملف معين =====
// ============================================

/**
 * حذف ملف data معين وإعادة إنشائه بقيمة افتراضية
 * @param {string} filePath - مسار الملف
 * @param {any} defaultContent - المحتوى الافتراضي
 * @param {boolean} isJson - هل الملف بصيغة JSON؟
 */
function resetDataFile(filePath, defaultContent = null, isJson = true) {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      //////console.log(`🗑️ تم حذف الملف: ${path.basename(filePath)}`);
    }
    const result = ensureFileExists(filePath, defaultContent, isJson);
    //////console.log(`✅ تم إعادة إنشاء الملف: ${path.basename(filePath)}`);
    return result;
  } catch (error) {
    console.error(`❌ فشل إعادة إنشاء الملف ${path.basename(filePath)}:`, error);
    return false;
  }
}

// ============================================
// ===== تصدير الدوال للاستخدام الخارجي =====
// ============================================

module.exports = {
  ensureDataDirectory,
  ensureFileExists,
  ensureAllDataFiles,
  resetAllDataFiles,
  validateAndRepairDataFiles,
  initializeDataSystem,
  resetDataFile
};
// ============================================
// ===== دوال إعادة التحقق عند عودة الإنترنت =====
// ============================================

async function checkInternetConnectivity() {
  try {
    // محاولة جلب الوقت من الإنترنت كاختبار للاتصال
    const time = await fetchTimeFromGoogle();
    if (time) {
      //////console.log('🌐 ✅ الاتصال بالإنترنت متاح');
      return true;
    }
    return false;
  } catch (error) {
    //////console.log('🌐 ❌ لا يوجد اتصال بالإنترنت');
    return false;
  }
}

async function revalidateLicense() {
  if (isRevalidateInProgress) {
    return false;
  }

  isRevalidateInProgress = true;

  try {
    const isConnected = await checkInternetConnectivity();
    if (!isConnected) {
      isRevalidateInProgress = false;
      return false;
    }

    const internetTime = await fetchTimeFromGoogle();
    if (!internetTime) {
      isRevalidateInProgress = false;
      return false;
    }

    const serial = await getMotherboardSerial();
    if (!serial) {
      isRevalidateInProgress = false;
      return false;
    }

    const check = await checkBreakExists(serial);
    if (!check.exists) {
      lockServer('الجهاز غير مسجل');
      isRevalidateInProgress = false;
      return false;
    }

    const license = await checkBreakLicense(check.breakData.id);
    if (!license.valid) {
      lockServer(license.message || 'انتهت صلاحية الترخيص');
      isRevalidateInProgress = false;
      return false;
    }

    if (license.expDate) {
      const expDate = new Date(license.expDate);
      const now = new Date(internetTime);
      if (expDate < now) {
        lockServer(`انتهت صلاحية الترخيص في ${expDate.toLocaleDateString('ar-EG')}`);
        isRevalidateInProgress = false;
        return false;
      }
    }

    // ✅ تم التحقق بنجاح
    if (serverLocked) {
      //console.log('🔓 ✅ تم فتح السيرفر بعد عودة الاتصال');
      serverLocked = false;
      licenseValid = true;
      licenseCheckResult = {
        valid: true,
        serial: serial,
        breakData: check.breakData,
        license: license,
        timestamp: internetTime
      };

      // ✅ حذف صفحة انتهاء الصلاحية
      const expiredPage = path.join(PUBLIC_DIR, 'license-expired.html');
      if (fs.existsSync(expiredPage)) {
        try {
          fs.unlinkSync(expiredPage);
          //console.log('🗑️ تم حذف صفحة انتهاء الصلاحية');
        } catch (e) {}
      }

      lastSuccessfulCheck = Date.now();
      reconnectAttempts = 0;
      isRevalidateInProgress = false;
      return true;
    } else {
      licenseValid = true;
      licenseCheckResult = {
        valid: true,
        serial: serial,
        breakData: check.breakData,
        license: license,
        timestamp: internetTime
      };
      lastSuccessfulCheck = Date.now();
      reconnectAttempts = 0;
      isRevalidateInProgress = false;
      return true;
    }

  } catch (error) {
    console.error('❌ خطأ في إعادة التحقق:', error);
    isRevalidateInProgress = false;
    return false;
  }
}

async function monitorConnectivityAndRevalidate() {
  if (isCheckingConnectivity) return;
  isCheckingConnectivity = true;

  try {
    ////console.log('🔍 فحص الاتصال بالإنترنت وإعادة التحقق...');

    const isConnected = await checkInternetConnectivity();

    if (!isConnected) {
      isCheckingConnectivity = false;
      if (serverLocked) {
        reconnectAttempts++;
      }
      return;
    }

    const result = await revalidateLicense();

    if (result) {
      //console.log('✅ ✅ تم إعادة التحقق بنجاح');
      reconnectAttempts = 0;

      // ✅ إذا كان السيرفر مقفلاً وتم فتحه، نعيد توجيه العميل إلى الصفحة الرئيسية
      if (!serverLocked) {


        // هذا سيؤثر على الطلبات الجديدة، لكن الطلبات الحالية ستحتاج إلى إعادة توجيه
        //console.log('🔄 السيرفر أصبح مفتوحاً، جاري توجيه المستخدمين إلى الصفحة الرئيسية');
      }} else {if (serverLocked) {
        reconnectAttempts++;
      }
    }

  } catch (error) {
    console.error('❌ خطأ في مراقبة الاتصال:', error);
  } finally {
    isCheckingConnectivity = false;
  }
}

// ============================================
// ===== دوال الترخيص المعدلة =====
// ============================================

function lockServer(reason = 'غير محدد') {try {
    if (serverLocked) return;
    serverLocked = true;
    licenseValid = false;

    ////console.log('================================================');
    // //console.log('🔒 جاري قفل السيرفر...');
    // //console.log(`📌 السبب: ${reason}`);
    // //console.log('================================================');

    createLicenseExpiredPage(reason);

    // ✅ بدء مراقبة الاتصال لإعادة التحقق تلقائياً
    if (!reconnectInterval) {
      //   //console.log('🔄 بدء مراقبة الاتصال بالإنترنت لإعادة التحقق...');
      reconnectInterval = setInterval(monitorConnectivityAndRevalidate, CONNECTIVITY_CHECK_INTERVAL);
    }

    // //console.log('🔒 السيرفر مقفل - يسمح فقط بصفحة انتهاء الصلاحية');
    // //console.log(`🌐 http://localhost:${getPortFromConfig()}/license-expired.html`);
    // //console.log('================================================');
  } catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}

async function checkLicensePeriodically() {
  try {
    //////console.log('🔍 جاري التحقق الدوري من الصلاحية...');

    // أولاً: التحقق من الاتصال بالإنترنت
    const isConnected = await checkInternetConnectivity();
    if (!isConnected) {
      //////console.log('⏳ لا يوجد اتصال بالإنترنت، تأجيل التحقق...');

      // إذا كان السيرفر مفتوحاً ولكن لا يوجد إنترنت، نحتفظ بالحالة الحالية
      // ولا نقفل السيرفر لمجرد فقدان الشبكة
      return;
    }

    // ✅ الإنترنت متصل - نكمل التحقق
    const internetTime = await fetchTimeFromGoogle();
    if (!internetTime) {
      console.error('❌ فشل جلب الوقت من الإنترنت للتحقق');
      return;
    }

    const serial = await getMotherboardSerial();
    if (!serial) {
      console.error('❌ فشل الحصول على سريال الجهاز');
      return;
    }

    const check = await checkBreakExists(serial);
    if (!check.exists) {
      console.error('❌ الجهاز غير مسجل');
      lockServer('الجهاز غير مسجل');
      return;
    }

    const license = await checkBreakLicense(check.breakData.id);
    if (!license.valid) {
      console.error(`❌ ${license.message || 'الترخيص غير صالح'}`);
      lockServer(license.message || 'انتهت صلاحية الترخيص');
      return;
    }

    if (license.expDate) {
      const expDate = new Date(license.expDate);
      const now = new Date(internetTime);

      if (expDate < now) {
        console.error(`❌ انتهت صلاحية الترخيص في: ${expDate.toLocaleDateString('ar-EG')}`);
        lockServer(`انتهت صلاحية الترخيص في ${expDate.toLocaleDateString('ar-EG')}`);
        return;
      }

      const daysLeft = Math.ceil((expDate - now) / (1000 * 60 * 60 * 24));

      if (daysLeft <= 7 && daysLeft > 0) {
        console.warn(`⚠️ تحذير: يتبقى ${daysLeft} أيام على انتهاء الترخيص`);
      }

      // ✅ إذا كان السيرفر مقفلاً ولكن الترخيص صالح، افتحه
      if (serverLocked) {
        //////console.log('🔓 ✅ الترخيص صالح، جاري فتح السيرفر...');
        serverLocked = false;
        licenseValid = true;

        // إزالة صفحة انتهاء الصلاحية
        const expiredPage = path.join(PUBLIC_DIR, 'license-expired.html');
        if (fs.existsSync(expiredPage)) {
          try {
            fs.unlinkSync(expiredPage);
            //////console.log('🗑️ تم حذف صفحة انتهاء الصلاحية');
          } catch (e) {}
        }
      }

      licenseValid = true;
      licenseCheckResult = {
        valid: true,
        serial: serial,
        breakData: check.breakData,
        license: license,
        timestamp: internetTime
      };

      //////console.log(`✅ الترخيص صالح حتى: ${expDate.toLocaleDateString('ar-EG')} (${daysLeft} يوم متبقي)`);
      lastSuccessfulCheck = Date.now();
    }

  } catch (error) {
    console.error('❌ خطأ في التحقق الدوري:', error);
  }
}

function startConnectivityMonitoring() {try {
    // التحقق فوراً عند بدء التشغيل
    setTimeout(() => {try {
        monitorConnectivityAndRevalidate();} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    }, 5000);

    // التحقق الدوري كل 30 ثانية
    if (!reconnectInterval) {
      reconnectInterval = setInterval(monitorConnectivityAndRevalidate, CONNECTIVITY_CHECK_INTERVAL);
      //////console.log(`🔄 بدأ مراقبة الاتصال (كل ${CONNECTIVITY_CHECK_INTERVAL / 1000} ثانية)`);
    }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

function startLicenseMonitoring() {try {
    if (licenseCheckInterval) {
      clearInterval(licenseCheckInterval);
    }

    // التحقق الدوري كل 5 دقائق (بدلاً من 100000 مللي)
    const CHECK_INTERVAL = 5 * 60 * 1000; // 5 دقائق
    licenseCheckInterval = setInterval(checkLicensePeriodically, CHECK_INTERVAL);
    //////console.log(`🔄 بدأ التحقق الدوري للصلاحية (كل ${CHECK_INTERVAL / 60000} دقيقة)`);

    // بدء مراقبة الاتصال
    startConnectivityMonitoring();

    // التحقق الأولي بعد 5 ثواني
    setTimeout(checkLicensePeriodically, 5000);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

function createLicenseExpiredPage(reason = 'غير محدد') {
  try {
    const expiredHtml = `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔑 انتهت صلاحية الترخيص</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; }
        body {
            background: linear-gradient(135deg, #0a0a1a, #1a1a2e);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 50px 40px;
            max-width: 600px;
            width: 100%;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.1);
            box-shadow: 0 30px 80px rgba(0,0,0,0.5);
        }
        .icon { font-size: 80px; display: block; margin-bottom: 20px; }
        h1 { color: #e74c3c; font-size: 28px; margin-bottom: 15px; }
        p { color: #a8b2d1; font-size: 16px; line-height: 1.8; margin-bottom: 10px; }
        .reason {
            background: rgba(231, 76, 60, 0.1);
            padding: 15px 20px;
            border-radius: 12px;
            border-right: 4px solid #e74c3c;
            margin: 20px 0;
            text-align: right;
            color: #e74c3c;
            font-size: 14px;
        }
        .status-box {
            background: rgba(255,255,255,0.03);
            padding: 15px 20px;
            border-radius: 12px;
            margin: 15px 0;
            border: 1px solid rgba(255,255,255,0.05);
        }
        .status-box .checking { color: #f39c12; }
        .status-box .connected { color: #2ecc71; }
        .status-box .failed { color: #e74c3c; }
        .btn {
            display: inline-block;
            padding: 14px 40px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            margin-top: 10px;
        }
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
        }
        .btn-secondary {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .btn-secondary:hover {
            background: rgba(255,255,255,0.1);
        }
        .footer { margin-top: 30px; color: rgba(255,255,255,0.2); font-size: 12px; }
        .reconnect-btn {
            margin-top: 10px;
            padding: 8px 20px;
            background: rgba(102, 126, 234, 0.15);
            border: 1px solid rgba(102, 126, 234, 0.2);
            border-radius: 20px;
            color: #8892b0;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s ease;
        }
        .reconnect-btn:hover {
            background: rgba(102, 126, 234, 0.25);
            color: #ccd6f6;
        }
        .btn-group {
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <span class="icon">🔑</span>
        <h1>${serverLocked && !licenseValid ? '⚠️ انقطع الاتصال بالإنترنت' : '❌ انتهت صلاحية الترخيص'}</h1>
        <p>${serverLocked && !licenseValid ? 'لا يمكن التحقق من صلاحية الترخيص بسبب انقطاع الاتصال بالإنترنت.' : 'عذراً، انتهت صلاحية ترخيص هذا السيرفر.'}</p>
        <p style="color: #8892b0; font-size: 14px;">${serverLocked && !licenseValid ? 'يرجى التحقق من اتصال الإنترنت لإعادة التحقق تلقائياً.' : 'يرجى تجديد الترخيص لمواصلة استخدام الخدمة.'}</p>
        <div class="reason">
            <strong>📌 السبب:</strong><br>
            ${reason}
        </div>
        <div class="status-box" id="statusBox">
            <span id="statusText" class="checking">🔄 جاري محاولة إعادة الاتصال...</span>
        </div>
        <div class="btn-group">
            <button class="reconnect-btn" onclick="manualReconnect()">🔄 محاولة إعادة التحقق</button>
             </div>
        <div class="footer">نظام إدارة الترخيص v1.0</div>
    </div>
    <script>
        let reconnectCheckInterval = null;
        let checkAttempts = 0;
        const MAX_ATTEMPTS = 3;
        
        function updateStatus(status, message) {
            const el = document.getElementById('statusText');
            if (!el) return;
            const statusMap = {
                'checking': '<span class="checking">🔄</span> جاري المحاولة...',
                'connected': '<span class="connected">✅</span> تم إعادة الاتصال! جاري التوجيه...',
                'failed': '<span class="failed">❌</span> فشل إعادة الاتصال',
                'waiting': '<span class="checking">⏳</span> انتظار عودة الإنترنت...'
            };
            el.innerHTML = statusMap[status] || message;
        }
        
        async function manualReconnect() {
            updateStatus('checking', 'جاري محاولة إعادة التحقق...');
            try {
                const response = await fetch('/api/system/check-connection');
                const data = await response.json();
                if (data.success && data.revalidateResult) {
                    updateStatus('connected', '✅ تم إعادة الاتصال! جاري التوجيه...');
                    // ✅ التحقق من الوجهة المناسبة
                    setTimeout(() => {
                        // محاولة التوجيه إلى الصفحة التي كان المستخدم فيها
                        const returnUrl = localStorage.getItem('returnUrl') || '/';
                        window.location.href = returnUrl;
                    }, 1500);
                } else {
                    updateStatus('failed', '❌ فشل إعادة التحقق، يرجى المحاولة مرة أخرى أو تجديد الترخيص');
                    checkAttempts++;
                    if (checkAttempts < MAX_ATTEMPTS) {
                        setTimeout(manualReconnect, 5000);
                    }
                }
            } catch (error) {
                updateStatus('failed', '❌ لا يمكن الاتصال بالسيرفر');
                checkAttempts++;
                if (checkAttempts < MAX_ATTEMPTS) {
                    setTimeout(manualReconnect, 5000);
                }
            }
        }
        
        // ✅ محاولة إعادة التحقق التلقائية كل 5 ثواني
        function startAutoReconnect() {
            reconnectCheckInterval = setInterval(() => {
                manualReconnect();
            }, 5000);
        }
        
        // ✅ محاولة فورية
        setTimeout(manualReconnect, 2000);
        
        // ✅ بدء التحقق التلقائي
        startAutoReconnect();
        
        // ✅ حفظ عنوان الصفحة التي كان المستخدم فيها للعودة إليها بعد التحقق
        localStorage.setItem('returnUrl', window.location.pathname);
        
        // ✅ إيقاف التحقق عند مغادرة الصفحة
        window.addEventListener('beforeunload', function() {
            if (reconnectCheckInterval) {
                clearInterval(reconnectCheckInterval);
            }
        });
    </script>
</body>
</html>
        `;

    const expiredPagePath = path.join(PUBLIC_DIR, 'license-expired.html');
    fs.writeFileSync(expiredPagePath, expiredHtml, 'utf8');
    //console.log(`📄 تم إنشاء صفحة انتهاء الصلاحية: ${expiredPagePath}`);

  } catch (error) {
    console.error('❌ خطأ في إنشاء صفحة انتهاء الصلاحية:', error);
  }
}

// ============================================
// ===== دوال سرعة التحميل =====
// ============================================
function getUserSpeed(identifier) {try {
    if (!speedConfig.enabled) return 0;
    let baseSpeed = speedConfig.defaultSpeed || 1;
    if (userSpeedLimits.has(identifier)) {
      baseSpeed = userSpeedLimits.get(identifier);
    }
    // تأكد من أن السرعة لا تتجاوز maxSpeed
    baseSpeed = Math.min(baseSpeed, speedConfig.maxSpeed);
    return Math.max(0.1, baseSpeed);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}
/**
 * دالة لبث ملف مع تقييد السرعة (Throttling) وتتبع التقدم.
 * @param {ReadableStream} readStream - مصدر البيانات (مثل fs.createReadStream).
 * @param {Express.Response} res - كائن الاستجابة من Express.
 * @param {number} speedMBps - السرعة المطلوبة بالميجابايت/ثانية.
 * @param {number} totalSize - الحجم الكلي للملف (للنسبة المئوية).
 * @param {string} sessionId - معرف الجلسة لتحديث التقدم.
 */
function throttleStream(readStream, res, speedMBps, totalSize, sessionId) {try {
    // ✅ حجم القطعة المناسب لضمان دقة السرعات المنخفضة (256 كيلوبايت)
    const chunkSize = 256 * 1024; // 256 KB

    // ✅ التحقق من تفعيل التقييد مع تجنب ReferenceError
    // إذا لم تُعرف speedConfig، نفترض أن التقييد مفعّل إذا كانت السرعة > 0
    const isThrottlingEnabled = typeof speedConfig !== 'undefined' && speedConfig.enabled || speedMBps > 0;

    if (!isThrottlingEnabled) {
      // إذا لم يكن التقييد مفعّلاً، استخدم البث المباشر (بدون تأخير)
      return streamWithBuffer(readStream, res);
    }

    // ✅ حساب التأخير المناسب لكل قطعة (بالمللي ثانية)
    const bytesPerSecond = speedMBps * 512 * 512; // بايت/ثانية
    const delayPerChunk = Math.ceil(chunkSize / bytesPerSecond * 1000);

    // ✅ إزالة الحد الأقصى 300 مللي (أو يمكنك تركه مع رفع القيمة إلى 5000)
    // نختار عدم وضع حد أعلى للحفاظ على دقة السرعة، لكن يمكنك إضافة حد لحماية الخادم
    const actualDelay = Math.min(delayPerChunk, 5000);

    //console.log(`📊 سرعة التحميل: ${speedMBps} MB/s, chunkSize: ${chunkSize} بايت, تأخير: ${actualDelay} مللي`);

    let bytesSent = 0;
    let buffer = [];
    let bufferSize = 0;
    let isEnded = false;
    let isPaused = false;

    // دالة لإفراغ المخزن المؤقت وإرسال البيانات
    function flushBuffer() {
      if (buffer.length === 0) return;
      try {
        const data = Buffer.concat(buffer);
        res.write(data);
        buffer = [];
        bufferSize = 0;
      } catch (err) {
        console.error('❌ خطأ في إرسال البيانات:', err);
        if (!readStream.destroyed) {
          readStream.destroy();
        }
      }
    }

    // معالجة وصول البيانات من المصدر
    readStream.on('data', (chunk) => {try {
        if (isEnded || res.writableEnded) {
          if (!readStream.destroyed) readStream.destroy();
          return;
        }

        // إيقاف المصدر مؤقتاً للتحكم في السرعة
        readStream.pause();
        isPaused = true;

        // تجميع البيانات في المخزن المؤقت
        buffer.push(chunk);
        bufferSize += chunk.length;
        bytesSent += chunk.length;

        // تحديث تقدم التحميل (إذا وُجد sessionId)
        if (sessionId && typeof updateSessionProgress === 'function') {
          updateSessionProgress(sessionId, chunk.length, totalSize);
        }

        // إذا وصل المخزن إلى الحجم المطلوب، أرسل البيانات فوراً
        if (bufferSize >= chunkSize) {
          flushBuffer();
        }

        // الانتظار لمدة التأخير المحسوبة ثم استئناف المصدر
        setTimeout(() => {try {
            if (!isEnded && !res.writableEnded && !readStream.destroyed) {
              readStream.resume();
              isPaused = false;
            }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        }, actualDelay);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // عند انتهاء المصدر من القراءة
    readStream.on('end', () => {try {
        isEnded = true;
        flushBuffer(); // إرسال أي بيانات متبقية في المخزن
        if (!res.writableEnded) {
          try {res.end();} catch (e) {/* تجاهل */}
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // عند حدوث خطأ في المصدر
    readStream.on('error', (err) => {try {
        console.error('❌ خطأ في البث المحدد:', err);
        isEnded = true;
        if (!res.headersSent) {
          res.status(500).json({ error: 'فشل تشغيل الملف' });
        } else {
          try {
            flushBuffer();
            if (!res.writableEnded) res.end();
          } catch (e) {/* تجاهل */}
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // عند إغلاق الاتصال من طرف العميل
    res.on('close', () => {try {
        isEnded = true;
        if (!readStream.destroyed) {
          readStream.destroy();
        }
        buffer = [];
        bufferSize = 0;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// التحقق من التحديثات (مع دعم التحديث التلقائي)
app.get('/api/updates/check', async (req, res) => {
  try {
    const result = await checkForUpdates();
    
    if (result.success && result.hasUpdate) {
      // إشعار بالتحديث الجديد
      if (updateConfig.notifications?.notifyOnNewVersion) {
        sendNotification('new_version_available', {
          version: result.latestVersion,
          message: `يتوفر إصدار جديد: ${result.latestVersion}`,
          changelog: result.availableVersions[0]?.changelog
        });
      }

      // التحديث التلقائي الكامل
      if (updateConfig.autoDownload && result.availableVersions[0]) {
        const latestVersion = result.availableVersions[0];
        
        console.log('🤖 التحديث التلقائي مفعل');
        
        // إذا كان هناك جدولة، جدول التحديث
        if (updateConfig.scheduledUpdates?.enabled) {
          console.log('📅 الجدولة مفعلة - جدولة التحديث');
          scheduleAutoUpdate(latestVersion.version, latestVersion.downloadUrl);
        } else {
          // تنفيذ فوري
          console.log('⚡ تنفيذ التحديث التلقائي فوراً');
          performAutoUpdate(latestVersion.version, latestVersion.downloadUrl);
        }
      }
    }
    
    res.json(result);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});
// ============================================
// ===== بث الملفات مع دعم التحميل المسبق ومعالجة Range =====
// ============================================

/**
 * دالة بث الملفات مع دعم التحميل (Download) وتقييد السرعة ومعالجة Range
 * @param {string} fullPath - المسار الكامل للملف
 * @param {Request} req - كائن الطلب
 * @param {Response} res - كائن الاستجابة
 * @param {boolean} isDownload - هل هو طلب تحميل (true) أم تشغيل عادي؟
 * @param {string} pathId - معرف المسار (للمنع) - يُمرر من المسار الرئيسي
 */
function streamFile(fullPath, req, res, isDownload = false, pathId = null) {
  try {
    // التحقق من وجود الملف
    if (!fs.existsSync(fullPath)) {
      console.error(`❌ الملف غير موجود: ${fullPath}`);
      if (!res.headersSent) {
        res.status(404).json({ error: 'الملف غير موجود' });
      }
      return;
    }

    const stat = fs.statSync(fullPath);
    const fileSize = stat.size;
    const mimeType = mime.lookup(fullPath) || 'application/octet-stream';

    // ==== التحقق من منع التحميل (إذا كان طلب تحميل وتم تمرير pathId) ====
    if (isDownload && pathId) {
      const fileName = path.basename(fullPath);
      if (!isDownloadAllowed(pathId, fileName)) {
        console.warn(`🚫 منع التحميل: ${fileName} (pathId: ${pathId})`);
        return res.status(403).json({
          error: '🚫 تحميل هذا الملف غير مسموح به',
          code: 'DOWNLOAD_BLOCKED'
        });
      }
    }

    // الحصول على سرعة المستخدم (للتقييد)
    const userId = getUserId(req);
    const userSpeed = getUserSpeed(userId);
    const session = trackSession(req, fullPath);
    const sessionId = session?.id;

    // ==== إذا كان تحميلاً (Download) ====
    if (isDownload) {
      const fileName = encodeURIComponent(path.basename(fullPath));
      res.setHeader('Content-Type', mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Length', fileSize);
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, Content-Length');

      const fileStream = fs.createReadStream(fullPath);

      // تطبيق تحديد السرعة إذا كان مفعلاً
      if (speedConfig.enabled && userSpeed > 0) {
        throttleStream(fileStream, res, userSpeed, fileSize, sessionId);
      } else {
        fileStream.pipe(res);
      }

      fileStream.on('error', (err) => {try {
          console.error('❌ خطأ في التحميل:', err);
          if (!res.headersSent) {
            res.status(500).json({ error: 'فشل تحميل الملف' });
          }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
      });
      return;
    }

    // ==== تشغيل عادي (بث) مع دعم Range ====
    const headers = {
      'Content-Type': mimeType,
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'public, max-age=86400',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Expose-Headers': 'Content-Range, Accept-Ranges, Content-Length, Content-Type',
      'Content-Disposition': 'inline'
    };

    const range = req.headers.range;
    if (range) {
      // معالجة طلب Range
      const rangeMatch = range.match(/bytes=(\d+)-(\d*)/);
      if (!rangeMatch) {
        return sendFullFile(fullPath, fileSize, mimeType, req, res, headers, userSpeed, sessionId);
      }

      const start = parseInt(rangeMatch[1], 10);
      const end = rangeMatch[2] ? parseInt(rangeMatch[2], 10) : fileSize - 1;

      if (isNaN(start) || start < 0 || start >= fileSize || end < start) {
        // طلب غير صحيح -> إرسال 416
        res.writeHead(416, {
          'Content-Range': `bytes */${fileSize}`,
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        });
        res.end(JSON.stringify({
          error: 'Requested range not satisfiable',
          fileSize: fileSize
        }));
        return;
      }

      const safeEnd = Math.min(end, fileSize - 1);
      const chunksize = safeEnd - start + 1;

      headers['Content-Range'] = `bytes ${start}-${safeEnd}/${fileSize}`;
      headers['Content-Length'] = chunksize;

      res.writeHead(206, headers);

      const fileStream = fs.createReadStream(fullPath, { start, end: safeEnd });

      if (speedConfig.enabled && userSpeed > 0) {
        throttleStream(fileStream, res, userSpeed, fileSize, sessionId);
      } else {
        streamWithBuffer(fileStream, res);
      }

      fileStream.on('error', (err) => {try {
          console.error('❌ خطأ في البث (Range):', err);
          if (!res.headersSent) {
            res.status(500).json({ error: 'فشل تشغيل الملف' });
          } else {
            try {res.end();} catch (e) {}
          }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
      });

    } else {
      // طلب كامل الملف (بدون Range)
      sendFullFile(fullPath, fileSize, mimeType, req, res, headers, userSpeed, sessionId);
    }

  } catch (error) {
    console.error('❌ خطأ في streamFile:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: error.message });
    }
  }
}

// دالة مساعدة لإرسال الملف كاملاً (مضمنة في streamFile)
function sendFullFile(fullPath, fileSize, mimeType, req, res, headers, userSpeed, sessionId) {try {
    headers['Content-Length'] = fileSize;
    res.writeHead(200, headers);

    const fileStream = fs.createReadStream(fullPath);

    if (speedConfig.enabled && userSpeed > 0) {
      throttleStream(fileStream, res, userSpeed, fileSize, sessionId);
    } else {
      streamWithBuffer(fileStream, res);
    }

    fileStream.on('error', (err) => {try {
        console.error('❌ خطأ في البث (كامل):', err);
        if (!res.headersSent) {
          res.status(500).json({ error: 'فشل تشغيل الملف' });
        } else {
          try {res.end();} catch (e) {}
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}



// ============================================
// ===== دالة البث مع مخزن مؤقت =====
// ============================================

function streamWithBuffer(readStream, res) {try {
    const chunkSize = 512 * 1024; // 512KB
    let buffer = [];
    let bufferSize = 0;

    readStream.on('data', (chunk) => {try {
        buffer.push(chunk);
        bufferSize += chunk.length;

        if (bufferSize >= chunkSize) {
          const data = Buffer.concat(buffer);
          res.write(data);
          buffer = [];
          bufferSize = 0;
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    readStream.on('end', () => {try {
        if (buffer.length > 0) {
          res.write(Buffer.concat(buffer));
        }
        if (!res.writableEnded) {
          try {res.end();} catch (e) {}
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    readStream.on('error', (err) => {try {
        console.error('❌ خطأ في البث:', err);
        if (!res.headersSent) {
          res.status(500).json({ error: 'فشل تشغيل الملف' });
        } else {
          try {res.end();} catch (e) {}
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // ✅ التنظيف عند إغلاق الاتصال
    res.on('close', () => {try {
        if (!readStream.destroyed) {
          readStream.destroy();
        }
        buffer = [];
        bufferSize = 0;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== دوال تفعيل الفترة التجريبية =====
// ============================================

async function activateTrial(breakId) {
  try {
    if (!breakId) {
      return { success: false, error: 'معرف الاستراحة مطلوب' };
    }

    const today = new Date();
    const expDate = new Date();
    expDate.setDate(expDate.getDate() + 15);

    const trialKey = 'TRIAL-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substr(2, 6).toUpperCase();

    const { data: keyData, error: keyError } = await supabase.
    from('keys').
    insert({
      key: trialKey,
      start_date: today.toISOString().split('T')[0],
      exp_date: expDate.toISOString().split('T')[0],
      active: true,
      message: '🆓 فترة تجريبية 15 يوم'
    }).
    select().
    single();

    if (keyError) {
      console.error('❌ خطأ في إنشاء المفتاح التجريبي:', keyError);
      return { success: false, error: keyError.message };
    }

    const { error: linkError } = await supabase.
    from('break_active').
    insert({
      sub_id_name_break: breakId,
      sub_id_key: keyData.id
    });

    if (linkError) {
      console.error('❌ خطأ في ربط المفتاح التجريبي:', linkError);
      await supabase.from('keys').delete().eq('id', keyData.id);
      return { success: false, error: linkError.message };
    }

    return {
      success: true,
      data: { key: trialKey, expDate: expDate }
    };

  } catch (error) {
    console.error('❌ خطأ في تفعيل الفترة التجريبية:', error);
    return { success: false, error: error.message };
  }
}

// ============================================
// ===== دوال النسخ الاحتياطي =====
// ============================================

function createFullBackup() {
  try {
    const backup = {
      timestamp: Date.now(),
      version: '2.0',
      data: {
        // الملفات الأساسية
        info: loadInfoFromFile(),
        config: loadConfig(),
        users: loadUsersFromFile(),
        channels: loadChannelsFromFile(),
        exclusive: loadExclusiveContent(),
        speedConfig: loadSpeedConfig(),
        restrictions: loadRestrictions(),
         views: loadViews(),
        // الملفات الإضافية
        messages: loadAllMessages(),
        watchHistory: loadWatchHistory(),
        syncCache: loadSyncCache(),
        metadataCache: loadMetadataCache(),
        scanResults: loadScanResults(),
        conversionConfig: loadConversionConfig(),
        folderImagesCache: loadFolderImagesCache()
      }
    };

    fs.writeFileSync(BACKUP_FILE, JSON.stringify(backup, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في إنشاء النسخة الاحتياطية الكاملة:', error);
    return false;
  }
}

function restoreFullBackup(backupData) {
  try {
    // ✅ التأكد من وجود البيانات
    if (!backupData || typeof backupData !== 'object') {
      throw new Error('بيانات النسخة الاحتياطية غير صالحة');
    }

    const data = backupData.data || {};
    let restoredCount = 0;

    // دالة مساعدة للاستعادة مع التحقق من وجود المفتاح
    const restoreIfExists = (key, saveFunction, loadFunction) => {try {
        if (data[key] !== undefined && data[key] !== null) {
          try {
            saveFunction(data[key]);
            restoredCount++;
            console.log(`✅ تم استعادة: ${key}`);
            return true;
          } catch (err) {
            console.error(`❌ فشل استعادة ${key}:`, err);
          }
        } else {
          console.log(`ℹ️ المفتاح ${key} غير موجود في النسخة، سيتم تجاهله`);
        }
        return false;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    };

    // استعادة الملفات الأساسية
    restoreIfExists('info', saveInfoToFile, loadInfoFromFile);
    restoreIfExists('config', saveConfig, loadConfig);
    restoreIfExists('users', saveUsersToFile, loadUsersFromFile);
    restoreIfExists('channels', saveChannelsToFile, loadChannelsFromFile);
    restoreIfExists('exclusive', saveExclusiveContent, loadExclusiveContent);
    restoreIfExists('speedConfig', saveSpeedConfig, loadSpeedConfig);
    restoreIfExists('restrictions', saveRestrictions, loadRestrictions);
restoreIfExists('views', saveViews, loadViews);
    // استعادة الملفات الإضافية
    restoreIfExists('messages', saveAllMessages, loadAllMessages);
    restoreIfExists('watchHistory', saveWatchHistory, loadWatchHistory);
    restoreIfExists('syncCache', saveSyncCache, loadSyncCache);
    restoreIfExists('metadataCache', saveMetadataCache, loadMetadataCache);
    restoreIfExists('scanResults', saveScanResults, loadScanResults);
    restoreIfExists('conversionConfig', saveConversionConfig, loadConversionConfig);
    restoreIfExists('folderImagesCache', saveFolderImagesCache, loadFolderImagesCache);

    // إعادة تحميل المتغيرات العالمية
    config = loadConfig();
    users = loadUsersFromFile();
    restrictions = loadRestrictions();

    // إعادة تحميل المتغيرات الأخرى إذا لزم الأمر
    // (مثل channels, exclusiveContent, speedConfig, إلخ)
    channels = loadChannelsFromFile();
    exclusiveContent = loadExclusiveContent();
    speedConfig = loadSpeedConfig();

    console.log(`✅ تم استعادة ${restoredCount} ملف بنجاح`);
    return true;

  } catch (error) {
    console.error('❌ خطأ في استعادة النسخة الاحتياطية:', error);
    return false;
  }
}
function loadScanResults() {
  try {
    if (fs.existsSync(SCAN_RESULTS_FILE)) {
      const data = fs.readFileSync(SCAN_RESULTS_FILE, 'utf8');
      return data && data.trim() ? JSON.parse(data) : {};
    }
  } catch (e) {console.error('❌ خطأ في تحميل نتائج المسح:', e);}
  return {};
}

function loadConversionConfig() {
  try {
    if (fs.existsSync(CONVERSION_CONFIG_FILE)) {
      const data = fs.readFileSync(CONVERSION_CONFIG_FILE, 'utf8');
      return data && data.trim() ? JSON.parse(data) : {};
    }
  } catch (e) {console.error('❌ خطأ في تحميل إعدادات التحويل:', e);}
  return {};
}

function loadFolderImagesCache() {
  try {
    if (fs.existsSync(FOLDER_IMAGES_CACHE_FILE)) {
      const data = fs.readFileSync(FOLDER_IMAGES_CACHE_FILE, 'utf8');
      return data && data.trim() ? JSON.parse(data) : {};
    }
  } catch (e) {console.error('❌ خطأ في تحميل كاش صور المجلدات:', e);}
  return {};
}
function repairAllDataFiles() {
  // إصلاح config.json إذا كان به مشاكل
  try {
    const config = loadConfig();
    if (!config.categories) config.categories = [];
    saveConfig(config);
  } catch (e) {console.warn('⚠️ فشل إصلاح config:', e);}

  // إصلاح restrictions.json
  try {
    const restrictions = loadRestrictions();
    if (!restrictions.downloadBlocked) restrictions.downloadBlocked = [];
    if (!restrictions.pathRestrictions) restrictions.pathRestrictions = [];
    saveRestrictions(restrictions);
  } catch (e) {console.warn('⚠️ فشل إصلاح restrictions:', e);}

  // إصلاح users.json
  try {
    const users = loadUsersFromFile();
    if (!Array.isArray(users) || users.length === 0) {
      saveUsersToFile([{
        id: 'admin',
        username: 'admin',
        password: 'admin123',
        role: 'admin',
        created: Date.now(),
        lastLogin: null,
        updatedAt: null
      }]);
    }
  } catch (e) {console.warn('⚠️ فشل إصلاح users:', e);}

  console.log('✅ تم إصلاح ملفات البيانات الأساسية');
}
// ============================================
// ===== Middleware =====
// ============================================

function lightweightMiddleware(req, res, next) {try {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, HEAD');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range, Accept, Authorization, Origin, X-Requested-With, Cache-Control');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Accept-Ranges, Content-Length, Content-Type, Content-Disposition');

    if (licenseCheckResult) {
      req.licenseInfo = licenseCheckResult.license;
      req.breakData = licenseCheckResult.breakData;
      req.serial = licenseCheckResult.serial;
    }

    next();} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

function licenseCheckMiddleware(req, res, next) {try {
    // المسارات المستثناة (لا تحتاج ترخيص وتسمح بالوصول حتى لو كان الترخيص غير صالح)
    const exemptPaths = [
    '/setup.html',
    '/setup.js',
    '/license-expired.html',
    '/api/system/status',
    '/api/system/license-info',
    '/api/system/update-key',
    '/api/system/activate-key',
    '/api/system/renew-license',
    '/api/system/register',
    '/api/system/check-connection',
    '/api/system/connection-status',
    '/api/system/check-and-redirect',
    '/api/auth/check',
    '/favicon.ico',
    '/api/speed/',
    '/style.css',
    '/script.js',
    '/splash.html',
    '/api/folder-images/'];


    const isExempt = exemptPaths.some((path) => {try {
        if (path.endsWith('/')) {
          return req.path.startsWith(path);
        }
        return req.path === path || req.path.startsWith(path);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    if (isExempt) {
      return next();
    }

    // ✅ إذا كان الترخيص غير صالح أو السيرفر مقفل
    if (!licenseValid || serverLocked) {
      // ✅ جميع الطلبات المحمية (بما فيها login, dashboard, index) يتم توجيهها إلى license-expired.html
      // باستثناء setup.html (لأنه مستثنى) و license-expired.html نفسه
      const expiredPage = path.join(PUBLIC_DIR, 'license-expired.html');
      if (fs.existsSync(expiredPage)) {
        // إعادة توجيه إلى صفحة انتهاء الصلاحية
        return res.redirect('/license-expired.html');
      } else {
        // إذا لم توجد صفحة انتهاء الصلاحية، ننشئها ثم نعيد التوجيه
        createLicenseExpiredPage(serverLocked ? 'انقطع الاتصال بالإنترنت أو انتهت صلاحية الترخيص' : 'انتهت صلاحية الترخيص');
        return res.redirect('/license-expired.html');
      }
    }

    next();} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== البحث عن أول صورة في المجلد =====
// ============================================
function findFirstImageInFolder(folderPath) {
  try {
    if (!folderPath) return null;
    if (!fs.existsSync(folderPath)) return null;
    const stat = fs.statSync(folderPath);
    if (!stat.isDirectory()) return null;

    const imageExtensions = [
    '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp',
    '.svg', '.tiff', '.ico', '.cur', '.heic', '.heif', '.avif'];


    // ✅ قراءة جميع الملفات (بما فيها المخفية)
    const files = fs.readdirSync(folderPath);

    // البحث عن أي صورة (بما فيها المخفية)
    for (const file of files) {
      const ext = path.extname(file).toLowerCase();
      if (imageExtensions.includes(ext)) {
        const fullPath = path.join(folderPath, file);
        try {
          if (fs.statSync(fullPath).isFile()) {
            return fullPath;
          }
        } catch (e) {}
      }
    }

    // البحث في المجلدات الفرعية (بما فيها المخفية)
    for (const file of files) {
      const subPath = path.join(folderPath, file);
      try {
        if (fs.statSync(subPath).isDirectory()) {
          const result = findFirstImageInFolder(subPath);
          if (result) return result;
        }
      } catch (e) {}
    }

  } catch (error) {}
  return null;
}

function getSmartRelativePath(fullPath, drivePath) {try {
    let normalizedFull = fullPath.replace(/\\/g, '/');
    let normalizedDrive = drivePath.replace(/\\/g, '/');

    if (!normalizedDrive.endsWith('/')) {
      normalizedDrive += '/';
    }

    let relativePath = normalizedFull.replace(normalizedDrive, '');

    if (relativePath.startsWith('/')) {
      relativePath = relativePath.substring(1);
    }

    const parts = relativePath.split('/');
    const fileName = parts.pop();

    let selectedFolders = parts;

    if (parts.length > 2) {
      selectedFolders = parts.slice(0);
    }

    if (selectedFolders.length === 0) {
      return fileName;
    }

    return [...selectedFolders, fileName].join('/');} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ابحث عن هذه الدالة في server.js
function scanDirectoryForVideos(dir, categoryId, driveIndex, drivePath, depth = 0, maxDepth = 10) {
  const results = [];

  // ✅ زيادة العمق إلى 15 أو أكثر
  if (depth > maxDepth) {
    return results;
  }

  try {
    // ✅ التحقق من وجود المجلد
    if (!fs.existsSync(dir)) {
      console.log(`⚠️ المجلد غير موجود: ${dir}`);
      return results;
    }

    const stat = fs.statSync(dir);
    if (!stat.isDirectory()) {
      return results;
    }

    // ✅ استخدام withFileTypes لتجنب statSync المتكرر
    const items = fs.readdirSync(dir, { withFileTypes: true });

    const videoExtensions = [
      '.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm',
      '.m4v', '.mpg', '.mpeg', '.3gp', '.ogv', '.ts', '.mts',
      '.m2ts', '.vob', '.divx', '.xvid'
    ];

    const audioExtensions = [
      '.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a',
      '.wma', '.opus', '.webm'
    ];

    const imageExtensions = [
      '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp',
      '.svg', '.tiff', '.ico', '.cur', '.heic', '.heif', '.avif'
    ];

    // ============================================
    // 🔍 البحث عن بوستر للمجلد
    // ============================================
    let posterPath = null;
    const folderMediaFiles = [];

    for (const entry of items) {
      if (entry.name.startsWith('.')) continue;
      if (entry.name.startsWith('$')) continue;
      if (entry.name === 'System Volume Information') continue;
      if (entry.name === '$RECYCLE.BIN') continue;
      if (entry.name === 'desktop.ini') continue;
      if (entry.name === 'Thumbs.db') continue;

      const fullPath = path.join(dir, entry.name);

      try {
        if (entry.isFile()) {
          const ext = path.extname(entry.name).toLowerCase();
          if (videoExtensions.includes(ext) || audioExtensions.includes(ext)) {
            const itemStat = fs.statSync(fullPath);
            folderMediaFiles.push({
              name: entry.name,
              fullPath: fullPath,
              modified: itemStat.mtime,
              size: itemStat.size,
              extension: ext,
              isVideo: videoExtensions.includes(ext),
              isAudio: audioExtensions.includes(ext)
            });
          }
        }
      } catch (e) {
        // تجاهل
      }
    }

    // إذا كان هناك ملفات وسائط، نبحث عن بوستر
    if (folderMediaFiles.length > 0) {
      folderMediaFiles.sort((a, b) => new Date(b.modified) - new Date(a.modified));
      const latestFile = folderMediaFiles[0];

      // البحث عن صورة بنفس اسم الملف
      const baseName = path.basename(latestFile.fullPath, latestFile.extension);
      for (const ext of imageExtensions) {
        const testPath = path.join(dir, baseName + ext);
        try {
          if (fs.existsSync(testPath) && fs.statSync(testPath).isFile()) {
            posterPath = testPath;
            break;
          }
        } catch (e) {}
      }

      // البحث عن أي صورة في المجلد
      if (!posterPath) {
        for (const entry of items) {
          if (entry.isFile()) {
            const ext = path.extname(entry.name).toLowerCase();
            if (imageExtensions.includes(ext)) {
              posterPath = path.join(dir, entry.name);
              break;
            }
          }
        }
      }

      const relativePath = getSmartRelativePath(latestFile.fullPath, drivePath);
      results.push({
        name: latestFile.name,
        path: relativePath,
        fullPath: latestFile.fullPath,
        modified: latestFile.modified,
        size: latestFile.size,
        extension: latestFile.extension,
        categoryId: categoryId,
        driveIndex: driveIndex,
        isDirectory: false,
        posterPath: posterPath ? posterPath.replace(/\\/g, '/') : null,
        folderPath: dir,
        depth: depth,
        fromFolder: true,
        isVideo: latestFile.isVideo,
        isAudio: latestFile.isAudio
      });
    }

    // ✅ ✅ ✅ البحث في المجلدات الفرعية - مع تسجيل أفضل
    for (const entry of items) {
      if (entry.name.startsWith('.')) continue;
      if (entry.name.startsWith('$')) continue;
      if (entry.name === 'System Volume Information') continue;
      if (entry.name === '$RECYCLE.BIN') continue;

      if (entry.isDirectory()) {
        const fullPath = path.join(dir, entry.name);
        
        // ✅ تسجيل المجلدات التي يتم مسحها
        if (depth === 0) {
          console.log(`   📂 مسح مجلد: ${entry.name} (العمق: ${depth + 1})`);
        }

        const subResults = scanDirectoryForVideos(
          fullPath,
          categoryId,
          driveIndex,
          drivePath,
          depth + 1,
          maxDepth
        );
        results.push(...subResults);
      }
    }

  } catch (error) {
    console.error(`❌ خطأ في مسح المجلد ${dir}:`, error.message);
  }

  return results;
}

// ===== تحميل الكاش =====
function loadSyncCache() {
  try {
    if (fs.existsSync(SYNC_CACHE_FILE)) {
      const data = fs.readFileSync(SYNC_CACHE_FILE, 'utf8');
      return data && data.trim() ? JSON.parse(data) : {};
    }
  } catch (e) {console.error('❌ خطأ في تحميل كاش المزامنة:', e);}
  return {};
}



// ============================================
// ===== مزامنة جميع الأقسام =====
// ============================================

async function syncAllCategories() {try {
    ////console.log('\n🔄 ================================================');
    ////console.log('🔄 بدء مزامنة المحتوى...');
    ////console.log('🔄 ================================================\n');

    const startTime = Date.now();
    const cache = loadSyncCache();
    const allCategories = config.categories.filter((c) => {try {return c.enabled !== false;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

    ////console.log(`📂 عدد الأقسام: ${allCategories.length}\n`);

    let totalFiles = 0;
    let totalPosters = 0;
    let totalFoldersScanned = 0;
    let categoriesWithFiles = 0;

    for (const category of allCategories) {
      if (!category.paths || category.paths.length === 0) {
        continue;
      }

      ////console.log(`📁 القسم: ${category.name} (${category.id})`);
      ////console.log(`   📂 عدد المسارات: ${category.paths.length}`);

      const allFiles = [];
      let foldersScanned = 0;
      let postersFound = 0;

      for (let driveIndex = 0; driveIndex < category.paths.length; driveIndex++) {
        const drive = category.paths[driveIndex];
        const drivePath = drive.path;

        ////console.log(`\n   📁 مسار ${driveIndex + 1}: ${drivePath}`);

        if (!fs.existsSync(drivePath)) {
          ////console.log(`      ❌ المسار غير موجود!`);
          continue;
        }

        try {
          // ✅ مسح فقط الفيديوهات والصوتيات
          const files = scanDirectoryForVideos(
            drivePath,
            category.id,
            driveIndex,
            drivePath,
            0,
            20
          );

          ////console.log(`      ✅ تم العثور على ${files.length} ملف (فيديو/صوت)`);

          for (const file of files) {
            if (file.posterPath) {
              postersFound++;
            }
          }

          allFiles.push(...files);
          foldersScanned++;

        } catch (error) {
          console.error(`      ❌ خطأ: ${error.message}`);
        }
      }

      allFiles.sort((a, b) => {try {return new Date(b.modified) - new Date(a.modified);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

      if (allFiles.length > 0) {
        categoriesWithFiles++;

        cache.categories[category.id] = {
          categoryId: category.id,
          categoryName: category.name,
          categoryIcon: category.icon || '📁',
          categoryColor: category.color || '#ff0000',
          files: allFiles.map((f) => {try {return {
                name: f.name,
                path: f.path,
                fullPath: f.fullPath || f.path,
                modified: f.modified,
                size: f.size,
                extension: f.extension,
                driveIndex: f.driveIndex || 0,
                categoryId: category.id,
                posterPath: f.posterPath || null,
                folderPath: f.folderPath || null,
                depth: f.depth || 0,
                isVideo: f.isVideo || false,
                isAudio: f.isAudio || false
              };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}),
          totalFiles: allFiles.length,
          totalFolders: foldersScanned,
          updatedAt: Date.now(),
          foldersScanned: foldersScanned,
          postersFound: postersFound,
          maxDepthReached: 20
        };
      } else {
        cache.categories[category.id] = {
          categoryId: category.id,
          categoryName: category.name,
          categoryIcon: category.icon || '📁',
          categoryColor: category.color || '#ff0000',
          files: [],
          totalFiles: 0,
          totalFolders: 0,
          updatedAt: Date.now(),
          foldersScanned: foldersScanned,
          postersFound: 0,
          maxDepthReached: 20
        };
      }

      totalFiles += allFiles.length;
      totalPosters += postersFound;
      totalFoldersScanned += foldersScanned;

      ////console.log(`\n   ✅ ${category.name}:`);
      ////console.log(`      🎬 ${allFiles.length} ملف (فيديو/صوت)`);
      ////console.log(`      🖼️ ${postersFound} بوستر`);
      ////console.log(`      📁 ${foldersScanned} مجلد تم مسحه\n`);
    }

    cache.lastSync = Date.now();
    cache.totalFiles = totalFiles;
    cache.totalPosters = totalPosters;
    cache.categoriesCount = allCategories.length;
    cache.foldersScanned = totalFoldersScanned;
    cache.categoriesWithFiles = categoriesWithFiles;
    cache.maxDepth = 20;

    saveSyncCache(cache);

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);

    ////console.log('✅ ================================================');
    ////console.log(`✅ تمت المزامنة في ${elapsed} ثانية`);
    ////console.log(`📊 إجمالي الملفات: ${totalFiles} ملف (فيديو/صوت)`);
    ////console.log(`🖼️ إجمالي البوسترات: ${totalPosters} بوستر`);
    ////console.log(`📁 إجمالي المجلدات الممسوحة: ${totalFoldersScanned}`);
    ////console.log(`📂 أقسام تحتوي على ملفات: ${categoriesWithFiles}/${allCategories.length}`);
    ////console.log('✅ ================================================\n');

    return cache;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}
// ============================================
// ===== متغيرات المزامنة =====
// ============================================

let syncInProgress = false;
let syncProgress = 0;
let syncStatus = 'idle';

// ============================================
// ===== إنشاء المجلدات اللازمة =====
// ============================================

function initDirectories() {try {
    const dirs = [
    DATA_DIR,
    path.join(DATA_DIR, 'public'),
    path.join(DATA_DIR, 'public', 'category-images'),
    path.join(DATA_DIR, 'public', 'path-images'),
    path.join(DATA_DIR, 'public', 'channel-images'),
    path.join(DATA_DIR, 'public', 'exclusive-images')];


    dirs.forEach((dir) => {try {
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
          //  //////console.log(`📁 تم إنشاء المجلد: ${dir}`);
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

initDirectories();

// ============================================
// ===== تهيئة الملفات =====
// ============================================

function initChannelsFile() {
  try {
    if (!fs.existsSync(CHANNELS_FILE)) {
      const defaultChannels = [{
        id: 'channel_' + Date.now() + '_1',
        name: 'القناة الأولى',
        url: 'https://example.com/stream.m3u8',
        description: 'قناة عامة',
        category: 'عامة',
        enabled: true,
        createdAt: Date.now(),
        views: 0
      }];
      fs.writeFileSync(CHANNELS_FILE, JSON.stringify(defaultChannels, null, 2), 'utf8');
    }
  } catch (error) {
    console.error('❌ خطأ في تهيئة ملف القنوات:', error);
  }
}

function initMessagesFile() {
  try {
    if (!fs.existsSync(MESSAGES_FILE)) {
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify({}, null, 2), 'utf8');
    }
  } catch (error) {
    console.error('❌ خطأ في تهيئة ملف الرسائل:', error);
  }
}

function initInfoFile() {
  try {
    if (!fs.existsSync(INFO_FILE)) {
      const defaultInfo = {
        name: '🏠 استراحة العائلة',
        description: 'مرحباً بكم في استراحة العائلة - وجهتكم المفضلة للاسترخاء والترفيه',
        phone: '📞 0500000000',
        whatsapp: '📱 0500000000',
        email: '📧 info@example.com',
        socialMedia: {
          facebook: '',
          instagram: '',
          twitter: '',
          youtube: ''
        },
        updatedAt: Date.now()
      };
      fs.writeFileSync(INFO_FILE, JSON.stringify(defaultInfo, null, 2), 'utf8');
    }
  } catch (error) {
    console.error('❌ خطأ في تهيئة ملف المعلومات:', error);
  }
}

function initExclusiveFile() {
  try {
    if (!fs.existsSync(EXCLUSIVE_FILE)) {
      fs.writeFileSync(EXCLUSIVE_FILE, JSON.stringify([], null, 2), 'utf8');
    }
  } catch (error) {
    console.error('❌ خطأ في تهيئة ملف المحتوى الحصري:', error);
  }
}

initChannelsFile();
initMessagesFile();
initInfoFile();
initExclusiveFile();

// ============================================
// ===== نظام الرسائل الخاص بكل مستخدم =====
// ============================================

// تحميل جميع رسائل المستخدمين
function loadAllMessages() {
  try {
    if (fs.existsSync(MESSAGES_FILE)) {
      const data = fs.readFileSync(MESSAGES_FILE, 'utf8');
      return data && data.trim() ? JSON.parse(data) : {};
    }
  } catch (e) {console.error('❌ خطأ في تحميل الرسائل:', e);}
  return {};
}

// تحميل رسائل مستخدم معين
function loadUserMessages(userId) {try {
    const all = loadAllMessages();
    return all[userId] || [];} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// حفظ رسائل مستخدم معين
function saveUserMessages(userId, messages) {
  try {
    const all = loadAllMessages();
    all[userId] = messages;
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify(all, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ رسائل المستخدم:', error);
    return false;
  }
}

// إضافة رسالة جديدة
function addUserMessage(userId, message, sender = 'user', ip = 'unknown') {try {
    const messages = loadUserMessages(userId);

    const newMessage = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      message: message.trim(),
      sender: sender,
      timestamp: Date.now(),
      read: sender === 'admin' ? true : false,
      reply: null,
      ip: ip
    };

    messages.push(newMessage);
    saveUserMessages(userId, messages);
    return newMessage;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// الحصول على إحصائيات الرسائل
function getMessagesStats() {try {
    const all = loadAllMessages();
    let totalMessages = 0;
    let unreadCount = 0;
    let users = Object.keys(all);

    for (const [userId, messages] of Object.entries(all)) {
      totalMessages += messages.length;
      unreadCount += messages.filter((m) => {try {return !m.read && m.sender === 'user';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}).length;
    }

    return {
      totalUsers: users.length,
      totalMessages: totalMessages,
      unreadCount: unreadCount,
      users: users
    };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== إعداد المسارات (API Routes) =====
// ============================================
// ============================================
// ===== دوال تحويل الفيديو =====
// ============================================

function scanForConvertibleFiles() {try {
    const files = [];
    const foldersSet = new Set();

    if (!config.categories) return { files: [], folders: [] };

    for (const cat of config.categories) {
      if (!cat.paths) continue;
      for (let i = 0; i < cat.paths.length; i++) {
        const drive = cat.paths[i];
        if (!fs.existsSync(drive.path)) continue;
        scanDirectoryRecursive(drive.path, files, foldersSet, drive.path);
      }
    }

    return { files, folders: Array.from(foldersSet) };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}
function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}
// ============================================
// ===== تتبع زيارات التصفح =====
// ============================================



function loadPageViews() {
    try {
        if (fs.existsSync(PAGE_VIEWS_FILE)) {
            const data = fs.readFileSync(PAGE_VIEWS_FILE, 'utf8');
            return data && data.trim() ? JSON.parse(data) : {};
        }
    } catch (e) {}
    return {};
}

function savePageViews(pageViews) {
    try {
        fs.writeFileSync(PAGE_VIEWS_FILE, JSON.stringify(pageViews, null, 2), 'utf8');
        return true;
    } catch (e) { return false; }
}
function scanDirectoryRecursive(dir, files, foldersSet, basePath) {
  try {
    const items = fs.readdirSync(dir);
    let hasConvertible = false;

    for (const item of items) {
      if (item.startsWith('.')) continue;
      const fullPath = path.join(dir, item);

      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          scanDirectoryRecursive(fullPath, files, foldersSet, basePath);
        } else {
          const ext = path.extname(item).toLowerCase();
          if (CONVERTIBLE_EXTS.includes(ext)) {
            hasConvertible = true;
            files.push({
              path: fullPath,
              name: item,
              ext: ext,
              size: stat.size,
              folder: path.relative(basePath, dir) || path.basename(basePath)
            });
          }
        }
      } catch (e) {}
    }

    if (hasConvertible) {
      foldersSet.add(path.relative(basePath, dir) || path.basename(basePath));
    }
  } catch (e) {}
}
// التأكد من وجود الملف
if (!fs.existsSync(PAGE_VIEWS_FILE)) {
    savePageViews({ daily: {}, users: {}, pages: {} });
  //  console.log('📄 تم إنشاء ملف page_views.json');
}
// ============================================
// ===== البحث عن FFmpeg =====
// ============================================

// ============================================
// ===== التحقق من وجود FFmpeg =====
// ============================================

function getFfmpegPath() {try {
    // قائمة المسارات المحتملة لـ ffmpeg
    const possiblePaths = [
    'ffmpeg', // في PATH
    path.join(EXEC_DIR, 'ffmpeg.exe'), // بجانب الملف التنفيذي (pkg)
    path.join(EXEC_DIR, 'ffmpeg'),
    path.join(process.cwd(), 'ffmpeg.exe'),
    path.join(process.cwd(), 'ffmpeg'),
    path.join(DATA_DIR, 'ffmpeg.exe'),
    path.join(DATA_DIR, 'ffmpeg'),
    'C:/ffmpeg/bin/ffmpeg.exe',
    'C:/Program Files/ffmpeg/bin/ffmpeg.exe',
    '/usr/bin/ffmpeg',
    '/usr/local/bin/ffmpeg',
    '/opt/ffmpeg/bin/ffmpeg'];


    for (const p of possiblePaths) {
      try {
        if (p === 'ffmpeg') {
          // نتحقق إذا كان ffmpeg موجوداً في PATH
          const result = require('child_process').spawnSync('ffmpeg', ['-version'], {
            windowsHide: true,
            stdio: 'ignore'
          });
          if (result.error === undefined) {
            return 'ffmpeg';
          }
        } else if (fs.existsSync(p)) {
          return p;
        }
      } catch (e) {

        // تجاهل الأخطاء
      }}

    // إذا لم يتم العثور على ffmpeg
    console.warn('⚠️ لم يتم العثور على FFmpeg، سيتم محاولة استخدامه من PATH');
    return 'ffmpeg';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}


// ============================================
// ===== التحقق من وجود FFmpeg عند بدء التشغيل =====
// ============================================

function checkFfmpeg() {
  try {
    const ffmpegPath = getFfmpegPath();
    let found = false;

    if (ffmpegPath === 'ffmpeg') {
      try {
        const result = require('child_process').spawnSync('ffmpeg', ['-version'], {
          windowsHide: true,
          stdio: 'ignore'
        });
        if (result.error === undefined) {
          found = true;
        }
      } catch (e) {}
    } else if (fs.existsSync(ffmpegPath)) {
      found = true;
    }

    if (!found) {
      console.warn('⚠️ ================================================');
      console.warn('⚠️ تحذير: FFmpeg غير مثبت على النظام!');
      console.warn('⚠️ لن تعمل صيغ: AVI, MKV, MOV, WMV, FLV وغيرها');
      console.warn('⚠️ يرجى تحميل FFmpeg من: https://ffmpeg.org/download.html');
      console.warn('⚠️ أو تثبيته عبر:');
      console.warn('⚠️   - Windows: winget install ffmpeg');
      console.warn('⚠️   - Linux: sudo apt install ffmpeg');
      console.warn('⚠️   - macOS: brew install ffmpeg');
      console.warn('⚠️ ================================================');
    } else {

      //////console.log(`✅ تم العثور على FFmpeg: ${ffmpegPath}`);
    }
    return found;
  } catch (error) {
    console.error('❌ خطأ في التحقق من FFmpeg:', error);
    return false;
  }
}
async function convertNextFile() {try {
    if (convertState.cancelRequested) {
      convertState.status = 'idle';
      convertState.currentFile = null;
      return;
    }

    if (convertState.currentIndex >= convertState.queue.length) {
      convertState.status = 'completed';
      convertState.currentFile = null;
      return;
    }

    const task = convertState.queue[convertState.currentIndex];
    convertState.currentFile = path.basename(task.input);
    convertState.status = 'converting';

    const input = task.input;
    const output = task.output;
    const args = ['-i', input, '-y'];

    // الفيديو
    if (task.resolution && task.resolution !== 'original') {
      args.push('-vf', `scale=${task.resolution}`);
    } else {
      args.push('-c:v', 'libx264', '-preset', 'fast');
    }

    // الخيوط
    if (task.threads > 0) {
      args.push('-threads', String(task.threads));
    }

    // الصوت
    if (task.audio === 'copy') {
      args.push('-c:a', 'copy');
    } else {
      args.push('-c:a', 'aac', '-b:a', '128k');
    }

    // إعدادات إضافية
    args.push('-movflags', '+faststart', '-pix_fmt', 'yuv420p');
    args.push(output);

    return new Promise((resolve) => {try {
        const ffmpegPath = getFfmpegPath();
        const proc = spawn(ffmpegPath, args, { windowsHide: true });
        convertState.process = proc;

        let stderr = '';
        proc.stderr.on('data', (data) => {try {
            stderr += data.toString();} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        proc.on('close', (code) => {try {
            convertState.process = null;
            const success = code === 0 && fs.existsSync(output);

            if (success && task.keepOriginal === 'delete') {
              try {
                fs.unlinkSync(input);
              } catch (e) {
                console.error('❌ فشل حذف الملف الأصلي:', e);
              }
            }

            convertState.results.push({
              path: input,
              output: output,
              success: success,
              error: success ? null : stderr.slice(-500)
            });

            if (success) {
              convertState.completed++;
            } else {
              convertState.failed++;
            }

            convertState.currentIndex++;
            resolve();

            // التالي
            setTimeout(() => {try {return convertNextFile();} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}, 500);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        proc.on('error', (err) => {try {
            convertState.process = null;
            convertState.results.push({
              path: input,
              success: false,
              error: err.message
            });
            convertState.failed++;
            convertState.currentIndex++;
            resolve();
            setTimeout(() => {try {return convertNextFile();} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}, 500);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== بدء تشغيل السيرفر =====
// ============================================

process.on('unhandledRejection', (reason, promise) => {try {
    console.error('❌ Unhandled Rejection:', reason);
    // لا تقتل العملية
  } catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
process.on('uncaughtException', (error) => {try {
    console.error('❌ Uncaught Exception:', error);
    // لا تقتل العملية (اختياري - احذف السطر التالي إذا أردت البقاء حياً)
    // process.exit(1);
  } catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

async function startServer() {try {
    //console.log('================================================');
    //console.log('🚀 جاري بدء تشغيل Media Server...');
    //console.log('================================================');
    checkFfmpeg();
    initializeDataSystem();
    ensureSyncCacheFile();
    startUpdateMonitoring();
    const isValid = await validateLicenseAfterLoading();

    if (!isValid) {
      //console.log('================================================');
      //console.log('❌ فشل التحقق من الصلاحية');
      //console.log('🔒 سيتم قفل السيرفر (السماح فقط بصفحة التجديد)');
      //console.log('================================================');

      lockServer('فشل التحقق من الصلاحية عند بدء التشغيل');
    } else {

      ////console.log('✅ تم التحقق من الصلاحية بنجاح');
    }
    app.use(cors({
      origin: '*',
      methods: ['GET', 'POST', 'DELETE', 'PUT', 'OPTIONS', 'HEAD'],
      allowedHeaders: ['Content-Type', 'Range', 'Accept', 'Authorization', 'Origin', 'X-Requested-With', 'Cache-Control'],
      exposedHeaders: ['Content-Range', 'Accept-Ranges', 'Content-Length', 'Content-Type', 'Content-Disposition'],
      credentials: true,
      maxAge: 86400
    }));

    app.use(express.json({ limit: '200mb' }));
    app.use(lightweightMiddleware);
    app.use(licenseCheckMiddleware);
    app.use(express.static(PUBLIC_DIR));
    loadFolderImagesCacheWithIndex();
    startLicenseMonitoring();
    setupRoutes();


    const PORT = getPortFromConfig();
    const server = app.listen(PORT, () => {try {
        console.log(`🚀 Media Server يعمل على المنفذ: ${PORT}`);
        console.log(`🌐 http://localhost:${PORT}`);
        console.log('================================================');

        if (!licenseValid || serverLocked) {



          //console.log('🔒 وضع القفل - يسمح فقط بصفحة تجديد الترخيص');
          //console.log(`🔑 http://localhost:${PORT}/setup.html`);
          //console.log(`📡 API مسموح: /api/system/*`);
        } else {

          //console.log('✅ السيرفر يعمل بشكل طبيعي');
          //console.log(`📂 الأقسام: ${config.categories?.length || 0}`);
          //console.log(`📺 القنوات: ${channels?.length || 0}`);
          //console.log(`⭐ المحتوى الحصري: ${exclusiveContent?.length || 0}`);
        } //  //////console.log('================================================');
        //  //////console.log(`🔄 فحص الترخيص كل ${LICENSE_CHECK_INTERVAL / 60000} دقيقة`);
        //  //////console.log('================================================');
      } catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});server.on('error', (error) => {try {
        if (error.code === 'EADDRINUSE') {
          console.error(`❌ المنفذ ${PORT} مشغول`);
          process.exit(1);
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== بدء التشغيل =====
// ============================================

startServer();
// تحميل كاش صور المجلدات عند بدء التشغيل

// ============================================
// ===== معالجة الإشارات =====
// ============================================

process.on('SIGINT', () => {try {
    //  //////console.log('\n🛑 جاري إيقاف السيرفر...');
    process.exit(0);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
});

process.on('SIGTERM', () => {try {
    //  //////console.log('\n🛑 جاري إيقاف السيرفر...');
    process.exit(0);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
});

process.on('uncaughtException', (error) => {try {
    console.error('❌ خطأ غير متوقع:', error);
    process.exit(1);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
});

process.on('unhandledRejection', (reason) => {try {
    console.error('❌ رفض غير معالج:', reason);
    process.exit(1);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
});
// ============================================
// ===== ✅ نظام استخراج بيانات المحتوى (MetaData) =====
// ============================================


const TMDB_API_KEY = '24230722adb8bcf44db730b34a8c926f';
const LASTFM_API_KEY = '2cba77656444e5e9b5152424b631260b';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const LASTFM_BASE_URL = 'https://ws.audioscrobbler.com/2.0/';

// إعدادات المزامنة
let metadataEnabled = true;
let metadataSyncInProgress = false;
let metadataSyncProgress = 0;
let metadataSyncCancelled = false;
let metadataSyncTotal = 0;
let metadataSyncCurrent = 0;
let metadataSyncLog = [];
let metadataSyncCurrentFolder = '';

// ============================================
// ===== دوال تحميل وحفظ الكاش =====
// ============================================

function loadMetadataCache() {
  try {
    if (fs.existsSync(METADATA_CACHE_FILE)) {
      const data = fs.readFileSync(METADATA_CACHE_FILE, 'utf8');
      return data && data.trim() ? JSON.parse(data) : {};
    }
  } catch (e) {console.error('❌ خطأ في تحميل كاش الميتاداتا:', e);}
  return {};
}



// ============================================
// ===== جلب البيانات من TMDB (أفلام ومسلسلات) =====
// ============================================

async function fetchFromTMDB(query, type = 'movie') {
  if (!TMDB_API_KEY || TMDB_API_KEY === 'YOUR_TMDB_API_KEY') {
    console.warn('⚠️ لم يتم تعيين مفتاح TMDB');
    return null;
  }

  try {
    const searchUrl = `${TMDB_BASE_URL}/search/${type}?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&language=ar&page=1`;
    const response = await axios.get(searchUrl, { timeout: 10000 });

    if (response.data && response.data.results && response.data.results.length > 0) {
      const result = response.data.results[0];

      const detailUrl = `${TMDB_BASE_URL}/${type}/${result.id}?api_key=${TMDB_API_KEY}&language=ar&append_to_response=credits`;
      const detailRes = await axios.get(detailUrl, { timeout: 10000 });
      const detail = detailRes.data;

      return {
        type: type,
        title: detail.title || detail.name,
        originalTitle: detail.original_title || detail.original_name,
        overview: detail.overview || 'لا يوجد وصف',
        rating: detail.vote_average || 0,
        voteCount: detail.vote_count || 0,
        posterPath: detail.poster_path ? `https://image.tmdb.org/t/p/w500${detail.poster_path}` : null,
        backdropPath: detail.backdrop_path ? `https://image.tmdb.org/t/p/original${detail.backdrop_path}` : null,
        releaseDate: detail.release_date || detail.first_air_date || null,
        genres: (detail.genres || []).map((g) => {try {return g.name;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}),
        runtime: detail.runtime || null,
        status: detail.status || null,
        tagline: detail.tagline || null,
        imdbId: detail.imdb_id || null,
        fetchedAt: Date.now()
      };
    }
  } catch (error) {
    console.error(`❌ خطأ في جلب البيانات من TMDB (${query}):`, error.message);
  }
  return null;
}

// ============================================
// ===== جلب البيانات من Last.fm (موسيقى) =====
// ============================================

async function fetchFromLastFM(query) {
  if (!LASTFM_API_KEY || LASTFM_API_KEY === 'YOUR_LASTFM_API_KEY') {
    console.warn('⚠️ لم يتم تعيين مفتاح Last.fm');
    return null;
  }

  try {
    const url = `${LASTFM_BASE_URL}?method=album.search&album=${encodeURIComponent(query)}&api_key=${LASTFM_API_KEY}&format=json&limit=1`;
    const response = await axios.get(url, { timeout: 10000 });

    if (response.data && response.data.results && response.data.results.albummatches && response.data.results.albummatches.album.length > 0) {
      const album = response.data.results.albummatches.album[0];

      const infoUrl = `${LASTFM_BASE_URL}?method=album.getinfo&api_key=${LASTFM_API_KEY}&artist=${encodeURIComponent(album.artist)}&album=${encodeURIComponent(album.name)}&format=json`;
      const infoRes = await axios.get(infoUrl, { timeout: 10000 });
      const info = infoRes.data;

      let coverUrl = null;
      if (info.album && info.album.image) {
        const sizes = info.album.image;
        const large = sizes.find((s) => {try {return s.size === 'extralarge';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}) || sizes.find((s) => {try {return s.size === 'large';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}) || sizes[0];
        if (large && large['#text']) coverUrl = large['#text'];
      }

      return {
        type: 'music',
        title: album.name,
        artist: album.artist,
        overview: info.album && info.album.wiki && info.album.wiki.summary || `ألبوم ${album.name} للمطرب ${album.artist}`,
        rating: null,
        voteCount: null,
        posterPath: coverUrl,
        backdropPath: coverUrl,
        releaseDate: info.album && info.album.releasedate ? info.album.releasedate : null,
        genres: info.album && info.album.tags ? info.album.tags.tag.map((t) => {try {return t.name;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}) : [],
        runtime: null,
        status: null,
        tagline: null,
        imdbId: null,
        fetchedAt: Date.now(),
        isMusic: true
      };
    }
  } catch (error) {
    console.error(`❌ خطأ في جلب البيانات من Last.fm (${query}):`, error.message);
  }
  return null;
}

// ============================================
// ===== الدالة الرئيسية لجلب البيانات =====
// ============================================

async function fetchMetadataForFolder(folderName) {try {
    let cleanName = folderName.
    replace(/[\(\)\[\]\{\}]/g, ' ').
    replace(/\s+/g, ' ').
    trim();

    const yearMatch = cleanName.match(/\s*(\d{4})\s*$/);
    let year = null;
    if (yearMatch) {
      year = yearMatch[1];
      cleanName = cleanName.replace(/\s*\d{4}\s*$/, '').trim();
    }

    // محاولة جلب البيانات من TMDB (فيلم)
    let metadata = await fetchFromTMDB(cleanName, 'movie');

    if (metadata) {
      if (metadata.rating < 3) {
        const tvData = await fetchFromTMDB(cleanName, 'tv');
        if (tvData && tvData.rating > metadata.rating) {
          metadata = tvData;
        }
      }
      return metadata;
    }

    metadata = await fetchFromTMDB(cleanName, 'tv');
    if (metadata) return metadata;

    metadata = await fetchFromLastFM(cleanName);
    if (metadata) return metadata;

    if (year) {
      const withYear = await fetchFromTMDB(`${cleanName} ${year}`, 'movie');
      if (withYear) return withYear;
    }

    return null;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== جمع المجلدات الفرعية =====
// ============================================

function collectFolders(dir, result, depth = 0, maxDepth = 5) {
  if (depth > maxDepth) return;
  try {
    const items = fs.readdirSync(dir);
    for (const item of items) {
      if (item.startsWith('.') || item.startsWith('$') || item === 'System Volume Information') continue;
      const fullPath = path.join(dir, item);
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          result.push(fullPath);
          collectFolders(fullPath, result, depth + 1, maxDepth);
        }
      } catch (e) {}
    }
  } catch (e) {}
}

// ============================================
// ===== جلب بيانات مجلد معين من الكاش =====
// ============================================

function getMetadataForFolder(folderPath) {try {
    const cache = loadMetadataCache();
    const key = folderPath.replace(/\\/g, '/');
    return cache[key] || null;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// ============================================
// ===== مزامنة جميع المجلدات في مسار معين =====
// ============================================

async function syncMetadataForPath(pathId) {try {
    //////console.log('🔍 pathId المستلم:', pathId);

    if (!pathId) {
      console.error('❌ pathId غير معرف');
      return;
    }

    if (metadataSyncInProgress) {
      console.warn('⚠️ مزامنة جارية بالفعل');
      return;
    }

    metadataSyncInProgress = true;
    metadataSyncCancelled = false;
    metadataSyncProgress = 0;
    metadataSyncCurrent = 0;
    metadataSyncLog = [];
    metadataSyncCurrentFolder = '';

    let targetPath = null;
    let targetCategory = null;
    let targetDriveIndex = -1;

    for (const cat of config.categories) {
      if (!cat.paths) continue;
      for (let i = 0; i < cat.paths.length; i++) {
        if (cat.paths[i] && cat.paths[i].id === pathId) {
          targetPath = cat.paths[i].path;
          targetCategory = cat;
          targetDriveIndex = i;
          break;
        }
      }
      if (targetPath) break;
    }

    if (!targetPath || !fs.existsSync(targetPath)) {
      console.error('❌ المسار غير موجود:', targetPath);
      metadataSyncInProgress = false;
      return;
    }

    //////console.log(`🔄 بدء مزامنة البيانات للمسار: ${targetPath}`);

    const folders = [];
    collectFolders(targetPath, folders);

    metadataSyncTotal = folders.length;

    //////console.log(`📁 تم العثور على ${folders.length} مجلد`);

    const cache = loadMetadataCache();

    for (let i = 0; i < folders.length; i++) {
      if (metadataSyncCancelled) {
        //////console.log('⏹ تم إلغاء المزامنة');
        metadataSyncLog.push('⏹ تم إلغاء المزامنة');
        break;
      }

      const folder = folders[i];
      metadataSyncCurrent = i + 1;
      metadataSyncCurrentFolder = folder;
      metadataSyncProgress = Math.round((i + 1) / folders.length * 100);

      const folderName = path.basename(folder);
      const cacheKey = folder.replace(/\\/g, '/');

      if (cache[cacheKey] && Date.now() - cache[cacheKey].fetchedAt < 7 * 24 * 60 * 60 * 1000) {
        continue;
      }

      //////console.log(`🔍 جلب بيانات: ${folderName} (${i+1}/${folders.length})`);
      metadataSyncLog.push(`🔍 جلب بيانات: ${folderName}`);

      const metadata = await fetchMetadataForFolder(folderName);

      if (metadata) {
        cache[cacheKey] = {
          ...metadata,
          path: folder,
          folderName: folderName,
          fetchedAt: Date.now()
        };
        metadataSyncLog.push(`✅ تم جلب بيانات: ${folderName} (${metadata.title})`);
        //////console.log(`✅ تم جلب بيانات: ${folderName} → ${metadata.title}`);
      } else {
        cache[cacheKey] = {
          type: 'unknown',
          title: folderName,
          overview: 'لا توجد بيانات متاحة',
          rating: null,
          posterPath: null,
          backdropPath: null,
          fetchedAt: Date.now(),
          path: folder,
          folderName: folderName,
          isFallback: true
        };
        metadataSyncLog.push(`⚠️ لا توجد بيانات لـ: ${folderName}`);
        //////console.log(`⚠️ لا توجد بيانات لـ: ${folderName}`);
      }

      saveMetadataCache(cache);
    }

    metadataSyncInProgress = false;
    metadataSyncProgress = 100;
    metadataSyncLog.push('✅ اكتملت المزامنة');

    //////console.log('✅ اكتملت المزامنة');
  } catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}
  
function startUpdateMonitoring() {
  if (updateCheckInterval) {
    clearInterval(updateCheckInterval);
  }

  if (!updateConfig.autoCheck) {
    console.log('ℹ️ المراقبة معطلة');
    return;
  }

  // التحقق الأولي
  setTimeout(() => {
    checkForUpdates().catch(err => {
      console.error('❌ خطأ في التحقق الأولي:', err.message);
    });
  }, 60000);

  // الدوري
  updateCheckInterval = setInterval(() => {
    checkForUpdates().catch(err => {
      console.error('❌ خطأ في التحقق الدوري:', err.message);
    });
  }, updateConfig.checkInterval);

  console.log(`🔄 بدأت المراقبة (كل ${updateConfig.checkInterval / 60000} دقيقة)`);
}

// ============================================
// ===== دالة setupRoutes (جميع المسارات) =====
// ============================================
// قم بتشغيل هذا السكريبت مرة واحدة لإصلاح المعرفات

function setupRoutes() {try {

    function fixMissingPathIds() {try {
        let fixed = 0;
        config.categories.forEach((cat) => {try {
            if (!cat.paths) return;
            cat.paths.forEach((p, idx) => {try {
                if (!p.id) {
                  p.id = `path_${cat.id}_${idx}_${Date.now()}`;
                  fixed++;
                }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
            });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });
        if (fixed > 0) {
          saveConfig(config);
          //console.log(`✅ تم إصلاح ${fixed} مسار بدون معرف`);
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    }
    fixMissingPathIds();
    // ===== مسار التحقق من حالة الترخيص وإعادة التوجيه =====
    app.get('/api/system/check-and-redirect', async (req, res) => {
      try {
        const isConnected = await checkInternetConnectivity();
        const result = await revalidateLicense();

        if (!serverLocked && licenseValid) {
          const expiredPage = path.join(PUBLIC_DIR, 'license-expired.html');
          if (fs.existsSync(expiredPage)) {
            try {
              fs.unlinkSync(expiredPage);
            } catch (e) {}
          }

          return res.json({
            success: true,
            licenseValid: true,
            serverLocked: false,
            redirectTo: '/',
            message: 'تم التحقق من الترخيص'
          });
        } else {
          return res.json({
            success: false,
            licenseValid: false,
            serverLocked: true,
            message: 'لا يزال الترخيص غير صالح'
          });
        }
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });


    // ===== تحديث صفحة انتهاء الصلاحية للتحقق التلقائي =====
    app.get('/license-expired.html', (req, res) => {try {
        // ✅ إذا كان الترخيص صالحاً، نعيد التوجيه إلى الصفحة الرئيسية
        if (licenseValid && !serverLocked) {
          return res.redirect('/');
        }

        const expiredPage = path.join(PUBLIC_DIR, 'license-expired.html');
        if (fs.existsSync(expiredPage)) {
          // نقرأ الملف ونضيف السكريبت للتحقق التلقائي
          let html = fs.readFileSync(expiredPage, 'utf8');
          // نتحقق إذا كان السكريبت موجوداً بالفعل
          if (!html.includes('checkLicenseAndRedirect')) {
            const script = `
            <script>
            // التحقق التلقائي كل 5 ثواني
            async function checkLicenseAndRedirect() {
                try {
                    const response = await fetch('/api/system/check-and-redirect');
                    const data = await response.json();
                    if (data.success && data.licenseValid && !data.serverLocked) {
                        // تم التحقق، نعيد التوجيه إلى الصفحة الرئيسية
                        window.location.href = '/';
                    } else {
                        // لا يزال مقفلاً، نعيد المحاولة
                        setTimeout(checkLicenseAndRedirect, 5000);
                    }
                } catch (error) {
                    setTimeout(checkLicenseAndRedirect, 5000);
                }
            }
            // بدء التحقق فوراً
            checkLicenseAndRedirect();
            </script>
            `;
            // إضافة السكريبت قبل إغلاق body
            html = html.replace('</body>', script + '</body>');
          }
          res.send(html);
        } else {
          // إذا لم توجد الصفحة، ننشئها ثم نعيد توجيه
          createLicenseExpiredPage('الترخيص غير صالح');
          // نعيد توجيه إلى نفس المسار بعد الإنشاء
          res.redirect('/license-expired.html');
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });
    // توليد الكاش (POST)
    // ===== مسارات كاش صور المجلدات =====

    // توليد الكاش
    app.post('/api/folder-images/generate', (req, res) => {try {
        if (!licenseValid || serverLocked) {
          return res.status(403).json({
            success: false,
            error: 'الترخيص غير صالح أو السيرفر مقفل'
          });
        }
        const result = generateFolderImagesCache();
        if (result.success) {
          res.json({
            success: true,
            message: 'تم توليد كاش صور المجلدات بنجاح',
            count: result.count
          });
        } else {
          res.status(500).json({
            success: false,
            error: result.error
          });
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // جلب الكاش (للتشخيص)
    app.get('/api/folder-images/cache', (req, res) => {try {
        const cache = loadFolderImagesCacheWithIndex();
        res.json({
          success: true,
          cache: cache,
          count: Object.keys(cache).length
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // جلب صورة مجلد من الكاش (بحث سريع O(1))
    app.get('/api/folder-images/get', (req, res) => {
      const folderPath = req.query.path;
      const categoryId = req.query.categoryId;
      const driveIndex = parseInt(req.query.driveIndex) || 0;
      try {
        if (!folderPath) {
          return res.status(400).json({ success: false, error: 'المسار مطلوب' });
        }

        const imagePath = getFolderImageFromCacheFast(folderPath, categoryId, driveIndex);

        if (imagePath && fs.existsSync(imagePath)) {
          const mimeType = mime.lookup(imagePath) || 'image/jpeg';
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Cache-Control', 'public, max-age=86400');
          res.setHeader('Access-Control-Allow-Origin', '*');
          return fs.createReadStream(imagePath).pipe(res);
        }
        return sendDefaultImage(res);
      } catch (error) {
        console.error('❌ خطأ في جلب صورة المجلد:', error);
        sendDefaultImage(res);
      }
    });
    app.get('/favicon.ico', (req, res) => {try {
        sendDefaultImage(res, 'image/x-icon');} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });
    // ============================================
    // ===== 29. مسارات تحويل الفيديو =====
    // ============================================

    app.get('/api/convert/scan', (req, res) => {
      try {
        const { files, folders } = scanForConvertibleFiles();
        res.json({
          success: true,
          files: files,
          folders: folders,
          count: files.length
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/convert/start', (req, res) => {
      try {
        const { files, resolution, threads, keepOriginal, audio } = req.body;

        if (!files || !Array.isArray(files) || files.length === 0) {
          return res.status(400).json({ success: false, error: 'لا توجد ملفات محددة' });
        }

        if (convertState.status === 'converting') {
          return res.status(409).json({ success: false, error: 'هناك تحويل جاري بالفعل' });
        }

        const queue = files.map((f) => {try {
            const ext = path.extname(f);
            const base = f.slice(0, -ext.length);
            const output = base + '.mp4';
            return {
              input: f,
              output: output,
              resolution: resolution || 'original',
              threads: threads || 2,
              keepOriginal: keepOriginal || 'keep',
              audio: audio || 'copy'
            };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        convertState = {
          status: 'converting',
          queue: queue,
          currentIndex: 0,
          currentFile: null,
          completed: 0,
          failed: 0,
          total: queue.length,
          results: [],
          cancelRequested: false,
          process: null
        };

        // بدء التحويل في الخلفية
        convertNextFile();

        res.json({
          success: true,
          message: `بدأ تحويل ${queue.length} ملف`,
          total: queue.length
        });

      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.get('/api/convert/progress', (req, res) => {try {
        res.json({
          success: true,
          status: convertState.status,
          total: convertState.total,
          completed: convertState.completed,
          failed: convertState.failed,
          currentFile: convertState.currentFile,
          currentIndex: convertState.currentIndex,
          results: convertState.results
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    app.post('/api/convert/cancel', (req, res) => {try {
        convertState.cancelRequested = true;
        if (convertState.process) {
          try {
            convertState.process.kill('SIGTERM');
          } catch (e) {}
        }
        convertState.status = 'idle';
        res.json({ success: true, message: 'تم إرسال طلب الإلغاء' });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });
    app.get('/api/categories', (req, res) => {
      try {
        res.json({
          success: true,
          categories: config.categories || [],
          default: config.defaultCategory
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/categories/add', (req, res) => {
      try {
        const { name, icon, color, paths } = req.body;

        if (!name) {
          return res.status(400).json({
            success: false,
            error: 'اسم القسم مطلوب'
          });
        }

        if (!config.categories) config.categories = [];

        const id = name.toLowerCase().replace(/\s+/g, '_') + '_' + Date.now();

        config.categories.push({
          id: id,
          name: name,
          icon: icon || '📁',
          color: color || '#667eea',
          paths: paths || [],
          enabled: true
        });

        if (saveConfig(config)) {
          res.json({
            success: true,
            message: 'تم إضافة القسم بنجاح',
            category: config.categories[config.categories.length - 1]
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ الإعدادات'
          });
        }
      } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.delete('/api/categories/remove/:id', (req, res) => {
      try {
        const id = req.params.id;

        const index = config.categories.findIndex((c) => {try {return c.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (index === -1) {
          return res.status(404).json({
            success: false,
            error: 'القسم غير موجود'
          });
        }

        config.categories.splice(index, 1);

        if (config.defaultCategory === id) {
          config.defaultCategory = config.categories[0]?.id || null;
        }

        if (saveConfig(config)) {
          res.json({
            success: true,
            message: 'تم حذف القسم بنجاح'
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ الإعدادات'
          });
        }
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.put('/api/categories/update/:id', (req, res) => {
      try {
        const id = req.params.id;
        const { name, icon, color, paths, enabled } = req.body;

        const category = config.categories.find((c) => {try {return c.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (!category) {
          return res.status(404).json({
            success: false,
            error: 'القسم غير موجود'
          });
        }

        if (name) category.name = name;
        if (icon) category.icon = icon;
        if (color) category.color = color;
        if (paths) category.paths = paths;
        if (enabled !== undefined) category.enabled = enabled;

        if (saveConfig(config)) {
          res.json({
            success: true,
            message: 'تم تحديث القسم بنجاح',
            category: category
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ الإعدادات'
          });
        }
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/categories/:id/paths/add', (req, res) => {
      try {
        const id = req.params.id;
        const { path: folderPath, type, name } = req.body;

        ////console.log('📥 إضافة مسار:', { id, folderPath, type, name });

        // ✅ التحقق من وجود المسار
        if (!folderPath) {
          return res.status(400).json({
            success: false,
            error: 'المسار مطلوب'
          });
        }

        // ✅ البحث عن القسم
        const categoryIndex = config.categories.findIndex((c) => {try {return c.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (categoryIndex === -1) {
          return res.status(404).json({
            success: false,
            error: 'القسم غير موجود'
          });
        }

        const category = config.categories[categoryIndex];

        // ✅ التأكد من وجود paths
        if (!category.paths) {
          category.paths = [];
        }

        // ✅ تنظيف المسار
        let cleanPath = folderPath.replace(/\\/g, '/').trim();

        // ✅ تطبيع مسار Windows
        if (cleanPath.match(/^[A-Za-z]:[^\\/]/)) {
          cleanPath = cleanPath.replace(/^([A-Za-z]):/, '$1:/');
        }

        // ✅ إنشاء معرف فريد
        const pathId = `path_${category.id}_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;

        // ✅ إضافة المسار
        const newPath = {
          id: pathId,
          path: cleanPath,
          type: type || 'all',
          name: name || path.basename(cleanPath) || 'مسار',
          isNetwork: cleanPath.startsWith('//') || cleanPath.startsWith('\\\\')
        };

        category.paths.push(newPath);

        ////console.log('✅ تم إضافة المسار:', newPath);

        // ✅ حفظ باستخدام طريقة مباشرة
        try {
          const jsonData = JSON.stringify(config, null, 2);
          fs.writeFileSync(CONFIG_FILE, jsonData, 'utf8');

          // ✅ إعادة تحميل config
          const freshData = fs.readFileSync(CONFIG_FILE, 'utf8');
          const freshConfig = JSON.parse(freshData);

          // ✅ تحديث config العام
          Object.assign(config, freshConfig);

          res.json({
            success: true,
            message: `تم إضافة المسار "${newPath.name}" بنجاح`,
            path: newPath,
            category: category
          });
        } catch (saveError) {
          console.error('❌ فشل حفظ الإعدادات:', saveError);
          // ✅ إزالة المسار إذا فشل الحفظ
          category.paths.pop();
          res.status(500).json({
            success: false,
            error: 'فشل حفظ الإعدادات: ' + saveError.message
          });
        }

      } catch (error) {
        console.error('❌ خطأ في إضافة المسار:', error);
        res.status(500).json({
          success: false,
          error: error.message,
          stack: error.stack
        });
      }
    });

    // ============================================
    // ===== 2. مسارات المحتوى =====
    // ============================================

    const folderCache = new Map();
    const FOLDER_CACHE_DURATION = 15000;

   app.get('/api/category/:id/content', (req, res) => {
  try {
    trackSession(req);
    const views = loadViews();

    const id = req.params.id;
    const relativePath = req.query.path || '';
    const driveIndex = parseInt(req.query.driveIndex) || 0;
    const cacheKey = `content_${id}_${relativePath}_${driveIndex}`;

    // التحقق من الكاش
    const cached = folderCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < FOLDER_CACHE_DURATION) {
      return res.json(cached.data);
    }

    // البحث عن القسم
    const category = config.categories.find((c) => c.id === id);
    if (!category || category.enabled === false) {
      return res.status(404).json({
        success: false,
        error: 'القسم غير موجود أو معطل'
      });
    }

    if (!category.paths || category.paths.length === 0) {
      const emptyResult = {
        success: true,
        category: category,
        path: relativePath || '/',
        items: [],
        totalItems: 0,
        driveIndex: driveIndex
      };
      folderCache.set(cacheKey, { data: emptyResult, timestamp: Date.now() });
      return res.json(emptyResult);
    }

    const drive = category.paths[driveIndex];
    if (!drive) {
      return res.status(404).json({
        success: false,
        error: 'المسار المحدد غير موجود'
      });
    }

    const fullPath = path.join(drive.path, relativePath);

    if (!fs.existsSync(fullPath)) {
      const emptyResult = {
        success: true,
        category: category,
        path: relativePath || '/',
        items: [],
        totalItems: 0,
        driveIndex: driveIndex
      };
      folderCache.set(cacheKey, { data: emptyResult, timestamp: Date.now() });
      return res.json(emptyResult);
    }

    // قراءة محتويات المجلد
    const items = fs.readdirSync(fullPath);
    const result = items
      .map((item) => {
        const itemPath = path.join(fullPath, item);
        let stat;
        try {
          stat = fs.statSync(itemPath);
        } catch (e) {
          return null;
        }
        const ext = path.extname(item).toLowerCase();

        let itemRelativePath = relativePath ? path.join(relativePath, item) : item;
        itemRelativePath = itemRelativePath.replace(/\\/g, '/');

        let hasPoster = false;
        if (stat.isDirectory()) {
          try {
            const files = fs.readdirSync(itemPath);
            hasPoster = files.some((f) => {
              const ext2 = path.extname(f).toLowerCase();
              return ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'].includes(ext2);
            });
          } catch (e) {
            hasPoster = false;
          }
        }

        return {
          name: item,
          path: itemRelativePath,
          fullPath: itemPath,
          isDirectory: stat.isDirectory(),
          size: stat.size,
          modified: stat.mtime,
          extension: ext,
          driveType: drive.type || 'all',
          hasPoster: hasPoster
        };
      })
      .filter((item) => item !== null);

    // تصفية حسب نوع المسار (إذا كان محدداً)
    let filteredItems = result;
    if (drive.type && drive.type !== 'all') {
      const allowedExtensions = FILE_TYPES[drive.type]?.extensions || [];
      filteredItems = result.filter((item) => {
        if (item.isDirectory) return true;
        return allowedExtensions.includes(item.extension.toLowerCase());
      });
    }

    // ترتيب النتائج (المجلدات أولاً ثم الملفات حسب الاسم)
    filteredItems.sort((a, b) => {
      if (a.isDirectory && !b.isDirectory) return -1;
      if (!a.isDirectory && b.isDirectory) return 1;
      return a.name.localeCompare(b.name);
    });

    // ✅ إضافة المشاهدات للملفات فقط (المجلدات ليس لها مشاهدات)
    const itemsWithViews = filteredItems.map(item => {
      if (!item.isDirectory) {
        const key = `${id}:${driveIndex}:${item.path}`;
        item.views = views[key] || 0;
      } else {
        item.views = 0;
      }
      return item;
    });

    const responseData = {
      success: true,
      category: category,
      path: relativePath || '/',
      items: itemsWithViews,
      totalItems: itemsWithViews.length,
      driveIndex: driveIndex,
      drivePath: drive.path,
      cached: false
    };

    folderCache.set(cacheKey, { data: responseData, timestamp: Date.now() });

    res.json(responseData);

  } catch (error) {
    console.error('Error in /api/category/:id/content:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

    setInterval(() => {try {
        const now = Date.now();
        for (const [key, value] of folderCache) {
          if (now - value.timestamp > FOLDER_CACHE_DURATION) {
            folderCache.delete(key);
          }
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    }, 60000);
// ============================================
// ===== مسار التراجع عن التحديث =====
// ============================================

app.post('/api/updates/rollback', async (req, res) => {
  try {
    const { version } = req.body;
    
    if (!version) {
      return res.status(400).json({
        success: false,
        error: 'الإصدار مطلوب'
      });
    }

    const result = await rollbackUpdate(version);
    
    if (result.success) {
      res.json({
        success: true,
        message: `تم التراجع إلى الإصدار ${version} بنجاح. يرجى إعادة تشغيل السيرفر.`,
        version
      });
    } else {
      res.status(500).json({
        success: false,
        error: result.error
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// جلب النسخ الاحتياطية المتاحة
app.get('/api/updates/backups', (req, res) => {
  try {
    const backupsDir = path.join(DATA_DIR, 'updates', 'backups');
    
    if (!fs.existsSync(backupsDir)) {
      return res.json({ success: true, backups: [] });
    }

    const backups = fs.readdirSync(backupsDir)
      .filter(f => f.startsWith('backup_'))
      .map(f => {
        const filePath = path.join(backupsDir, f);
        const stat = fs.statSync(filePath);
        
        // استخراج الإصدار من اسم الملف
        const match = f.match(/backup_v([\d.]+)_/);
        const version = match ? match[1] : 'unknown';
        
        return {
          name: f,
          version,
          size: stat.size,
          sizeFormatted: formatBytes(stat.size),
          createdAt: stat.mtime.getTime(),
          date: stat.mtime.toLocaleString('ar-EG')
        };
      })
      .sort((a, b) => b.createdAt - a.createdAt);

    res.json({ success: true, backups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// حذف نسخة احتياطية
app.delete('/api/updates/backups/:name', (req, res) => {
  try {
    const name = req.params.name;
    const backupPath = path.join(DATA_DIR, 'updates', 'backups', name);
    
    if (name.includes('..') || name.includes('/') || name.includes('\\')) {
      return res.status(403).json({ success: false, error: 'ممنوع' });
    }

    if (fs.existsSync(backupPath)) {
      fs.unlinkSync(backupPath);
      res.json({ success: true, message: 'تم حذف النسخة الاحتياطية' });
    } else {
      res.status(404).json({ success: false, error: 'النسخة غير موجودة' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});// ============================================
// ===== مسار التحديث التلقائي الفوري =====
// ============================================

app.post('/api/updates/auto-update-now', async (req, res) => {
  try {
    console.log('🚀 طلب تشغيل التحديث التلقائي الفوري');

    // التحقق من وجود تحديث
    const checkResult = await checkForUpdates();

    if (!checkResult.success) {
      return res.status(500).json({
        success: false,
        error: checkResult.error || 'فشل التحقق من التحديثات'
      });
    }

    if (!checkResult.hasUpdate) {
      return res.json({
        success: false,
        error: 'لا توجد تحديثات جديدة متاحة'
      });
    }

    const latestVersion = checkResult.availableVersions[0];

    // إرسال الاستجابة أولاً
    res.json({
      success: true,
      message: `بدء التحديث التلقائي إلى الإصدار ${latestVersion.version}`,
      version: latestVersion.version
    });

    // تنفيذ التحديث في الخلفية
    setTimeout(() => {
      performAutoUpdate(latestVersion.version, latestVersion.downloadUrl);
    }, 1000);

  } catch (error) {
    console.error('❌ خطأ:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});
    // ============================================
    // ===== 3. مسارات الصور =====
    // ============================================

    const CATEGORY_IMAGES_DIR = path.join(DATA_DIR, 'public', 'category-images');

    app.post('/api/category/:id/upload-image', (req, res) => {
      try {
        const { image } = req.body;
        const categoryId = req.params.id;

        if (!image) {
          return res.status(400).json({
            success: false,
            error: 'الصورة مطلوبة'
          });
        }

        const matches = image.match(/^data:image\/(\w+);base64,/);
        if (!matches) {
          return res.status(400).json({
            success: false,
            error: 'تنسيق الصورة غير صحيح'
          });
        }

        const ext = matches[1];
        const base64Data = image.replace(/^data:image\/\w+;base64,/, '');
        const filename = `${categoryId}.${ext}`;
        const filepath = path.join(CATEGORY_IMAGES_DIR, filename);

        const oldFiles = fs.readdirSync(CATEGORY_IMAGES_DIR);
        oldFiles.forEach((f) => {try {
            if (f.startsWith(categoryId)) {
              fs.unlinkSync(path.join(CATEGORY_IMAGES_DIR, f));
            }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        fs.writeFileSync(filepath, base64Data, 'base64');

        const timestamp = Date.now();
        res.json({
          success: true,
          message: 'تم رفع الصورة بنجاح',
          imageUrl: `/category-images/${filename}?t=${timestamp}`
        });
      } catch (error) {
        console.error('Error uploading category image:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.delete('/api/category/:id/delete-image', (req, res) => {
      try {
        const categoryId = req.params.id;
        const files = fs.readdirSync(CATEGORY_IMAGES_DIR);
        let deleted = false;

        files.forEach((f) => {try {
            if (f.startsWith(categoryId)) {
              fs.unlinkSync(path.join(CATEGORY_IMAGES_DIR, f));
              deleted = true;
            }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        res.json({
          success: true,
          message: deleted ? 'تم حذف الصورة بنجاح' : 'لا توجد صورة للحذف'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });
// ============================================
// ===== مسارات الإشعارات =====
// ============================================

// جلب جميع الإشعارات
app.get('/api/notifications', (req, res) => {
  try {
    const cache = loadNotificationsCache();
    const unreadCount = (cache.notifications || []).filter(n => !n.read).length;
    
    res.json({
      success: true,
      notifications: (cache.notifications || []).slice(-50).reverse(),
      unreadCount,
      lastRead: cache.lastRead
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// تعيين إشعار كمقروء
app.post('/api/notifications/read/:id', (req, res) => {
  try {
    const id = req.params.id;
    const cache = loadNotificationsCache();
    
    const notif = (cache.notifications || []).find(n => n.id === id);
    if (notif) {
      notif.read = true;
      saveNotificationsCache(cache);
    }
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// تعيين جميع الإشعارات كمقروءة
app.post('/api/notifications/read-all', (req, res) => {
  try {
    const cache = loadNotificationsCache();
    
    (cache.notifications || []).forEach(n => n.read = true);
    cache.lastRead = Date.now();
    saveNotificationsCache(cache);
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// حذف إشعار
app.delete('/api/notifications/:id', (req, res) => {
  try {
    const id = req.params.id;
    const cache = loadNotificationsCache();
    
    cache.notifications = (cache.notifications || []).filter(n => n.id !== id);
    saveNotificationsCache(cache);
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// حذف جميع الإشعارات
app.delete('/api/notifications', (req, res) => {
  try {
    const cache = loadNotificationsCache();
    cache.notifications = [];
    saveNotificationsCache(cache);
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});
// ============================================
// ===== اختبار الاتصال بسيرفر التحديثات =====
// ============================================

app.post('/api/updates/test-connection', async (req, res) => {
  const startTime = Date.now();
  
  try {
    const { url } = req.body;

    if (!url) {
      return res.status(400).json({
        success: false,
        error: 'الرابط مطلوب'
      });
    }

    // التحقق من صحة الرابط
    try {
      new URL(url);
    } catch (e) {
      return res.status(400).json({
        success: false,
        error: 'الرابط غير صالح'
      });
    }

    console.log(`🧪 اختبار الاتصال بـ: ${url}`);

    // محاولة الاتصال
    let testUrl = url.replace(/\/$/, ''); // إزالة / في النهاية
    
    // جرب المسار /versions أولاً
    let response;
    let versionsFound = false;
    let versionsData = null;

    try {
      response = await axios.get(`${testUrl}/versions`, {
        timeout: 10000,
        headers: {
          'User-Agent': `MediaServer/${getCurrentVersion()}`,
          'Accept': 'application/json'
        },
        validateStatus: (status) => status < 500
      });

      if (response.status === 200 && response.data) {
        versionsFound = true;
        versionsData = response.data;
      }
    } catch (e1) {
      // جرب /api/versions
      try {
        response = await axios.get(`${testUrl}/api/versions`, {
          timeout: 10000,
          headers: {
            'User-Agent': `MediaServer/${getCurrentVersion()}`,
            'Accept': 'application/json'
          },
          validateStatus: (status) => status < 500
        });

        if (response.status === 200 && response.data) {
          versionsFound = true;
          versionsData = response.data;
        }
      } catch (e2) {
        // جرب الرابط مباشرة
        try {
          response = await axios.get(testUrl, {
            timeout: 10000,
            headers: {
              'User-Agent': `MediaServer/${getCurrentVersion()}`,
              'Accept': 'application/json'
            },
            validateStatus: (status) => status < 500
          });

          if (response.status === 200 && response.data) {
            versionsFound = true;
            versionsData = response.data;
          }
        } catch (e3) {
          throw new Error(`لا يمكن الاتصال: ${e3.message}`);
        }
      }
    }

    const responseTime = Date.now() - startTime;

    if (!versionsFound) {
      return res.json({
        success: false,
        error: 'الاتصال ناجح لكن الاستجابة غير صالحة (لا تحتوي على بيانات الإصدارات)',
        responseTime
      });
    }

    // استخراج معلومات الإصدارات
    let versions = [];
    let latestVersion = null;

    if (versionsData && versionsData.versions && Array.isArray(versionsData.versions)) {
      versions = versionsData.versions;
    } else if (versionsData && versionsData.data && versionsData.data.versions) {
      versions = versionsData.data.versions;
    } else if (Array.isArray(versionsData)) {
      versions = versionsData;
    }

    const currentVersion = getCurrentVersion();

    // البحث عن أحدث إصدار
    const newerVersions = versions.filter(v => {
      const vVersion = v.version || v;
      return compareVersions(vVersion, currentVersion) > 0;
    });

    if (newerVersions.length > 0) {
      newerVersions.sort((a, b) => {
        const v1 = a.version || a;
        const v2 = b.version || b;
        return compareVersions(v2, v1);
      });
      latestVersion = newerVersions[0].version || newerVersions[0];
    }

    res.json({
      success: true,
      message: 'الاتصال ناجح',
      versionsCount: versions.length,
      currentVersion: currentVersion,
      latestVersion: latestVersion,
      hasUpdate: newerVersions.length > 0,
      newerVersionsCount: newerVersions.length,
      responseTime: responseTime,
      serverInfo: {
        url: url,
        testedAt: Date.now()
      }
    });

  } catch (error) {
    const responseTime = Date.now() - startTime;
    
    console.error('❌ فشل اختبار الاتصال:', error.message);

    let errorMessage = error.message;
    
    // تحسين رسائل الأخطاء
    if (error.code === 'ECONNREFUSED') {
      errorMessage = 'تم رفض الاتصال - تأكد من أن السيرفر يعمل';
    } else if (error.code === 'ETIMEDOUT' || error.code === 'ECONNABORTED') {
      errorMessage = 'انتهت مهلة الاتصال - السيرفر لا يستجيب';
    } else if (error.code === 'ENOTFOUND') {
      errorMessage = 'لم يتم العثور على السيرفر - تحقق من الرابط';
    } else if (error.response) {
      errorMessage = `خطأ HTTP ${error.response.status}: ${error.response.statusText}`;
    }

    res.json({
      success: false,
      error: errorMessage,
      responseTime: responseTime,
      errorCode: error.code
    });
  }
});
// SSE - البث المباشر للإشعارات
app.get('/api/notifications/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.flushHeaders();

  // إرسال رسالة ترحيب
  res.write(`data: ${JSON.stringify({ type: 'connected', timestamp: Date.now() })}\n\n`);

  notificationClients.add(res);

  // إبقاء الاتصال مفتوحاً
  const keepAlive = setInterval(() => {
    try {
      res.write(`: keepalive\n\n`);
    } catch (e) {
      clearInterval(keepAlive);
      notificationClients.delete(res);
    }
  }, 30000);

  req.on('close', () => {
    clearInterval(keepAlive);
    notificationClients.delete(res);
  });
});

// جلب إعدادات الإشعارات
app.get('/api/notifications/settings', (req, res) => {
  try {
    res.json({
      success: true,
      settings: updateConfig.notifications || {}
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// حفظ إعدادات الإشعارات
app.post('/api/notifications/settings', (req, res) => {
  try {
    const settings = req.body;
    
    updateConfig.notifications = {
      ...updateConfig.notifications,
      ...settings
    };
    
    saveUpdateConfig(updateConfig);
    
    res.json({
      success: true,
      message: 'تم حفظ إعدادات الإشعارات',
      settings: updateConfig.notifications
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});
    app.get('/api/category-image/:id', (req, res) => {
      try {
        const categoryId = req.params.id;
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.ico'];

        for (const ext of imageExtensions) {
          const imagePath = path.join(CATEGORY_IMAGES_DIR, `${categoryId}${ext}`);
          if (fs.existsSync(imagePath)) {
            const mimeType = mime.lookup(imagePath) || 'image/jpeg';
            res.setHeader('Content-Type', mimeType);
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.setHeader('Pragma', 'no-cache');
            res.setHeader('Expires', '0');
            res.setHeader('Access-Control-Allow-Origin', '*');
            return fs.createReadStream(imagePath).pipe(res);
          }
        }

        // لم نجد الصورة ← نرسل الافتراضية
        return sendDefaultImage(res);
      } catch (error) {
        console.error('Error serving category image:', error);
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== 4. صور المسارات =====
    // ============================================

    const PATH_IMAGES_DIR = path.join(DATA_DIR, 'public', 'path-images');

    app.post('/api/path/:id/upload-image', (req, res) => {
      try {
        const { image } = req.body;
        const pathId = req.params.id;

        if (!image) {
          return res.status(400).json({
            success: false,
            error: 'الصورة مطلوبة'
          });
        }

        const matches = image.match(/^data:image\/(\w+);base64,/);
        if (!matches) {
          return res.status(400).json({
            success: false,
            error: 'تنسيق الصورة غير صحيح'
          });
        }

        const ext = matches[1];
        const base64Data = image.replace(/^data:image\/\w+;base64,/, '');
        const filename = `${pathId}.${ext}`;
        const filepath = path.join(PATH_IMAGES_DIR, filename);

        const oldFiles = fs.readdirSync(PATH_IMAGES_DIR);
        oldFiles.forEach((f) => {try {
            if (f.startsWith(pathId)) {
              fs.unlinkSync(path.join(PATH_IMAGES_DIR, f));
            }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        fs.writeFileSync(filepath, base64Data, 'base64');

        const timestamp = Date.now();
        res.json({
          success: true,
          message: 'تم رفع الصورة بنجاح',
          imageUrl: `/path-images/${filename}?t=${timestamp}`
        });
      } catch (error) {
        console.error('Error uploading path image:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.delete('/api/path/:id/delete-image', (req, res) => {
      try {
        const pathId = req.params.id;
        const files = fs.readdirSync(PATH_IMAGES_DIR);
        let deleted = false;

        files.forEach((f) => {try {
            if (f.startsWith(pathId)) {
              fs.unlinkSync(path.join(PATH_IMAGES_DIR, f));
              deleted = true;
            }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        res.json({
          success: true,
          message: deleted ? 'تم حذف الصورة بنجاح' : 'لا توجد صورة للحذف'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/path-image/:id', (req, res) => {
      try {
        const pathId = req.params.id;
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.ico'];

        for (const ext of imageExtensions) {
          const imagePath = path.join(PATH_IMAGES_DIR, `${pathId}${ext}`);
          if (fs.existsSync(imagePath)) {
            const mimeType = mime.lookup(imagePath) || 'image/jpeg';
            res.setHeader('Content-Type', mimeType);
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.setHeader('Pragma', 'no-cache');
            res.setHeader('Expires', '0');
            res.setHeader('Access-Control-Allow-Origin', '*');
            return fs.createReadStream(imagePath).pipe(res);
          }
        }

        return sendDefaultImage(res);
      } catch (error) {
        console.error('Error serving path image:', error);
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== 5. مسار البوستر =====
    // ============================================

    app.get('/api/poster', (req, res) => {
      try {
        trackSession(req);

        const filePath = req.query.path || '';
        const isDirectory = req.query.isDirectory === 'true';
        const categoryId = req.query.categoryId || '';
        const driveIndex = parseInt(req.query.driveIndex) || 0;

        if (!filePath) {
          return res.status(404).json({ error: 'المسار غير موجود' });
        }

        let decodedPath = decodeURIComponent(filePath);
        decodedPath = decodedPath.replace(/\\/g, '/');

        let fullPath = null;
        let foundDrive = null;

        if (categoryId && config.categories) {
          const category = config.categories.find((c) => {try {return c.id === categoryId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
          if (category && category.paths && category.paths[driveIndex]) {
            const drive = category.paths[driveIndex];
            const testPath = path.join(drive.path, decodedPath);
            if (fs.existsSync(testPath)) {
              fullPath = testPath;
              foundDrive = drive;
            }
          }
        }

        if (!fullPath && config.categories) {
          for (const category of config.categories) {
            if (!category.paths) continue;
            for (const drive of category.paths) {
              const testPath = path.join(drive.path, decodedPath);
              if (fs.existsSync(testPath)) {
                fullPath = testPath;
                foundDrive = drive;
                break;
              }
            }
            if (fullPath) break;
          }
        }

        if (!fullPath) {
          return res.status(404).json({ error: 'الملف أو المجلد غير موجود' });
        }

        let posterPath = null;

        if (isDirectory) {
          posterPath = findFirstImageInFolder(fullPath);
        } else {
          const dirPath = path.dirname(fullPath);
          posterPath = findFirstImageInFolder(dirPath);
        }

        if (posterPath && fs.existsSync(posterPath)) {
          const mimeType = mime.lookup(posterPath) || 'image/jpeg';
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Cache-Control', 'public, max-age=86400');
          res.setHeader('Access-Control-Allow-Origin', '*');
          return fs.createReadStream(posterPath).pipe(res);
        }

        res.status(404).json({ error: 'لا توجد صورة' });

      } catch (error) {
        console.error('Error in poster API:', error);
        res.status(500).json({ error: error.message });
      }
    });
    // ============================================
    // ===== مسار البوستر المحسن =====
    // ============================================

    // ============================================
    // ===== مسار البوستر المحسن =====
    // ============================================

    app.get('/api/poster-enhanced', (req, res) => {
      try {
        const filePath = req.query.path || '';
        const categoryId = req.query.categoryId || '';
        const driveIndex = parseInt(req.query.driveIndex) || 0;
        const isDirectory = req.query.isDirectory === 'true';

        if (!filePath || !categoryId) {
          console.warn('⚠️ مسار البوستر: الملف أو القسم غير موجود');
          return res.status(404).json({ error: 'المسار أو القسم غير موجود' });
        }

        let decodedPath = decodeURIComponent(filePath);
        decodedPath = decodedPath.replace(/\\/g, '/');

        ////console.log(`🔍 البحث عن بوستر للملف: ${decodedPath}`);
        ////console.log(`📂 القسم: ${categoryId}, driveIndex: ${driveIndex}`);

        // ✅ البحث عن المسار الكامل للملف
        let fullPath = null;
        let foundDrive = null;

        // 1. البحث في القسم المحدد
        const category = config.categories.find((c) => {try {return c.id === categoryId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (category && category.paths) {
          for (let i = 0; i < category.paths.length; i++) {
            const drive = category.paths[i];
            // محاولة مسارات مختلفة
            const possiblePaths = [
            path.join(drive.path, decodedPath),
            path.join(drive.path, path.basename(decodedPath)),
            decodedPath];


            for (const testPath of possiblePaths) {
              try {
                if (fs.existsSync(testPath)) {
                  fullPath = testPath;
                  foundDrive = drive;
                  ////console.log(`✅ تم العثور على الملف: ${fullPath}`);
                  break;
                }
              } catch (e) {}
            }
            if (fullPath) break;
          }
        }

        // 2. إذا لم يتم العثور، البحث في جميع الأقسام
        if (!fullPath) {
          for (const cat of config.categories) {
            if (!cat.paths) continue;
            for (const drive of cat.paths) {
              const testPath = path.join(drive.path, decodedPath);
              try {
                if (fs.existsSync(testPath)) {
                  fullPath = testPath;
                  foundDrive = drive;
                  ////console.log(`✅ تم العثور على الملف في قسم آخر: ${fullPath}`);
                  break;
                }
              } catch (e) {}
            }
            if (fullPath) break;
          }
        }

        if (!fullPath) {
          console.warn(`⚠️ الملف غير موجود: ${decodedPath}`);
          return res.status(404).json({ error: 'الملف غير موجود' });
        }

        // ✅ البحث عن صورة في نفس المجلد
        const dirPath = path.dirname(fullPath);
        ////console.log(`📁 البحث في المجلد: ${dirPath}`);

        let posterPath = null;

        // قائمة أسماء الملفات المحتملة للبوستر
        const posterNames = [
        'poster', 'cover', 'folder', 'album', 'artwork',
        'front', 'back', 'thumbnail', 'thumb',
        '1', '01', 'cover_art', 'album_art', 'icon', 'logo',
        'image', 'img', 'main', 'preview'];


        // ✅ جميع امتدادات الصور
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg', '.tiff', '.ico', '.cur'];

        // 1. البحث عن صورة بنفس اسم الملف
        const fileName = path.basename(fullPath, path.extname(fullPath));
        for (const ext of imageExtensions) {
          const testPath = path.join(dirPath, fileName + ext);
          try {
            if (fs.existsSync(testPath)) {
              posterPath = testPath;
              ////console.log(`✅ تم العثور على صورة بنفس الاسم: ${posterPath}`);
              break;
            }
          } catch (e) {}
        }

        // 2. البحث عن صور بأسماء شائعة
        if (!posterPath) {
          for (const name of posterNames) {
            for (const ext of imageExtensions) {
              const testPath = path.join(dirPath, name + ext);
              try {
                if (fs.existsSync(testPath)) {
                  posterPath = testPath;
                  ////console.log(`✅ تم العثور على صورة باسم ${name}: ${posterPath}`);
                  break;
                }
              } catch (e) {}
            }
            if (posterPath) break;
          }
        }

        // 3. البحث عن أي صورة في المجلد
        if (!posterPath) {
          try {
            const files = fs.readdirSync(dirPath);
            for (const file of files) {
              const ext = path.extname(file).toLowerCase();
              if (imageExtensions.includes(ext)) {
                posterPath = path.join(dirPath, file);
                ////console.log(`✅ تم العثور على صورة عشوائية: ${posterPath}`);
                break;
              }
            }
          } catch (e) {
            console.warn(`⚠️ فشل في قراءة المجلد: ${dirPath}`);
          }
        }

        // 4. البحث في المجلدات الفرعية
        if (!posterPath) {
          const subFolders = ['images', 'covers', 'artwork', 'posters', 'photos', 'thumbnails', 'icons', 'assets'];
          for (const sub of subFolders) {
            const subPath = path.join(dirPath, sub);
            try {
              if (fs.existsSync(subPath) && fs.statSync(subPath).isDirectory()) {
                const files = fs.readdirSync(subPath);
                for (const file of files) {
                  const ext = path.extname(file).toLowerCase();
                  if (imageExtensions.includes(ext)) {
                    posterPath = path.join(subPath, file);
                    ////console.log(`✅ تم العثور على صورة في مجلد فرعي: ${posterPath}`);
                    break;
                  }
                }
              }
            } catch (e) {}
            if (posterPath) break;
          }
        }

        // ✅ إذا تم العثور على صورة، أرسلها
        if (posterPath && fs.existsSync(posterPath)) {
          const mimeType = mime.lookup(posterPath) || 'image/jpeg';
          ////console.log(`📤 إرسال الصورة: ${posterPath} (${mimeType})`);
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Cache-Control', 'public, max-age=86400');
          res.setHeader('Access-Control-Allow-Origin', '*');
          return fs.createReadStream(posterPath).pipe(res);
        }

        // إذا لم يتم العثور على صورة
        if (!posterPath || !fs.existsSync(posterPath)) {
          return sendDefaultImage(res);
        }

        // إرسال الصورة الموجودة
        const mimeType = mime.lookup(posterPath) || 'image/jpeg';
        res.setHeader('Content-Type', mimeType);
        res.setHeader('Cache-Control', 'public, max-age=86400');
        res.setHeader('Access-Control-Allow-Origin', '*');
        return fs.createReadStream(posterPath).pipe(res);

      } catch (error) {
        console.error('❌ خطأ في البوستر المحسن:', error);
        sendDefaultImage(res);
      }
    });
    // ============================================
    // ===== مسار الصور المصغرة للمجلدات =====
    // ============================================

    // ============================================
    // ===== مسار الصور المصغرة (يدعم الفيديو والصور) =====
    // ============================================

    app.get('/api/thumbnail', (req, res) => {
      try {
        const filePath = req.query.path || '';
        const categoryId = req.query.categoryId || '';
        const driveIndex = parseInt(req.query.driveIndex) || 0;

        if (!filePath || !categoryId) {
          return res.status(400).json({ error: 'المسار والقسم مطلوبان' });
        }

        let decodedPath = decodeURIComponent(filePath);
        decodedPath = decodedPath.replace(/\\/g, '/');

        // البحث عن المسار الكامل للملف
        let fullPath = null;
        const category = config.categories.find((c) => {try {return c.id === categoryId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (category && category.paths && category.paths[driveIndex]) {
          const drive = category.paths[driveIndex];
          const possiblePaths = [
          path.join(drive.path, decodedPath),
          path.join(drive.path, path.basename(decodedPath)),
          decodedPath];


          for (const testPath of possiblePaths) {
            if (fs.existsSync(testPath)) {
              fullPath = testPath;
              break;
            }
          }
        }

        if (!fullPath) {
          for (const cat of config.categories) {
            if (!cat.paths) continue;
            for (const drive of cat.paths) {
              const testPath = path.join(drive.path, decodedPath);
              if (fs.existsSync(testPath)) {
                fullPath = testPath;
                break;
              }
            }
            if (fullPath) break;
          }
        }

        if (!fullPath) {
          console.warn(`⚠️ الملف غير موجود: ${decodedPath}`);
          return res.status(404).json({ error: 'الملف غير موجود' });
        }

        const ext = path.extname(fullPath).toLowerCase();

        // ✅ ✅ ✅ دعم جميع امتدادات الصور بما في ذلك .ico
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg', '.tiff', '.ico', '.cur'];
        const videoExtensions = ['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v', '.mpg', '.mpeg', '.3gp', '.ogv', '.ts', '.mts'];

        // ✅ إذا كان الملف صورة (بما في ذلك .ico)
        if (imageExtensions.includes(ext)) {
          const mimeType = mime.lookup(fullPath) || 'image/x-icon';
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Cache-Control', 'public, max-age=86400');
          res.setHeader('Access-Control-Allow-Origin', '*');

          const stat = fs.statSync(fullPath);
          res.setHeader('Content-Length', stat.size);

          const stream = fs.createReadStream(fullPath);
          stream.pipe(res);

          stream.on('error', (err) => {try {
              console.error('❌ خطأ في إرسال الصورة:', err);
              if (!res.headersSent) {
                res.status(500).json({ error: 'فشل إرسال الصورة' });
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
          return;
        }

        // ✅ إذا كان الملف فيديو
        if (videoExtensions.includes(ext)) {
          const encodedPath = encodeURIComponent(decodedPath);
          const posterUrl = `/api/poster-enhanced?path=${encodedPath}&categoryId=${categoryId}&driveIndex=${driveIndex}`;
          return res.redirect(posterUrl);
        }

        // ✅ إذا كان الملف ليس صورة ولا فيديو، حاول البحث عن صورة في نفس المجلد
        const dirPath = path.dirname(fullPath);
        let posterPath = null;

        // قائمة أسماء الملفات المحتملة للبوستر
        const posterNames = [
        'poster', 'cover', 'folder', 'album', 'artwork',
        'front', 'back', 'thumbnail', 'thumb',
        '1', '01', 'cover_art', 'album_art', 'icon', 'logo'];


        // 1. البحث عن صورة بنفس اسم الملف
        const fileName = path.basename(fullPath, path.extname(fullPath));
        for (const ext2 of imageExtensions) {
          const testPath = path.join(dirPath, fileName + ext2);
          if (fs.existsSync(testPath)) {
            posterPath = testPath;
            break;
          }
        }

        // 2. البحث عن صور بأسماء شائعة
        if (!posterPath) {
          for (const name of posterNames) {
            for (const ext2 of imageExtensions) {
              const testPath = path.join(dirPath, name + ext2);
              if (fs.existsSync(testPath)) {
                posterPath = testPath;
                break;
              }
            }
            if (posterPath) break;
          }
        }

        // 3. البحث عن أي صورة في المجلد (بما في ذلك .ico)
        if (!posterPath) {
          try {
            const files = fs.readdirSync(dirPath);
            for (const file of files) {
              const ext2 = path.extname(file).toLowerCase();
              if (imageExtensions.includes(ext2)) {
                posterPath = path.join(dirPath, file);
                break;
              }
            }
          } catch (e) {}
        }

        // 4. البحث في المجلدات الفرعية
        if (!posterPath) {
          const subFolders = ['images', 'covers', 'artwork', 'posters', 'photos', 'thumbnails', 'icons'];
          for (const sub of subFolders) {
            const subPath = path.join(dirPath, sub);
            try {
              if (fs.existsSync(subPath) && fs.statSync(subPath).isDirectory()) {
                const files = fs.readdirSync(subPath);
                for (const file of files) {
                  const ext2 = path.extname(file).toLowerCase();
                  if (imageExtensions.includes(ext2)) {
                    posterPath = path.join(subPath, file);
                    break;
                  }
                }
              }
            } catch (e) {}
            if (posterPath) break;
          }
        }

        if (posterPath && fs.existsSync(posterPath)) {
          const mimeType = mime.lookup(posterPath) || 'image/jpeg';
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Cache-Control', 'public, max-age=86400');
          res.setHeader('Access-Control-Allow-Origin', '*');
          return fs.createReadStream(posterPath).pipe(res);
        }
        // إذا لم توجد صورة
        return sendDefaultImage(res);
      } catch (error) {
        console.error('❌ خطأ في مسار الصور المصغرة:', error);
        sendDefaultImage(res);
      }
    });
    // ============================================
    // ===== 6. مسار تشغيل الملفات =====
    // ============================================

    // ============================================
    // ===== مسار تشغيل الملفات مع معالجة الأخطاء =====
    // ============================================
    // ============================================
    // ===== مسار قراءة الكاش من الملف =====
    // ============================================

    app.get('/api/search-cache', (req, res) => {
      try {
        const SYNC_CACHE_FILE = getDataPath('sync_cache.json');

        if (!fs.existsSync(SYNC_CACHE_FILE)) {
          return res.status(404).json({
            success: false,
            error: 'ملف الكاش غير موجود'
          });
        }

        const data = fs.readFileSync(SYNC_CACHE_FILE, 'utf8');
        const cache = JSON.parse(data);

        // تحويل البيانات إلى صيغة مناسبة للبحث
        const searchData = {
          success: true,
          data: {
            categories: {},
            totalFiles: 0,
            totalFolders: 0,
            lastSync: cache.lastSync || null
          }
        };

        // استخراج البيانات من الكاش
        if (cache.categories) {
          for (const [categoryId, catData] of Object.entries(cache.categories)) {
            searchData.data.categories[categoryId] = {
              id: categoryId,
              name: catData.categoryName || 'قسم',
              icon: catData.categoryIcon || '📁',
              color: catData.categoryColor || '#667eea',
              files: [],
              folders: [],
              totalFiles: catData.totalFiles || 0
            };

            // استخراج الملفات
            if (catData.files && Array.isArray(catData.files)) {
              for (const file of catData.files) {
                const ext = file.extension || '';
                let icon = '📄';
                let type = 'ملف';

                if (VIDEO_EXTENSIONS && VIDEO_EXTENSIONS.includes(ext)) {
                  icon = '🎬';
                  type = 'فيديو';
                } else if (AUDIO_EXTENSIONS && AUDIO_EXTENSIONS.includes(ext)) {
                  icon = '🎵';
                  type = 'صوت';
                } else if (IMAGE_EXTENSIONS && IMAGE_EXTENSIONS.includes(ext)) {
                  icon = '🖼️';
                  type = 'صورة';
                }

                // استخراج مسار المجلد
                let folderPath = '';
                const filePath = file.path || file.fullPath || '';
                if (filePath) {
                  const normalized = filePath.replace(/\\/g, '/');
                  const lastSlash = normalized.lastIndexOf('/');
                  if (lastSlash > 0) {
                    folderPath = normalized.substring(0, lastSlash);
                  }
                }

                searchData.data.categories[categoryId].files.push({
                  name: file.name || 'ملف',
                  path: file.path || file.fullPath || '',
                  folderPath: folderPath,
                  extension: ext,
                  size: file.size || 0,
                  modified: file.modified || Date.now(),
                  icon: icon,
                  type: type,
                  driveIndex: file.driveIndex || 0
                });
              }
              searchData.data.totalFiles += catData.files.length;
            }
          }
        }

        res.json(searchData);

      } catch (error) {
        console.error('❌ خطأ في قراءة كاش البحث:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== مسار تحميل الكاش للبحث (بديل) =====
    // ============================================

    app.get('/api/search-cache/download', (req, res) => {
      try {
        const SYNC_CACHE_FILE = getDataPath('sync_cache.json');

        if (!fs.existsSync(SYNC_CACHE_FILE)) {
          return res.status(404).json({
            success: false,
            error: 'ملف الكاش غير موجود'
          });
        }

        const data = fs.readFileSync(SYNC_CACHE_FILE, 'utf8');

        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Cache-Control', 'public, max-age=3600');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.send(data);

      } catch (error) {
        console.error('❌ خطأ في تحميل الكاش:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });
    app.get('/api/category/:id/stream/*', (req, res) => {
      try {
        const id = req.params.id; // categoryId
        let filePath = req.params[0]; // مسار الملف النسبي

        let decodedPath = decodeURIComponent(filePath);
        let fixedPath = decodedPath.replace(/\\/g, '/');
        fixedPath = fixedPath.replace(/\/+/g, '/');

        const driveIndex = parseInt(req.query.driveIndex) || 0;
        const isDownload = req.query.download === 'true';

        // البحث عن القسم
        const category = config.categories.find((c) => {try {return c.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (!category || category.enabled === false) {
          return res.status(404).json({ error: 'القسم غير موجود' });
        }

        if (!category.paths || driveIndex >= category.paths.length) {
          return res.status(404).json({ error: 'المسار غير موجود' });
        }

        const drive = category.paths[driveIndex];
        let fullPath = null;

        // بناء المسار الكامل
        if (fixedPath.match(/^[A-Za-z]:\//)) {
          // مسار مطلق
          fullPath = fixedPath;
        } else {
          let drivePath = drive.path.replace(/\\/g, '/');
          if (!drivePath.endsWith('/')) drivePath += '/';
          let relativePath = fixedPath;
          if (relativePath.startsWith('/')) relativePath = relativePath.substring(1);
          fullPath = drivePath + relativePath;
        }

        // التحقق من وجود الملف
        if (!fs.existsSync(fullPath)) {
          // محاولة البحث في مسارات أخرى (كحل احتياطي)
          let foundPath = null;
          for (const cat of config.categories) {
            if (!cat.paths) continue;
            for (const d of cat.paths) {
              let dPath = d.path.replace(/\\/g, '/');
              if (!dPath.endsWith('/')) dPath += '/';
              const testPath = dPath + fixedPath;
              if (fs.existsSync(testPath)) {
                foundPath = testPath;
                break;
              }
            }
            if (foundPath) break;
          }
          if (foundPath) {
            fullPath = foundPath;
          } else {
            return res.status(404).json({ error: 'الملف غير موجود', path: fullPath });
          }
        }

        // التحقق من امتداد الملف: إذا كان يحتاج تحويل (AVI, MKV, ...) استخدم FFmpeg
        const ext = path.extname(fullPath).toLowerCase();
        if (TRANSCODE_EXTS.includes(ext) && !isDownload) {
          // //console.log(`🎬 FFmpeg تحويل: ${path.basename(fullPath)} (${ext})`);
          return transcodeAndStream(fullPath, req, res);
        }

        // ==== استدعاء streamFile مع تمرير drive.id ====
        // نقوم بتمرير معرف المسار (drive.id) لتمكين التحقق من المنع
        streamFile(fullPath, req, res, isDownload, drive.id);

      } catch (error) {
        console.error('❌ خطأ في التشغيل:', error);
        if (error.message && error.message.includes('Range Not Satisfiable')) {
          return res.status(416).json({
            error: 'Range Not Satisfiable',
            code: 'RANGE_NOT_SATISFIABLE',
            message: 'النطاق المطلوب غير متوفر في الملف'
          });
        }
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== 7. مسار التحميل =====
    // ============================================

    app.get('/api/download', (req, res) => {
      try {
        const filePath = req.query.path;
        const categoryId = req.query.categoryId;
        const driveIndex = parseInt(req.query.driveIndex) || 0;

        if (!filePath) {
          return res.status(400).json({ error: 'المسار مطلوب' });
        }

        const decodedPath = decodeURIComponent(filePath);

        let fullPath = null;
        let foundDrive = null;

        if (categoryId && config.categories) {
          const category = config.categories.find((c) => {try {return c.id === categoryId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
          if (category && category.paths && category.paths[driveIndex]) {
            const drive = category.paths[driveIndex];
            const testPath = path.join(drive.path, decodedPath);
            if (fs.existsSync(testPath)) {
              fullPath = testPath;
              foundDrive = drive;
            }
          }
        }

        if (!fullPath && config.categories) {
          for (const category of config.categories) {
            if (!category.paths) continue;
            for (const drive of category.paths) {
              const testPath = path.join(drive.path, decodedPath);
              if (fs.existsSync(testPath)) {
                fullPath = testPath;
                foundDrive = drive;
                break;
              }
            }
            if (fullPath) break;
          }
        }

        if (!fullPath) {
          console.error(`❌ الملف غير موجود: ${decodedPath}`);
          return res.status(404).json({ error: 'الملف غير موجود' });
        }

        if (foundDrive) {
          const pathId = foundDrive.id;
          const fileName = path.basename(fullPath);

          if (!isDownloadAllowed(pathId, fileName)) {
            return res.status(403).json({
              error: '🚫 تحميل هذا الملف غير مسموح به',
              code: 'DOWNLOAD_BLOCKED'
            });
          }
        }

        const stat = fs.statSync(fullPath);
        const fileSize = stat.size;
        const mimeType = mime.lookup(fullPath) || 'application/octet-stream';
        const fileName = encodeURIComponent(path.basename(fullPath));

        res.setHeader('Content-Type', mimeType);
        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        res.setHeader('Content-Length', fileSize);
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, Content-Length');

        const clientIp = req.headers['x-forwarded-for'] || req.connection?.remoteAddress || 'unknown';
        const userId = getUserId(req); // استخدم userId إن أمكن
        const userSpeed = getUserSpeed(userId); // أو clientIp مؤقتاً
        const session = trackSession(req, fullPath);
        const sessionId = session?.id;

        const fileStream = fs.createReadStream(fullPath);

        if (speedConfig.enabled && userSpeed > 0) {
          throttleStream(fileStream, res, userSpeed, fileSize, sessionId);
        } else {
          fileStream.pipe(res);
        }
      } catch (error) {
        console.error('❌ خطأ في التحميل:', error);
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== 8. مسار التحقق من الملف =====
    // ============================================

// تسجيل زيارة صفحة
app.post('/api/track/pageview', (req, res) => {
    try {
        const { page, referrer } = req.body;
        const userId = getUserId(req);
        const { ip, device } = getClientInfo(req);
        
        const pageViews = loadPageViews();
        const today = new Date().toISOString().split('T')[0];
        
        // تهيئة البيانات
        if (!pageViews.daily) pageViews.daily = {};
        if (!pageViews.users) pageViews.users = {};
        if (!pageViews.pages) pageViews.pages = {};
        
        // تسجيل يومي
        if (!pageViews.daily[today]) {
            pageViews.daily[today] = { views: 0, uniqueUsers: new Set() };
        }
        pageViews.daily[today].views++;
        pageViews.daily[today].uniqueUsers.add(userId);
        
        // تسجيل حسب الصفحة
        if (!pageViews.pages[page]) {
            pageViews.pages[page] = { views: 0, users: new Set() };
        }
        pageViews.pages[page].views++;
        pageViews.pages[page].users.add(userId);
        
        // تسجيل حسب المستخدم
        if (!pageViews.users[userId]) {
            pageViews.users[userId] = { 
                visits: 0, 
                pages: {}, 
                firstVisit: Date.now(),
                ip,
                device
            };
        }
        pageViews.users[userId].visits++;
        pageViews.users[userId].lastVisit = Date.now();
        pageViews.users[userId].pages[page] = (pageViews.users[userId].pages[page] || 0) + 1;
        
        // تحويل Sets إلى Arrays للحفظ
        const toSave = {
            daily: {},
            users: pageViews.users,
            pages: {}
        };
        
        for (const [date, data] of Object.entries(pageViews.daily)) {
            toSave.daily[date] = {
                views: data.views,
                uniqueUsers: data.uniqueUsers instanceof Set 
                    ? data.uniqueUsers.size 
                    : data.uniqueUsers
            };
        }
        
        for (const [page, data] of Object.entries(pageViews.pages)) {
            toSave.pages[page] = {
                views: data.views,
                users: data.users instanceof Set ? data.users.size : data.users
            };
        }
        
        savePageViews(toSave);
        
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// جلب إحصائيات الزيارات
app.get('/api/reports/pageviews', (req, res) => {
    try {
        const pageViews = loadPageViews();
        const { period = '30' } = req.query; // آخر 30 يوم
        
        const days = parseInt(period) || 30;
        const now = new Date();
        const dailyStats = [];
        
        for (let i = days - 1; i >= 0; i--) {
            const date = new Date(now);
            date.setDate(date.getDate() - i);
            const dateStr = date.toISOString().split('T')[0];
            
            const dayData = pageViews.daily?.[dateStr] || { views: 0, uniqueUsers: 0 };
            dailyStats.push({
                date: dateStr,
                views: dayData.views || 0,
                uniqueUsers: dayData.uniqueUsers || 0
            });
        }
        
        // إحصائيات إجمالية
        const totalViews = Object.values(pageViews.daily || {})
            .reduce((sum, d) => sum + (d.views || 0), 0);
        
        const today = new Date().toISOString().split('T')[0];
        const todayViews = pageViews.daily?.[today]?.views || 0;
        
        res.json({
            success: true,
            summary: {
                totalViews,
                todayViews,
                totalUniqueUsers: Object.keys(pageViews.users || {}).length,
                averageDailyViews: dailyStats.length > 0 
                    ? Math.round(totalViews / dailyStats.length) 
                    : 0
            },
            dailyStats,
            topPages: Object.entries(pageViews.pages || {})
                .map(([page, data]) => ({ page, ...data }))
                .sort((a, b) => b.views - a.views)
                .slice(0, 20),
            recentUsers: Object.entries(pageViews.users || {})
                .map(([userId, data]) => ({ userId, ...data }))
                .sort((a, b) => b.lastVisit - a.lastVisit)
                .slice(0, 50)
        });
        
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
    app.get('/api/check-file', (req, res) => {
      try {
        const filePath = req.query.path;
        const categoryId = req.query.categoryId;
        const driveIndex = parseInt(req.query.driveIndex) || 0;

        if (!filePath) {
          return res.status(400).json({ error: 'المسار مطلوب' });
        }

        const decodedPath = decodeURIComponent(filePath);
        let fullPath = null;

        if (categoryId && config.categories) {
          const category = config.categories.find((c) => {try {return c.id === categoryId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
          if (category && category.paths && category.paths[driveIndex]) {
            const drive = category.paths[driveIndex];
            const testPath = path.join(drive.path, decodedPath);
            if (fs.existsSync(testPath)) {
              fullPath = testPath;
            }
          }
        }

        if (!fullPath && config.categories) {
          for (const category of config.categories) {
            if (!category.paths) continue;
            for (const drive of category.paths) {
              const testPath = path.join(drive.path, decodedPath);
              if (fs.existsSync(testPath)) {
                fullPath = testPath;
                break;
              }
            }
            if (fullPath) break;
          }
        }

        if (fullPath) {
          const stat = fs.statSync(fullPath);
          res.json({
            exists: true,
            path: fullPath,
            size: stat.size,
            name: path.basename(fullPath)
          });
        } else {
          res.json({
            exists: false,
            error: 'الملف غير موجود'
          });
        }
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== 9. مسارات التصفح =====
    // ============================================

    app.get('/api/browse', (req, res) => {
      try {
        trackSession(req);

        const currentPath = req.query.path || '';

        let fullPath = currentPath;
        if (!fullPath || fullPath === '') {
          if (process.platform === 'win32') {
            const drives = [];
            for (let i = 65; i <= 90; i++) {
              const drive = String.fromCharCode(i) + ':/';
              try {
                if (fs.existsSync(drive)) {
                  drives.push({
                    name: drive,
                    path: drive,
                    isDirectory: true,
                    isDrive: true
                  });
                }
              } catch (e) {}
            }
            return res.json({
              success: true,
              path: '',
              items: drives,
              isRoot: true
            });
          } else {
            fullPath = '/';
          }
        }

        if (fullPath.match(/^[A-Za-z]:[^\\/]/)) {
          fullPath = fullPath.replace(/^([A-Za-z]):/, '$1:/');
        }
        fullPath = fullPath.replace(/\\/g, '/');

        const items = fs.readdirSync(fullPath);
        const result = items.map((item) => {
          const itemPath = path.join(fullPath, item);
          try {
            const stat = fs.statSync(itemPath);
            return {
              name: item,
              path: itemPath,
              isDirectory: stat.isDirectory(),
              isDrive: false
            };
          } catch (e) {
            return null;
          }
        }).filter((item) => {try {return item !== null && item.isDirectory;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        result.sort((a, b) => {try {return a.name.localeCompare(b.name);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        res.json({
          success: true,
          path: fullPath,
          items: result,
          isRoot: false,
          parent: path.dirname(fullPath)
        });
      } catch (error) {
        console.error('Error browsing:', error);
        res.status(404).json({
          success: false,
          error: 'لا يمكن الوصول إلى هذا المسار'
        });
      }
    });

    app.get('/api/drives/all', (req, res) => {
      try {
        trackSession(req);
        const allDrives = [];
        if (config.categories) {
          config.categories.forEach((cat) => {try {
              if (cat.paths) {
                cat.paths.forEach((p) => {try {
                    if (!p || typeof p !== 'object') return;
                    // ✅ استخدم المعرف المخزن في config مباشرة
                    const pathId = p.id;
                    if (!pathId) {
                      console.warn('⚠️ مسار بدون معرف:', p);
                      return;
                    }
                    allDrives.push({
                      id: pathId, // ✅ المعرف الثابت
                      name: p.name || path.basename(p.path) || 'مسار',
                      path: p.path,
                      type: p.type || 'all',
                      categoryId: cat.id,
                      categoryName: cat.name,
                      enabled: cat.enabled !== false
                    });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
                });
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
        }
        res.json({ success: true, drives: allDrives });
      } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ success: false, error: error.message });
      }
    });
// ===== جلب عدد المشاهدات لملف (أو مجموعة) =====
app.get('/api/views', (req, res) => {
    try {
        const filePath = req.query.path;
        const categoryId = req.query.categoryId;
        const driveIndex = parseInt(req.query.driveIndex) || 0;
        if (!filePath || !categoryId) {
            return res.status(400).json({ success: false, error: 'المسار والقسم مطلوبان' });
        }
        const views = loadViews();
        const key = `${categoryId}:${driveIndex}:${filePath}`;
        res.json({ success: true, views: views[key] || 0 });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ===== زيادة عدد المشاهدات لملف =====
app.post('/api/views/increment', (req, res) => {
    try {
        const { filePath, categoryId, driveIndex } = req.body;
        if (!filePath || !categoryId) {
            return res.status(400).json({ success: false, error: 'المسار والقسم مطلوبان' });
        }
        const views = loadViews();
        const key = `${categoryId}:${driveIndex || 0}:${filePath}`;
        views[key] = (views[key] || 0) + 1;
        saveViews(views);
        res.json({ success: true, views: views[key] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============================================
// ===== API: معلومات setup =====
// ============================================

app.get('/api/updates/setup-info', (req, res) => {
  try {
    const info = {
      setupDir: SETUP_DIR,
      updatesDir: UPDATES_DIR,
      cacheDir: CACHE_DIR,
      launcherExists: fs.existsSync(LAUNCHER_EXE),
      currentVersion: getCurrentVersion(),
      pendingUpdate: null,
      updatesContent: []
    };

    // محتوى مجلد updates
    if (fs.existsSync(UPDATES_DIR)) {
      info.updatesContent = fs.readdirSync(UPDATES_DIR).map(f => {
        const p = path.join(UPDATES_DIR, f);
        const stat = fs.statSync(p);
        return {
          name: f,
          isDirectory: stat.isDirectory(),
          size: stat.size
        };
      });
    }

    // الإصدار المعلّق
    const versionFile = path.join(UPDATES_DIR, 'current.version');
    if (fs.existsSync(versionFile)) {
      const version = fs.readFileSync(versionFile, 'utf8').trim();
      const serverJs = path.join(UPDATES_DIR, 'server.js');
      if (fs.existsSync(serverJs)) {
        info.pendingUpdate = {
          version,
          ready: true,
          size: fs.statSync(serverJs).size
        };
      }
    }

    res.json({ success: true, info });

  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ===== API: تنزيل تحديث من GitHub =====
// ============================================

app.post('/api/updates/download', async (req, res) => {
  try {
    const { version, downloadUrl } = req.body;

    if (!version || !downloadUrl) {
      return res.status(400).json({
        success: false,
        error: 'الإصدار والرابط مطلوبان'
      });
    }

    res.json({
      success: true,
      message: 'بدأ التنزيل في الخلفية',
      version
    });

    // تنزيل في الخلفية
    downloadUpdate(version, downloadUrl)
      .then(result => {
        if (result.success) {
          console.log('✅ اكتمل التنزيل');
          sendNotification('download_complete', { version });
        }
      })
      .catch(err => console.error('❌ خطأ:', err));

  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ===== API: تقدم التنزيل =====
// ============================================

app.get('/api/updates/download/progress', (req, res) => {
  res.json({
    success: true,
    isDownloading,
    progress: downloadProgress
  });
});

// ============================================
// ===== API: تثبيت التحديث (تشغيل launcher) =====
// ============================================

app.post('/api/updates/install', async (req, res) => {
  try {
    // التحقق من وجود الملفات في updates
    const serverJs = path.join(UPDATES_DIR, 'server.js');
    const packageJson = path.join(UPDATES_DIR, 'package.json');

    if (!fs.existsSync(serverJs)) {
      return res.status(400).json({
        success: false,
        error: 'server.js غير موجود في updates - يرجى التنزيل أولاً'
      });
    }

    if (!fs.existsSync(packageJson)) {
      return res.status(400).json({
        success: false,
        error: 'package.json غير موجود في updates - يرجى التنزيل أولاً'
      });
    }

    if (!fs.existsSync(LAUNCHER_EXE)) {
      return res.status(400).json({
        success: false,
        error: 'launcher.exe غير موجود في setup'
      });
    }

    // قراءة الإصدار
    let version = 'unknown';
    const versionFile = path.join(UPDATES_DIR, 'current.version');
    if (fs.existsSync(versionFile)) {
      version = fs.readFileSync(versionFile, 'utf8').trim();
    }

    // إرسال الاستجابة
    res.json({
      success: true,
      message: `بدأ التثبيت - سيتم إغلاق السيرفر وتشغيل launcher.exe`,
      version
    });

    // إنشاء نسخة احتياطية
    if (updateConfig.autoBackupBeforeUpdate) {
      console.log('💾 إنشاء نسخة احتياطية...');
      createPreUpdateBackup(version);
    }

    // تشغيل launcher.exe
    setTimeout(() => {
      console.log('🚀 تشغيل launcher.exe...');
      
      const { spawn } = require('child_process');
      spawn(LAUNCHER_EXE, [], {
        detached: true,
        stdio: 'ignore',
        cwd: SETUP_DIR,
        windowsHide: false
      }).unref();

      // إغلاق السيرفر الحالي
      setTimeout(() => process.exit(0), 2000);
    }, 1000);

  } catch (error) {
    console.error('❌ خطأ في التثبيت:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ===== API: جلب الإصدارات من GitHub =====
// ============================================

app.get('/api/updates/available-versions', async (req, res) => {
  try {
    const result = await checkForUpdates();

    if (!result.success) {
      return res.status(500).json(result);
    }

    const versions = (result.allVersions || []).map(v => ({
      version: v.version,
      releaseDate: v.releaseDate,
      changelog: v.changelog,
      downloadUrl: v.downloadUrl,
      size: v.size,
      sizeMB: v.size ? (v.size / 1024 / 1024).toFixed(2) : '?',
      isCurrent: v.version === result.currentVersion,
      isNewer: compareVersions(v.version, result.currentVersion) > 0,
      isOlder: compareVersions(v.version, result.currentVersion) < 0,
      prerelease: v.prerelease
    }));

    res.json({
      success: true,
      currentVersion: result.currentVersion,
      versions
    });

  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ===== API: إعدادات التحديث =====
// ============================================

app.get('/api/updates/config', (req, res) => {
  res.json({
    success: true,
    config: {
      ...updateConfig,
      currentVersion: getCurrentVersion()
    }
  });
});

app.post('/api/updates/config', (req, res) => {
  try {
    const { updateServerUrl, autoCheck, checkInterval } = req.body;

    if (updateServerUrl !== undefined) updateConfig.updateServerUrl = updateServerUrl.trim();
    if (autoCheck !== undefined) updateConfig.autoCheck = autoCheck;
    if (checkInterval !== undefined) updateConfig.checkInterval = Math.max(300000, parseInt(checkInterval));

    if (saveUpdateConfig(updateConfig)) {
      res.json({
        success: true,
        message: 'تم حفظ الإعدادات',
        config: updateConfig
      });
    } else {
      res.status(500).json({ success: false, error: 'فشل الحفظ' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ===== API: اختبار الاتصال بـ GitHub =====
// ============================================

app.post('/api/updates/test-connection', async (req, res) => {
  const startTime = Date.now();

  try {
    const { url } = req.body;

    if (!url) {
      return res.status(400).json({ success: false, error: 'الرابط مطلوب' });
    }

    try {
      new URL(url);
    } catch (e) {
      return res.status(400).json({ success: false, error: 'الرابط غير صالح' });
    }

    console.log(`🧪 اختبار الاتصال بـ: ${url}`);

    const response = await axios.get(url, {
      timeout: 15000,
      headers: {
        'User-Agent': `ZainServer/${getCurrentVersion()}`,
        'Accept': 'application/vnd.github+json'
      }
    });

    const responseTime = Date.now() - startTime;
    const releases = Array.isArray(response.data) ? response.data : (response.data.versions || []);
    const currentVersion = getCurrentVersion();

    const versions = releases.map(r => ({
      version: (r.tag_name || r.version || '').replace(/^v/, ''),
      downloadUrl: (r.assets && r.assets[0] && r.assets[0].browser_download_url) || r.downloadUrl || '',
      prerelease: r.prerelease || false
    })).filter(v => v.version && v.downloadUrl);

    const newerVersions = versions.filter(v => 
      compareVersions(v.version, currentVersion) > 0
    );

    let latestVersion = null;
    if (newerVersions.length > 0) {
      newerVersions.sort((a, b) => compareVersions(b.version, a.version));
      latestVersion = newerVersions[0].version;
    }

    res.json({
      success: true,
      message: 'الاتصال ناجح',
      versionsCount: versions.length,
      currentVersion,
      latestVersion,
      hasUpdate: newerVersions.length > 0,
      newerVersionsCount: newerVersions.length,
      responseTime
    });

  } catch (error) {
    const responseTime = Date.now() - startTime;

    let errorMessage = error.message;
    if (error.code === 'ECONNREFUSED') errorMessage = 'تم رفض الاتصال';
    else if (error.code === 'ETIMEDOUT') errorMessage = 'انتهت المهلة';
    else if (error.code === 'ENOTFOUND') errorMessage = 'السيرفر غير موجود';
    else if (error.response) errorMessage = `HTTP ${error.response.status}`;

    res.json({
      success: false,
      error: errorMessage,
      responseTime,
      errorCode: error.code
    });
  }
});

// ============================================
// ===== API: تفريغ مجلد updates =====
// ============================================

app.delete('/api/updates/clear', (req, res) => {
  try {
    if (!fs.existsSync(UPDATES_DIR)) {
      return res.json({ success: true, message: 'المجلد فارغ أصلاً' });
    }

    for (const item of fs.readdirSync(UPDATES_DIR)) {
      const p = path.join(UPDATES_DIR, item);
      try {
        if (fs.statSync(p).isDirectory()) {
          fs.rmSync(p, { recursive: true, force: true });
        } else {
          fs.unlinkSync(p);
        }
      } catch (e) {}
    }

    res.json({ success: true, message: 'تم تفريغ مجلد updates' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ===== جلب مشاهدات متعددة (دفعة) =====
app.post('/api/views/batch', (req, res) => {
    try {
        const { files } = req.body;
        if (!files || !Array.isArray(files)) {
            return res.status(400).json({ success: false, error: 'قائمة الملفات مطلوبة' });
        }
        const views = loadViews();
        const result = {};
        for (const file of files) {
            const key = `${file.categoryId}:${file.driveIndex || 0}:${file.path}`;
            result[key] = views[key] || 0;
        }
        res.json({ success: true, views: result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
    app.put('/api/drives/update/:id', (req, res) => {
      try {
        trackSession(req);

        const id = req.params.id;
        const { enabled, name, type } = req.body;

        let found = false;
        if (config.categories) {
          for (const cat of config.categories) {
            if (cat.paths) {
              for (let i = 0; i < cat.paths.length; i++) {
                const pathId = cat.paths[i].id || cat.id + '_path_' + i;
                if (pathId === id) {
                  if (enabled !== undefined) {
                    cat.enabled = enabled;
                  }
                  if (name) {
                    cat.paths[i].name = name;
                  }
                  if (type && Object.keys(FILE_TYPES).includes(type)) {
                    cat.paths[i].type = type;
                  }
                  found = true;
                  break;
                }
              }
            }
            if (found) break;
          }
        }

        if (!found) {
          return res.status(404).json({
            success: false,
            error: 'المسار غير موجود'
          });
        }

        if (saveConfig(config)) {
          res.json({
            success: true,
            message: 'تم تحديث المسار بنجاح'
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ الإعدادات'
          });
        }
      } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.delete('/api/drives/remove/:id', (req, res) => {
      try {
        trackSession(req);

        const id = req.params.id;

        let found = false;
        if (config.categories) {
          for (const cat of config.categories) {
            if (cat.paths) {
              const index = cat.paths.findIndex((p, idx) => {try {
                  if (!p || typeof p !== 'object') return false;
                  const pathId = p.id || cat.id + '_path_' + idx;
                  return pathId === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
              });
              if (index !== -1) {
                cat.paths.splice(index, 1);
                found = true;
                break;
              }
            }
          }
        }

        if (!found) {
          return res.status(404).json({
            success: false,
            error: 'المسار غير موجود'
          });
        }

        if (saveConfig(config)) {
          res.json({
            success: true,
            message: 'تم حذف المسار بنجاح'
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ الإعدادات'
          });
        }
      } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== 10. مسارات الإحصائيات =====
    // ============================================

    app.get('/api/active-users', (req, res) => {
      try {
        const online = activeSessions.filter((s) => {try {return Date.now() - s.lastActivity < 120000;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        res.json({
          success: true,
          online: online.length,
          totalSessions: totalSessions,
          peakUsers: peakUsers,
          users: online.map((s) => {try {return {
                id: s.id,
                username: s.username || 'زائر',
                ip: s.ip,
                device: s.device,
                currentFile: s.currentFile || 'تصفح',
                progress: s.progress || 0,
                speed: s.speed || 0,
                connected: s.connected,
                lastActivity: s.lastActivity,
                isActive: true
              };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}})
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.get('/api/bandwidth', (req, res) => {
      try {
        const totalSpeed = activeSessions.reduce((sum, s) => {try {return sum + (s.speed || 0);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}, 0);
        res.json({
          success: true,
          currentSpeed: parseFloat(totalSpeed.toFixed(2)),
          sessions: activeSessions.length,
          peak: peakUsers,
          totalSessions: totalSessions
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.get('/api/stats', (req, res) => {
      try {
        const online = activeSessions.filter((s) => {try {return Date.now() - s.lastActivity < 120000;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        const totalSpeed = activeSessions.reduce((sum, s) => {try {return sum + (s.speed || 0);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}, 0);

        let totalFiles = 0;
        if (config.categories) {
          config.categories.forEach((cat) => {try {
              if (cat.paths) {
                cat.paths.forEach((p) => {
                  try {
                    if (fs.existsSync(p.path)) {
                      const items = fs.readdirSync(p.path);
                      totalFiles += items.length;
                    }
                  } catch (e) {}
                });
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
        }

        res.json({
          success: true,
          stats: {
            categories: config.categories?.length || 0,
            paths: config.categories?.reduce((sum, c) => {try {return sum + (c.paths?.length || 0);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}, 0) || 0,
            totalFiles: totalFiles,
            onlineUsers: online.length,
            totalSessions: totalSessions,
            peakUsers: peakUsers,
            currentBandwidth: parseFloat(totalSpeed.toFixed(2))
          }
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // ============================================
    // ===== 11. مسارات نظام الترخيص =====
    // ============================================

    app.get('/api/system/status', async (req, res) => {
      try {
        const serial = await getMotherboardSerial();
        const check = await checkBreakExists(serial);

        if (check.exists) {
          const license = await checkBreakLicense(check.breakData.id);
          res.json({
            success: true,
            status: 'existing',
            breakData: check.breakData,
            license: license,
            serial: serial
          });
        } else {
          res.json({
            success: true,
            status: 'new',
            serial: serial,
            message: 'جهاز جديد - يرجى التسجيل'
          });
        }
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/system/register', async (req, res) => {
      try {
        const {
          name_break,
          phone_num,
          info,
          name,
          password,
          licenseOption
        } = req.body;

        if (!phone_num) {
          return res.status(400).json({
            success: false,
            error: 'رقم الهاتف مطلوب'
          });
        }

        const serial = await getMotherboardSerial();

        const check = await checkBreakExists(serial);
        if (check.exists) {
          return res.status(400).json({
            success: false,
            error: 'هذا الجهاز مسجل بالفعل'
          });
        }

        const breakResult = await createBreak({
          name_break: name_break || 'استراحة',
          phone_num: phone_num,
          serial_motherboard: serial,
          info: info || '',
          name: name || 'admin',
          password: password || 'admin123'
        });

        if (!breakResult.success) {
          console.error('❌ فشل إنشاء الاستراحة:', breakResult.error);
          return res.status(500).json({
            success: false,
            error: breakResult.error
          });
        }

        if (licenseOption === 'trial') {
          const trialResult = await activateTrial(breakResult.breakData.id);
          if (!trialResult.success) {
            return res.status(500).json({
              success: false,
              error: trialResult.error
            });
          }

          return res.json({
            success: true,
            message: '✅ تم تسجيل الاستراحة وتفعيل الفترة التجريبية (15 يوم)',
            breakData: breakResult.breakData,
            serial: serial,
            trial: true
          });
        }

        res.json({
          success: true,
          message: '✅ تم تسجيل الاستراحة بنجاح، يرجى إدخال مفتاح الترخيص',
          breakData: breakResult.breakData,
          serial: serial,
          trial: false
        });

      } catch (error) {
        console.error('❌ خطأ في التسجيل:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });
// ============================================
// ===== إضافة إلى server.js =====
// ===== نظام تقارير المشاهدات =====
// ============================================

// جلب إحصائيات المشاهدة الكاملة
app.get('/api/reports/views', (req, res) => {
    try {
        const views = loadViews();
        const syncCache = loadSyncCache();
        
        // تحليل البيانات
        const entries = Object.entries(views);
        const totalViews = entries.reduce((sum, [_, count]) => sum + count, 0);
        const uniqueFiles = entries.length;
        
        // ترتيب الملفات حسب عدد المشاهدات
       const sortedByViews = entries
    .map(([key, count]) => {
        const parts = key.split(':');
        const categoryId = parts[0];
        const driveIndex = parseInt(parts[1]) || 0;
        const filePath = parts.slice(2).join(':');
        const fileName = filePath.split('/').pop();
        
        // ✅ استخراج المجلد المحتوي
        let folderPath = '';
        let folderName = 'المجلد الرئيسي';
        
        if (filePath.includes('/')) {
            const pathParts = filePath.split('/');
            pathParts.pop();
            folderPath = pathParts.join('/');
            folderName = pathParts[pathParts.length - 1] || 'المجلد الرئيسي';
        }
        
        // معلومات القسم
        let categoryName = categoryId;
        let categoryIcon = '📁';
        let categoryColor = '#667eea';
        
        if (syncCache?.categories?.[categoryId]) {
            const catData = syncCache.categories[categoryId];
            categoryName = catData.categoryName || categoryId;
            categoryIcon = catData.categoryIcon || '📁';
            categoryColor = catData.categoryColor || '#667eea';
        } else {
            const cat = config.categories?.find(c => c.id === categoryId);
            if (cat) {
                categoryName = cat.name || categoryId;
                categoryIcon = cat.icon || '📁';
                categoryColor = cat.color || '#667eea';
            }
        }
        
        return {
            key,
            categoryId,
            categoryName,
            categoryIcon,
            categoryColor,
            driveIndex,
            filePath,
            fileName,
            folderPath,      // ✅ المسار النسبي للمجلد
            folderName,      // ✅ اسم المجلد فقط
            views: count,
            extension: fileName.includes('.') ? '.' + fileName.split('.').pop() : ''
        };
    })
    .sort((a, b) => b.views - a.views);
        
        // إحصائيات حسب القسم
        const byCategory = {};
        entries.forEach(([key, count]) => {
            const [categoryId] = key.split(':');
            if (!byCategory[categoryId]) {
                byCategory[categoryId] = { views: 0, files: 0 };
            }
            byCategory[categoryId].views += count;
            byCategory[categoryId].files++;
        });
        
        // إحصائيات حسب نوع الملف
        const byExtension = {};
        sortedByViews.forEach(item => {
            const ext = item.extension || 'unknown';
            if (!byExtension[ext]) {
                byExtension[ext] = { views: 0, files: 0 };
            }
            byExtension[ext].views += item.views;
            byExtension[ext].files++;
        });
        
        res.json({
            success: true,
            summary: {
                totalViews,
                uniqueFiles,
                averageViewsPerFile: uniqueFiles > 0 ? (totalViews / uniqueFiles).toFixed(2) : 0,
                categoriesWithViews: Object.keys(byCategory).length
            },
            topFiles: sortedByViews.slice(0, 50),
            leastViewed: sortedByViews.slice(-20).reverse(),
            byCategory,
            byExtension,
            allFiles: sortedByViews
        });
        
    } catch (error) {
        console.error('❌ خطأ في تقرير المشاهدات:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// جلب إحصائيات المشاهدة لملف معين
app.get('/api/reports/views/file', (req, res) => {
    try {
        const { path: filePath, categoryId, driveIndex } = req.query;
        const views = loadViews();
        const key = `${categoryId}:${driveIndex || 0}:${filePath}`;
        
        res.json({
            success: true,
            filePath,
            categoryId,
            driveIndex: parseInt(driveIndex) || 0,
            views: views[key] || 0
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// ===== إضافة إلى server.js =====
// ===== نظام تقارير المستخدمين =====
// ============================================

// جلب إحصائيات المستخدمين الكاملة
app.get('/api/reports/users', (req, res) => {
    try {
        const watchHistory = loadWatchHistory();
        const messages = loadAllMessages();
        
        // تحليل سجل المشاهدة
        const users = [];
        let totalWatchTime = 0;
        let totalWatchedFiles = 0;
        
        for (const [userId, userData] of Object.entries(watchHistory)) {
            const watchedFiles = Object.values(userData.watchHistory || {});
            const watchedCount = watchedFiles.filter(w => w.watched).length;
            const totalProgress = watchedFiles.reduce((sum, w) => sum + (w.progress || 0), 0);
            
            users.push({
                userId,
                username: userData.username || 'زائر',
                totalFiles: watchedFiles.length,
                watchedFiles: watchedCount,
                inProgress: watchedFiles.length - watchedCount,
                averageProgress: watchedFiles.length > 0 
                    ? (totalProgress / watchedFiles.length).toFixed(1) 
                    : 0,
                lastActive: userData.lastActive,
                firstSeen: userData.firstSeen || null,
                messageCount: messages[userId]?.length || 0
            });
            
            totalWatchedFiles += watchedCount;
        }
        
        // ترتيب حسب النشاط
        users.sort((a, b) => b.watchedFiles - a.watchedFiles);
        
        // إحصائيات عامة
        const now = Date.now();
        const oneDayAgo = now - 24 * 60 * 60 * 1000;
        const oneWeekAgo = now - 7 * 24 * 60 * 60 * 1000;
        const oneMonthAgo = now - 30 * 24 * 60 * 60 * 1000;
        
        const activeToday = users.filter(u => u.lastActive > oneDayAgo).length;
        const activeThisWeek = users.filter(u => u.lastActive > oneWeekAgo).length;
        const activeThisMonth = users.filter(u => u.lastActive > oneMonthAgo).length;
        
        res.json({
            success: true,
            summary: {
                totalUsers: users.length,
                activeToday,
                activeThisWeek,
                activeThisMonth,
                totalWatchedFiles,
                averageFilesPerUser: users.length > 0 
                    ? (totalWatchedFiles / users.length).toFixed(1) 
                    : 0
            },
            topUsers: users.slice(0, 50),
            allUsers: users
        });
        
    } catch (error) {
        console.error('❌ خطأ في تقرير المستخدمين:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// جلب إحصائيات الجلسات الحالية
app.get('/api/reports/sessions', (req, res) => {
    try {
        const now = Date.now();
        const activeSessionsList = activeSessions.filter(s => now - s.lastActivity < 120000);
        
        // إحصائيات
        const totalActive = activeSessionsList.length;
        const totalBandwidth = activeSessionsList.reduce((sum, s) => sum + (s.speed || 0), 0);
        
        // تجميع حسب الجهاز
        const byDevice = {};
        activeSessionsList.forEach(s => {
            const device = s.device || 'Unknown';
            if (!byDevice[device]) byDevice[device] = 0;
            byDevice[device]++;
        });
        
        // تجميع حسب IP
        const byIP = {};
        activeSessionsList.forEach(s => {
            if (!byIP[s.ip]) byIP[s.ip] = { count: 0, files: [] };
            byIP[s.ip].count++;
            if (s.currentFile) byIP[s.ip].files.push(s.currentFile);
        });
        
        res.json({
            success: true,
            summary: {
                activeNow: totalActive,
                totalSessions: totalSessions,
                peakUsers: peakUsers,
                currentBandwidth: parseFloat(totalBandwidth.toFixed(2))
            },
            byDevice,
            byIP,
            sessions: activeSessionsList.map(s => ({
                id: s.id,
                ip: s.ip,
                device: s.device,
                username: s.username,
                currentFile: s.currentFile,
                progress: s.progress,
                speed: s.speed,
                connected: s.connected,
                lastActivity: s.lastActivity,
                duration: now - s.connected
            }))
        });
        
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
// ============================================
// ===== تقرير شامل للإحصائيات =====
// ============================================

app.get('/api/reports/dashboard', (req, res) => {
    try {
        const views = loadViews();
        const watchHistory = loadWatchHistory();
        const syncCache = loadSyncCache();
        
        // ===== إحصائيات المشاهدات =====
        const viewEntries = Object.entries(views);
        const totalViews = viewEntries.reduce((sum, [_, count]) => sum + count, 0);
        const uniqueFilesViewed = viewEntries.length;
        
        // أكثر ملف مشاهدة
       // أكثر الملفات مشاهدة
const topViewed = viewEntries
    .map(([key, count]) => {
        const parts = key.split(':');
        const categoryId = parts[0];
        const driveIndex = parseInt(parts[1]) || 0;
        const fullRelativePath = parts.slice(2).join(':'); // المسار الكامل النسبي
        const fileName = fullRelativePath.split('/').pop();
        
        // ✅ استخراج المجلد المحتوي للملف
        let folderPath = '';
        let folderName = 'المجلد الرئيسي';
        
        if (fullRelativePath.includes('/')) {
            const pathParts = fullRelativePath.split('/');
            pathParts.pop(); // إزالة اسم الملف
            folderPath = pathParts.join('/');
            folderName = pathParts[pathParts.length - 1] || 'المجلد الرئيسي';
        }
        
        // الحصول على معلومات القسم
        let categoryName = categoryId;
        let categoryIcon = '📁';
        let categoryColor = '#667eea';
        
        if (syncCache?.categories?.[categoryId]) {
            const catData = syncCache.categories[categoryId];
            categoryName = catData.categoryName || categoryId;
            categoryIcon = catData.categoryIcon || '📁';
            categoryColor = catData.categoryColor || '#667eea';
        } else {
            // محاولة الحصول عليها من config
            const cat = config.categories?.find(c => c.id === categoryId);
            if (cat) {
                categoryName = cat.name || categoryId;
                categoryIcon = cat.icon || '📁';
                categoryColor = cat.color || '#667eea';
            }
        }
        
        // ✅ محاولة الحصول على المسار الكامل من الكاش
        let fullPath = fullRelativePath;
        if (syncCache?.categories?.[categoryId]?.files) {
            const cachedFile = syncCache.categories[categoryId].files.find(f => 
                f.path === fullRelativePath || 
                f.name === fileName
            );
            if (cachedFile?.fullPath) {
                fullPath = cachedFile.fullPath;
            }
        }
        
        return { 
            key,
            fileName,           // اسم الملف
            folderPath,         // المسار النسبي للمجلد
            folderName,         // اسم المجلد فقط
            fullRelativePath,   // المسار الكامل النسبي
            fullPath,           // المسار الكامل (إذا توفر)
            categoryId,
            categoryName,
            categoryIcon,
            categoryColor,
            driveIndex,
            views: count 
        };
    })
    .sort((a, b) => b.views - a.views);
        
        // ===== إحصائيات المستخدمين =====
        const users = Object.entries(watchHistory);
        const totalUsers = users.length;
        const totalWatchedFiles = users.reduce((sum, [_, data]) => {
            return sum + Object.values(data.watchHistory || {}).filter(w => w.watched).length;
        }, 0);
        
        // المستخدمين النشطين
        const now = Date.now();
        const activeUsers = users.filter(([_, data]) => 
            data.lastActive && (now - data.lastActive) < 7 * 24 * 60 * 60 * 1000
        ).length;
        
        // ===== إحصائيات الجلسات =====
        const activeSessionsCount = activeSessions.filter(s => 
            now - s.lastActivity < 120000
        ).length;
        
        // ===== إحصائيات الملفات =====
        let totalFiles = 0;
        let totalVideos = 0;
        let totalSize = 0;
        
        if (syncCache && syncCache.categories) {
            for (const catData of Object.values(syncCache.categories)) {
                if (catData.files) {
                    totalFiles += catData.files.length;
                    totalVideos += catData.files.filter(f => 
                        VIDEO_EXTENSIONS.includes(f.extension)
                    ).length;
                    totalSize += catData.files.reduce((sum, f) => sum + (f.size || 0), 0);
                }
            }
        }
        
        res.json({
            success: true,
            timestamp: now,
            views: {
                total: totalViews,
                uniqueFiles: uniqueFilesViewed,
                top10: topViewed.slice(0, 10),
                averagePerFile: uniqueFilesViewed > 0 
                    ? (totalViews / uniqueFilesViewed).toFixed(2) 
                    : 0
            },
            users: {
                total: totalUsers,
                activeThisWeek: activeUsers,
                totalWatchedFiles,
                averageFilesPerUser: totalUsers > 0 
                    ? (totalWatchedFiles / totalUsers).toFixed(1) 
                    : 0
            },
            sessions: {
                activeNow: activeSessionsCount,
                totalToday: totalSessions,
                peak: peakUsers
            },
            files: {
                total: totalFiles,
                videos: totalVideos,
                totalSize: totalSize,
                totalSizeFormatted: formatBytes(totalSize)
            }
        });
        
    } catch (error) {
        console.error('❌ خطأ في التقرير الشامل:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/views/increment', async (req, res) => {
    try {
        const { filePath, categoryId, driveIndex } = req.body;
        if (!filePath || !categoryId) {
            return res.status(400).json({ success: false, error: 'المسار والقسم مطلوبان' });
        }
        
        // ✅ انتظر حتى يتم تحرير القفل
        let attempts = 0;
        while (viewsWriteLock && attempts < 100) {
            await new Promise(resolve => setTimeout(resolve, 50));
            attempts++;
        }
        
        viewsWriteLock = true;
        
        try {
            // ✅ قراءة أحدث نسخة من الملف مباشرة (تجاهل أي كاش)
            const views = loadViews();
            const key = `${categoryId}:${driveIndex || 0}:${filePath}`;
            views[key] = (views[key] || 0) + 1;
            
            const success = saveViews(views);
            
            res.json({ 
                success, 
                views: views[key] 
            });
        } finally {
            viewsWriteLock = false;
        }
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});
    app.post('/api/system/update-key', async (req, res) => {
      try {
        const { licenseKey } = req.body;

        if (!licenseKey) {
          return res.status(400).json({
            success: false,
            error: 'مفتاح الترخيص مطلوب'
          });
        }

        const serial = await getMotherboardSerial();

        const check = await checkBreakExists(serial);

        if (!check.exists) {
          return res.status(404).json({
            success: false,
            error: 'الجهاز غير مسجل'
          });
        }

        const breakId = check.breakData.id;

        const keyCheck = await checkLicenseKey(licenseKey);

        if (!keyCheck.valid) {
          return res.status(400).json({
            success: false,
            error: keyCheck.error || 'المفتاح غير صالح'
          });
        }

        const { error: deleteError } = await supabase.
        from('break_active').
        delete().
        eq('sub_id_name_break', breakId);

        if (deleteError) {
          console.error('❌ خطأ في حذف المفتاح القديم:', deleteError);
          return res.status(500).json({
            success: false,
            error: 'فشل حذف المفتاح القديم: ' + deleteError.message
          });
        }

        const { error: insertError } = await supabase.
        from('break_active').
        insert({
          sub_id_name_break: breakId,
          sub_id_key: keyCheck.keyData.id
        });

        if (insertError) {
          console.error('❌ خطأ في إضافة المفتاح الجديد:', insertError);
          return res.status(500).json({
            success: false,
            error: 'فشل إضافة المفتاح الجديد: ' + insertError.message
          });
        }

        res.json({
          success: true,
          message: `✅ تم تحديث المفتاح بنجاح - صلاحية حتى ${new Date(keyCheck.keyData.exp_date).toLocaleDateString('ar-EG')}`,
          keyData: keyCheck.keyData
        });

      } catch (error) {
        console.error('❌ خطأ في تحديث المفتاح:', error);
        res.status(500).json({
          success: false,
          error: error.message || 'حدث خطأ داخلي في الخادم'
        });
      }
    });

    app.post('/api/system/activate-key', async (req, res) => {
      try {
        const { licenseKey } = req.body;

        if (!licenseKey) {
          return res.status(400).json({
            success: false,
            error: 'مفتاح الترخيص مطلوب'
          });
        }

        const serial = await getMotherboardSerial();
        const check = await checkBreakExists(serial);

        if (!check.exists) {
          return res.status(404).json({
            success: false,
            error: 'الجهاز غير مسجل'
          });
        }

        const breakId = check.breakData.id;

        const keyCheck = await checkLicenseKey(licenseKey);
        if (!keyCheck.valid) {
          return res.status(400).json({
            success: false,
            error: keyCheck.error || 'المفتاح غير صالح'
          });
        }

        const newKeyId = keyCheck.keyData.id;

        const { error: deleteError } = await supabase.
        from('break_active').
        delete().
        eq('sub_id_name_break', breakId);

        if (deleteError) {
          console.error('❌ خطأ في حذف المفتاح القديم:', deleteError);
          return res.status(500).json({
            success: false,
            error: 'فشل حذف المفتاح القديم: ' + deleteError.message
          });
        }

        const { error: insertError } = await supabase.
        from('break_active').
        insert({
          sub_id_name_break: breakId,
          sub_id_key: newKeyId
        });

        if (insertError) {
          console.error('❌ خطأ في إضافة المفتاح الجديد:', insertError);
          return res.status(500).json({
            success: false,
            error: 'فشل إضافة المفتاح الجديد: ' + insertError.message
          });
        }

        serverLocked = false;
        licenseValid = true;

        res.json({
          success: true,
          message: `✅ تم تفعيل المفتاح بنجاح - صلاحية حتى ${new Date(keyCheck.keyData.exp_date).toLocaleDateString('ar-EG')}`,
          keyData: keyCheck.keyData
        });

      } catch (error) {
        console.error('❌ خطأ في تفعيل المفتاح:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/system/renew-license', async (req, res) => {
      try {
        const { licenseKey } = req.body;

        if (!licenseKey) {
          return res.status(400).json({
            success: false,
            error: 'مفتاح الترخيص مطلوب'
          });
        }

        const serial = await getMotherboardSerial();
        if (!serial) {
          return res.status(500).json({
            success: false,
            error: 'فشل الحصول على سريال الجهاز'
          });
        }

        const check = await checkBreakExists(serial);
        if (!check.exists) {
          return res.status(404).json({
            success: false,
            error: 'الجهاز غير مسجل'
          });
        }

        const breakId = check.breakData.id;

        const keyCheck = await checkLicenseKey(licenseKey);
        if (!keyCheck.valid) {
          return res.status(400).json({
            success: false,
            error: keyCheck.error || 'المفتاح غير صالح'
          });
        }

        const newKeyId = keyCheck.keyData.id;

        const { error: deleteError } = await supabase.
        from('break_active').
        delete().
        eq('sub_id_name_break', breakId);

        if (deleteError) {
          console.error('❌ خطأ في حذف المفتاح القديم:', deleteError);
          return res.status(500).json({
            success: false,
            error: 'فشل حذف المفتاح القديم: ' + deleteError.message
          });
        }

        const { error: insertError } = await supabase.
        from('break_active').
        insert({
          sub_id_name_break: breakId,
          sub_id_key: newKeyId
        });

        if (insertError) {
          console.error('❌ خطأ في إضافة المفتاح الجديد:', insertError);
          return res.status(500).json({
            success: false,
            error: 'فشل إضافة المفتاح الجديد: ' + insertError.message
          });
        }

        serverLocked = false;
        licenseValid = true;

        const updatedLicense = await checkBreakLicense(breakId);
        licenseCheckResult = {
          valid: true,
          serial: serial,
          breakData: check.breakData,
          license: updatedLicense,
          timestamp: Date.now()
        };

        res.json({
          success: true,
          message: `✅ تم تجديد الترخيص بنجاح - صلاحية حتى ${new Date(keyCheck.keyData.exp_date).toLocaleDateString('ar-EG')}`,
          keyData: keyCheck.keyData,
          breakData: check.breakData
        });

      } catch (error) {
        console.error('❌ خطأ في تجديد الترخيص:', error);
        res.status(500).json({
          success: false,
          error: error.message || 'حدث خطأ داخلي في الخادم'
        });
      }
    });

    app.get('/api/system/license-info', async (req, res) => {
      try {
        const serial = await getMotherboardSerial();
        const check = await checkBreakExists(serial);

        if (!check.exists) {
          return res.json({
            success: true,
            exists: false,
            message: 'الجهاز غير مسجل'
          });
        }

        const license = await checkBreakLicense(check.breakData.id);

        res.json({
          success: true,
          exists: true,
          breakData: check.breakData,
          license: license
        });

      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // ============================================
    // ===== 11.5 مسارات إعادة التحقق =====
    // ============================================

    app.get('/api/system/check-connection', async (req, res) => {
      try {
        const isConnected = await checkInternetConnectivity();
        const result = await revalidateLicense();

        res.json({
          success: true,
          isConnected: isConnected,
          serverLocked: serverLocked,
          licenseValid: licenseValid,
          revalidateResult: result,
          timestamp: Date.now()
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/system/connection-status', (req, res) => {try {
        res.json({
          success: true,
          serverLocked: serverLocked,
          licenseValid: licenseValid,
          reconnectAttempts: reconnectAttempts,
          lastSuccessfulCheck: lastSuccessfulCheck,
          isChecking: isCheckingConnectivity,
          monitoringActive: !!reconnectInterval
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // ============================================
    // ===== 12. مسارات المستخدمين =====
    // ============================================

    app.get('/api/users', (req, res) => {
      try {
        const safeUsers = users.map((u) => {try {return {
              id: u.id,
              username: u.username,
              role: u.role,
              created: u.created,
              lastLogin: u.lastLogin
            };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        res.json({
          success: true,
          users: safeUsers
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/users/login', (req, res) => {
      try {
        const { username, password } = req.body;

        if (!username || !password) {
          return res.status(400).json({
            success: false,
            error: 'اسم المستخدم وكلمة المرور مطلوبان'
          });
        }

        let users = [];
        try {
          if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            if (data && data.trim()) {
              users = JSON.parse(data);
            }
          }
        } catch (e) {
          console.error('❌ خطأ في قراءة ملف المستخدمين:', e);
          users = loadUsersFromFile();
        }

        const user = users.find((u) => {try {return u.username === username && u.password === password;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (!user) {
          return res.status(401).json({
            success: false,
            error: 'اسم المستخدم أو كلمة المرور غير صحيحة'
          });
        }

        user.lastLogin = Date.now();
        saveUsersToFile(users);

        users = loadUsersFromFile();

        res.json({
          success: true,
          user: {
            id: user.id,
            username: user.username,
            role: user.role
          }
        });
      } catch (error) {
        console.error('❌ خطأ في تسجيل الدخول:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/users/add', (req, res) => {
      try {
        const { username, password, role } = req.body;

        if (!username || !password) {
          return res.status(400).json({
            success: false,
            error: 'اسم المستخدم وكلمة المرور مطلوبان'
          });
        }

        if (users.find((u) => {try {return u.username === username;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}})) {
          return res.status(400).json({
            success: false,
            error: 'اسم المستخدم موجود بالفعل'
          });
        }

        const newUser = {
          id: 'user_' + Date.now(),
          username: username,
          password: password,
          role: role || 'user',
          created: Date.now()
        };

        users.push(newUser);
        saveUsersToFile(users);

        res.json({
          success: true,
          message: 'تم إضافة المستخدم بنجاح',
          user: newUser
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.put('/api/users/update/:id', (req, res) => {
      try {
        const id = req.params.id;
        const { username, password, role } = req.body;

        const userIndex = users.findIndex((u) => {try {return u.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (userIndex === -1) {
          return res.status(404).json({
            success: false,
            error: 'المستخدم غير موجود'
          });
        }

        if (username) users[userIndex].username = username;
        if (password) users[userIndex].password = password;
        if (role) users[userIndex].role = role;

        saveUsersToFile(users);

        res.json({
          success: true,
          message: 'تم تحديث المستخدم بنجاح'
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.delete('/api/users/delete/:id', (req, res) => {
      try {
        const id = req.params.id;

        if (id === 'admin') {
          return res.status(400).json({
            success: false,
            error: 'لا يمكن حذف المدير الرئيسي'
          });
        }

        const userIndex = users.findIndex((u) => {try {return u.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (userIndex === -1) {
          return res.status(404).json({
            success: false,
            error: 'المستخدم غير موجود'
          });
        }

        users.splice(userIndex, 1);
        saveUsersToFile(users);

        res.json({
          success: true,
          message: 'تم حذف المستخدم بنجاح'
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/users/admin/update', (req, res) => {
      try {
        const { currentPassword, newUsername, newPassword } = req.body;

        let users = [];
        try {
          if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            if (data && data.trim()) {
              users = JSON.parse(data);
            }
          }
        } catch (e) {
          console.error('❌ خطأ في قراءة ملف المستخدمين:', e);
          users = loadUsersFromFile();
        }

        if (!Array.isArray(users) || users.length === 0) {
          return res.status(500).json({
            success: false,
            error: 'لا يوجد مستخدمين في النظام'
          });
        }

        const adminIndex = users.findIndex((u) => {try {return u.id === 'admin';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (adminIndex === -1) {
          return res.status(404).json({
            success: false,
            error: 'المدير الرئيسي غير موجود'
          });
        }

        const admin = users[adminIndex];

        if (!currentPassword) {
          return res.status(400).json({
            success: false,
            error: 'كلمة المرور الحالية مطلوبة للتحقق'
          });
        }

        if (admin.password !== currentPassword) {
          return res.status(401).json({
            success: false,
            error: '❌ كلمة المرور الحالية غير صحيحة'
          });
        }

        let updatedFields = [];

        if (newUsername && newUsername.trim()) {
          const trimmedUsername = newUsername.trim();
          if (trimmedUsername.length < 3) {
            return res.status(400).json({
              success: false,
              error: 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل'
            });
          }

          const existingUser = users.find((u) => {try {return u.username === trimmedUsername && u.id !== 'admin';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
          if (existingUser) {
            return res.status(400).json({
              success: false,
              error: 'اسم المستخدم موجود بالفعل'
            });
          }

          users[adminIndex].username = trimmedUsername;
          updatedFields.push('اسم المستخدم');
        }

        if (newPassword && newPassword.trim()) {
          if (newPassword.trim().length < 4) {
            return res.status(400).json({
              success: false,
              error: 'كلمة المرور يجب أن تكون 4 أحرف على الأقل'
            });
          }
          users[adminIndex].password = newPassword.trim();
          updatedFields.push('كلمة المرور');
        }

        users[adminIndex].updatedAt = Date.now();

        const saveResult = saveUsersToFile(users);

        if (saveResult) {
          users = loadUsersFromFile();

          res.json({
            success: true,
            message: `تم تحديث ${updatedFields.join(' و ')} بنجاح`,
            updatedFields: updatedFields,
            user: {
              id: users[adminIndex].id,
              username: users[adminIndex].username,
              role: users[adminIndex].role,
              updatedAt: users[adminIndex].updatedAt
            }
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ التغييرات في الملف'
          });
        }
      } catch (error) {
        console.error('❌ خطأ في تحديث المدير:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/users/admin/info', (req, res) => {
      try {
        let users = [];
        try {
          if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            if (data && data.trim()) {
              users = JSON.parse(data);
            }
          }
        } catch (e) {
          console.error('❌ خطأ في قراءة ملف المستخدمين:', e);
          users = loadUsersFromFile();
        }

        const admin = users.find((u) => {try {return u.id === 'admin';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (!admin) {
          return res.status(404).json({
            success: false,
            error: 'المدير الرئيسي غير موجود'
          });
        }

        res.json({
          success: true,
          user: {
            id: admin.id,
            username: admin.username,
            role: admin.role,
            created: admin.created,
            lastLogin: admin.lastLogin,
            updatedAt: admin.updatedAt
          }
        });
      } catch (error) {
        console.error('❌ خطأ في جلب معلومات المدير:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== 13. مسارات معلومات الاستراحة =====
    // ============================================

    app.get('/api/info', (req, res) => {
      try {
        const info = loadInfoFromFile();
        res.json({
          success: true,
          info: info
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/info/update', (req, res) => {
      try {
        const { name, description, phone, whatsapp, email, socialMedia } = req.body;

        const currentInfo = loadInfoFromFile();

        if (name !== undefined) currentInfo.name = name.trim() || currentInfo.name;
        if (description !== undefined) currentInfo.description = description.trim() || currentInfo.description;
        if (phone !== undefined) currentInfo.phone = phone.trim() || currentInfo.phone;
        if (whatsapp !== undefined) currentInfo.whatsapp = whatsapp.trim() || currentInfo.whatsapp;
        if (email !== undefined) currentInfo.email = email.trim() || currentInfo.email;
        if (socialMedia !== undefined) {
          currentInfo.socialMedia = {
            ...currentInfo.socialMedia,
            ...socialMedia
          };
        }

        if (saveInfoToFile(currentInfo)) {
          res.json({
            success: true,
            message: 'تم تحديث المعلومات بنجاح',
            info: currentInfo
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ المعلومات'
          });
        }
      } catch (error) {
        console.error('❌ خطأ في تحديث المعلومات:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== 14. مسارات القنوات =====
    // ============================================

    const channelCache = new Map();
    const CHANNEL_CACHE_DURATION = 30000;

    app.get('/api/channels', (req, res) => {
      try {
        const cached = channelCache.get('channels');
        if (cached && Date.now() - cached.timestamp < CHANNEL_CACHE_DURATION) {
          return res.json(cached.data);
        }

        const channels = loadChannelsFromFile();
        const enabledChannels = channels.filter((c) => {try {return c.enabled !== false;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        const result = {
          success: true,
          channels: enabledChannels,
          all: channels
        };

        channelCache.set('channels', { data: result, timestamp: Date.now() });
        res.json(result);
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/channels/all', (req, res) => {
      try {
        const channels = loadChannelsFromFile();
        res.json({
          success: true,
          channels: channels
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/channels/add', (req, res) => {
      try {
        const { name, url, description, category, enabled } = req.body;

        if (!name || !url) {
          return res.status(400).json({
            success: false,
            error: 'اسم القناة والرابط مطلوبان'
          });
        }

        const channels = loadChannelsFromFile();

        const newChannel = {
          id: 'channel_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
          name: name.trim(),
          url: url.trim(),
          description: description || '',
          category: category || 'عامة',
          enabled: enabled !== undefined ? enabled : true,
          createdAt: Date.now(),
          views: 0
        };

        channels.push(newChannel);

        if (saveChannelsToFile(channels)) {
          res.json({
            success: true,
            message: 'تم إضافة القناة بنجاح',
            channel: newChannel
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ القناة'
          });
        }
      } catch (error) {
        console.error('❌ خطأ في إضافة القناة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.put('/api/channels/update/:id', (req, res) => {
      try {
        const id = req.params.id;
        const { name, url, description, category, enabled } = req.body;

        const channels = loadChannelsFromFile();
        const index = channels.findIndex((c) => {try {return c.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (index === -1) {
          return res.status(404).json({
            success: false,
            error: 'القناة غير موجودة'
          });
        }

        if (name) channels[index].name = name.trim();
        if (url) channels[index].url = url.trim();
        if (description !== undefined) channels[index].description = description;
        if (category) channels[index].category = category;
        if (enabled !== undefined) channels[index].enabled = enabled;

        if (saveChannelsToFile(channels)) {
          res.json({
            success: true,
            message: 'تم تحديث القناة بنجاح',
            channel: channels[index]
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ التحديث'
          });
        }
      } catch (error) {
        console.error('❌ خطأ في تحديث القناة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.delete('/api/channels/delete/:id', (req, res) => {
      try {
        const id = req.params.id;
        const channels = loadChannelsFromFile();
        const filtered = channels.filter((c) => {try {return c.id !== id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (filtered.length === channels.length) {
          return res.status(404).json({
            success: false,
            error: 'القناة غير موجودة'
          });
        }

        const CHANNEL_IMAGES_DIR = path.join(DATA_DIR, 'public', 'channel-images');
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];
        for (const ext of imageExtensions) {
          const imagePath = path.join(CHANNEL_IMAGES_DIR, `${id}${ext}`);
          try {
            if (fs.existsSync(imagePath)) {
              fs.unlinkSync(imagePath);
            }
          } catch (e) {}
        }

        if (saveChannelsToFile(filtered)) {
          res.json({
            success: true,
            message: 'تم حذف القناة بنجاح'
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حذف القناة'
          });
        }
      } catch (error) {
        console.error('❌ خطأ في حذف القناة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/channels/:id/upload-image', (req, res) => {
      try {
        const { image } = req.body;
        const id = req.params.id;

        if (!image) {
          return res.status(400).json({
            success: false,
            error: 'الصورة مطلوبة'
          });
        }

        const matches = image.match(/^data:image\/(\w+);base64,/);
        if (!matches) {
          return res.status(400).json({
            success: false,
            error: 'تنسيق الصورة غير صحيح'
          });
        }

        const CHANNEL_IMAGES_DIR = path.join(DATA_DIR, 'public', 'channel-images');
        if (!fs.existsSync(CHANNEL_IMAGES_DIR)) {
          fs.mkdirSync(CHANNEL_IMAGES_DIR, { recursive: true });
        }

        const ext = matches[1];
        const base64Data = image.replace(/^data:image\/\w+;base64,/, '');
        const filename = `${id}.${ext}`;
        const filepath = path.join(CHANNEL_IMAGES_DIR, filename);

        const oldFiles = fs.readdirSync(CHANNEL_IMAGES_DIR);
        oldFiles.forEach((f) => {try {
            if (f.startsWith(id)) {
              try {
                fs.unlinkSync(path.join(CHANNEL_IMAGES_DIR, f));
              } catch (e) {}
            }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        fs.writeFileSync(filepath, base64Data, 'base64');

        const channels = loadChannelsFromFile();
        const index = channels.findIndex((c) => {try {return c.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (index !== -1) {
          channels[index].image = `/channel-images/${filename}`;
          saveChannelsToFile(channels);
        }

        res.json({
          success: true,
          message: 'تم رفع الصورة بنجاح',
          imageUrl: `/channel-images/${filename}`
        });
      } catch (error) {
        console.error('❌ خطأ في رفع صورة القناة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.delete('/api/channels/:id/delete-image', (req, res) => {
      try {
        const id = req.params.id;
        const CHANNEL_IMAGES_DIR = path.join(DATA_DIR, 'public', 'channel-images');
        const files = fs.readdirSync(CHANNEL_IMAGES_DIR);
        let deleted = false;

        files.forEach((f) => {try {
            if (f.startsWith(id)) {
              try {
                fs.unlinkSync(path.join(CHANNEL_IMAGES_DIR, f));
                deleted = true;
              } catch (e) {}
            }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        const channels = loadChannelsFromFile();
        const index = channels.findIndex((c) => {try {return c.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (index !== -1) {
          delete channels[index].image;
          saveChannelsToFile(channels);
        }

        res.json({
          success: true,
          message: deleted ? 'تم حذف الصورة بنجاح' : 'لا توجد صورة للحذف'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/channel-image/:id', (req, res) => {
      try {
        const id = req.params.id;
        const CHANNEL_IMAGES_DIR = path.join(DATA_DIR, 'public', 'channel-images');
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.ico'];

        for (const ext of imageExtensions) {
          const imagePath = path.join(CHANNEL_IMAGES_DIR, `${id}${ext}`);
          if (fs.existsSync(imagePath)) {
            const mimeType = mime.lookup(imagePath) || 'image/jpeg';
            res.setHeader('Content-Type', mimeType);
            res.setHeader('Cache-Control', 'public, max-age=86400');
            res.setHeader('Access-Control-Allow-Origin', '*');
            return fs.createReadStream(imagePath).pipe(res);
          }
        }

        return sendDefaultImage(res);
      } catch (error) {
        console.error('❌ خطأ في عرض صورة القناة:', error);
        res.status(500).json({ error: error.message });
      }
    });

    app.post('/api/channels/view/:id', (req, res) => {
      try {
        const id = req.params.id;
        const channels = loadChannelsFromFile();
        const index = channels.findIndex((c) => {try {return c.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (index === -1) {
          return res.status(404).json({
            success: false,
            error: 'القناة غير موجودة'
          });
        }

        channels[index].views = (channels[index].views || 0) + 1;
        saveChannelsToFile(channels);

        res.json({
          success: true,
          views: channels[index].views
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/channel-images/:filename', (req, res) => {
      try {
        const filename = req.params.filename;
        const CHANNEL_IMAGES_DIR = path.join(DATA_DIR, 'public', 'channel-images');
        const imagePath = path.join(CHANNEL_IMAGES_DIR, filename);

        if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
          return res.status(403).json({ error: 'ممنوع' });
        }

        if (fs.existsSync(imagePath)) {
          const mimeType = mime.lookup(imagePath) || 'image/jpeg';
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Cache-Control', 'public, max-age=86400');
          res.setHeader('Access-Control-Allow-Origin', '*');
          return fs.createReadStream(imagePath).pipe(res);
        }

        res.status(404).json({ error: 'الصورة غير موجودة' });
      } catch (error) {
        console.error('❌ خطأ في عرض صورة القناة:', error);
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== 15. مسارات المحتوى الحصري =====
    // ============================================

    const exclusiveCache = new Map();
    const EXCLUSIVE_CACHE_DURATION = 30000;

    app.get('/api/exclusive', (req, res) => {
      try {
        const cached = exclusiveCache.get('exclusive');
        if (cached && Date.now() - cached.timestamp < EXCLUSIVE_CACHE_DURATION) {
          return res.json(cached.data);
        }

        const activeContent = exclusiveContent.filter((item) => {try {return item.enabled !== false;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        const result = {
          success: true,
          content: activeContent
        };

        exclusiveCache.set('exclusive', { data: result, timestamp: Date.now() });
        res.json(result);
      } catch (error) {
        console.error('Error in /api/exclusive:', error);
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.get('/api/exclusive/all', (req, res) => {
      try {
        res.json({
          success: true,
          content: exclusiveContent
        });
      } catch (error) {
        console.error('Error in /api/exclusive/all:', error);
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/exclusive/add', (req, res) => {
      try {
        const {
          title, description, rating, filePath, categoryId,
          driveIndex, posterImage, type, views, enabled,
          createdAt, directUrl
        } = req.body;

        if (!title || !categoryId) {
          return res.status(400).json({
            success: false,
            error: 'العنوان والقسم مطلوبان'
          });
        }

        const newItem = {
          id: 'exclusive_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
          title: title,
          description: description || '',
          rating: parseFloat(rating) || 0,
          filePath: filePath || '',
          originalPath: filePath || '',
          categoryId: categoryId,
          driveIndex: parseInt(driveIndex) || 0,
          posterImage: posterImage || '',
          createdAt: parseInt(createdAt) || Date.now(),
          views: parseInt(views) || 0,
          enabled: enabled !== undefined ? enabled : true,
          type: type || 'video',
          fileExists: false,
          directUrl: directUrl || undefined
        };

        exclusiveContent.push(newItem);

        if (saveExclusiveContent(exclusiveContent)) {
          res.json({
            success: true,
            message: 'تم إضافة المحتوى الحصري بنجاح',
            item: newItem
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ المحتوى'
          });
        }
      } catch (error) {
        console.error('Error adding exclusive:', error);
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.put('/api/exclusive/update/:id', (req, res) => {
      try {
        const id = req.params.id;
        const {
          title, description, rating, filePath, categoryId,
          driveIndex, posterImage, enabled, type, views,
          createdAt, directUrl
        } = req.body;

        const index = exclusiveContent.findIndex((item) => {try {return item.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (index === -1) {
          return res.status(404).json({
            success: false,
            error: 'المحتوى غير موجود'
          });
        }

        if (title) exclusiveContent[index].title = title;
        if (description !== undefined) exclusiveContent[index].description = description;
        if (rating !== undefined) exclusiveContent[index].rating = parseFloat(rating) || 0;
        if (filePath !== undefined) exclusiveContent[index].filePath = filePath;
        if (categoryId) exclusiveContent[index].categoryId = categoryId;
        if (driveIndex !== undefined) exclusiveContent[index].driveIndex = parseInt(driveIndex) || 0;
        if (posterImage !== undefined) exclusiveContent[index].posterImage = posterImage;
        if (enabled !== undefined) exclusiveContent[index].enabled = enabled;
        if (type) exclusiveContent[index].type = type;
        if (views !== undefined) exclusiveContent[index].views = parseInt(views) || 0;
        if (createdAt) exclusiveContent[index].createdAt = parseInt(createdAt);
        if (directUrl !== undefined) exclusiveContent[index].directUrl = directUrl;

        if (saveExclusiveContent(exclusiveContent)) {
          res.json({
            success: true,
            message: 'تم تحديث المحتوى الحصري بنجاح',
            item: exclusiveContent[index]
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ المحتوى'
          });
        }
      } catch (error) {
        console.error('Error updating exclusive:', error);
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.delete('/api/exclusive/delete/:id', (req, res) => {
      try {
        const id = req.params.id;
        const index = exclusiveContent.findIndex((item) => {try {return item.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (index === -1) {
          return res.status(404).json({
            success: false,
            error: 'المحتوى غير موجود'
          });
        }

        const EXCLUSIVE_IMAGES_DIR = path.join(DATA_DIR, 'public', 'exclusive-images');
        try {
          const files = fs.readdirSync(EXCLUSIVE_IMAGES_DIR);
          files.forEach((f) => {try {
              if (f.startsWith(id)) {
                fs.unlinkSync(path.join(EXCLUSIVE_IMAGES_DIR, f));
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
        } catch (e) {}

        exclusiveContent.splice(index, 1);

        if (saveExclusiveContent(exclusiveContent)) {
          res.json({
            success: true,
            message: 'تم حذف المحتوى الحصري بنجاح'
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ المحتوى'
          });
        }
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/exclusive/view/:id', (req, res) => {
      try {
        const id = req.params.id;
        const item = exclusiveContent.find((item) => {try {return item.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (!item) {
          return res.status(404).json({
            success: false,
            error: 'المحتوى غير موجود'
          });
        }

        item.views = (item.views || 0) + 1;
        saveExclusiveContent(exclusiveContent);

        res.json({
          success: true,
          views: item.views
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

  app.get('/api/exclusive/stream/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const item = exclusiveContent.find(i => i.id === id);
    if (!item) {
      return res.status(404).json({ error: 'المحتوى غير موجود', code: 'CONTENT_NOT_FOUND' });
    }

    item.views = (item.views || 0) + 1;
    saveExclusiveContent(exclusiveContent);

    // إذا كان هناك رابط مباشر، استخدمه
    if (item.directUrl) {
      return res.redirect(item.directUrl);
    }

    // إذا كان filePath موجوداً، استخدمه مباشرة
    let filePath = item.filePath;
    if (!filePath || !fs.existsSync(filePath)) {
      // حاول البحث في المسارات المسجلة (للتوافق مع الإصدارات القديمة)
      // ... كود البحث القديم ...
      return res.status(404).json({ error: 'الملف غير موجود', code: 'FILE_NOT_FOUND' });
    }

    // استخدم streamFile مع تمرير pathId (اختياري)
    const isDownload = req.query.download === 'true';
    streamFile(filePath, req, res, isDownload, null);

  } catch (error) {
    console.error('❌ خطأ في تشغيل المحتوى الحصري:', error);
    res.status(500).json({ error: error.message, code: 'SERVER_ERROR' });
  }
});

   app.get('/api/exclusive/download/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const item = exclusiveContent.find(i => i.id === id);
    if (!item) return res.status(404).json({ error: 'المحتوى غير موجود' });

    let filePath = item.filePath;
    if (!filePath || !fs.existsSync(filePath)) {
      // البحث القديم ...
      return res.status(404).json({ error: 'الملف غير موجود' });
    }

    const isDownload = true;
    streamFile(filePath, req, res, isDownload, null);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

    app.post('/api/exclusive/repair', async (req, res) => {
      try {
        let fixedCount = 0;
        let deletedCount = 0;
        let repaired = [];

        for (const item of exclusiveContent) {
          let filePath = null;

          for (const cat of config.categories) {
            if (!cat.paths) continue;
            for (const drive of cat.paths) {
              const testPath = path.join(drive.path, path.basename(item.filePath));
              if (fs.existsSync(testPath)) {
                filePath = testPath;
                break;
              }
              const fullTestPath = path.join(drive.path, item.filePath);
              if (fs.existsSync(fullTestPath)) {
                filePath = fullTestPath;
                break;
              }
            }
            if (filePath) break;
          }

          if (filePath) {
            item.filePath = filePath;
            item.fileExists = true;
            fixedCount++;
            repaired.push({
              id: item.id,
              title: item.title,
              oldPath: item.filePath,
              newPath: filePath,
              status: 'fixed'
            });
          } else {
            item.enabled = false;
            item.fileExists = false;
            deletedCount++;
            repaired.push({
              id: item.id,
              title: item.title,
              oldPath: item.filePath,
              status: 'disabled'
            });
          }
        }

        saveExclusiveContent(exclusiveContent);

        res.json({
          success: true,
          message: `تم إصلاح ${fixedCount} عنصر وتعطيل ${deletedCount} عنصر`,
          fixed: fixedCount,
          deleted: deletedCount,
          details: repaired
        });

      } catch (error) {
        console.error('❌ خطأ في إصلاح المسارات:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== 16. صور المحتوى الحصري =====
    // ============================================

    const EXCLUSIVE_IMAGES_DIR = path.join(DATA_DIR, 'public', 'exclusive-images');

    app.post('/api/exclusive/:id/upload-image', (req, res) => {
      try {
        const { image } = req.body;
        const id = req.params.id;

        if (!image) {
          return res.status(400).json({
            success: false,
            error: 'الصورة مطلوبة'
          });
        }

        const matches = image.match(/^data:image\/(\w+);base64,/);
        if (!matches) {
          return res.status(400).json({
            success: false,
            error: 'تنسيق الصورة غير صحيح'
          });
        }

        const ext = matches[1];
        const base64Data = image.replace(/^data:image\/\w+;base64,/, '');
        const filename = `${id}.${ext}`;
        const filepath = path.join(EXCLUSIVE_IMAGES_DIR, filename);

        try {
          const oldFiles = fs.readdirSync(EXCLUSIVE_IMAGES_DIR);
          oldFiles.forEach((f) => {try {
              if (f.startsWith(id)) {
                try {
                  fs.unlinkSync(path.join(EXCLUSIVE_IMAGES_DIR, f));
                } catch (e) {}
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
        } catch (e) {}

        fs.writeFileSync(filepath, base64Data, 'base64');

        const item = exclusiveContent.find((item) => {try {return item.id === id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (item) {
          item.posterImage = `/exclusive-images/${filename}`;
          saveExclusiveContent(exclusiveContent);
        }

        res.json({
          success: true,
          message: 'تم رفع الصورة بنجاح',
          imageUrl: `/exclusive-images/${filename}`
        });
      } catch (error) {
        console.error('Error uploading exclusive image:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/exclusive-image/:id', (req, res) => {
      try {
        const id = req.params.id;
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.ico'];

        for (const ext of imageExtensions) {
          const imagePath = path.join(EXCLUSIVE_IMAGES_DIR, `${id}${ext}`);
          if (fs.existsSync(imagePath)) {
            const mimeType = mime.lookup(imagePath) || 'image/jpeg';
            res.setHeader('Content-Type', mimeType);
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.setHeader('Pragma', 'no-cache');
            res.setHeader('Expires', '0');
            res.setHeader('Access-Control-Allow-Origin', '*');
            return fs.createReadStream(imagePath).pipe(res);
          }
        }

        return sendDefaultImage(res);
      } catch (error) {
        console.error('Error serving exclusive image:', error);
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== 17. مسارات سجل المشاهدة =====
    // ============================================

    app.get('/api/watch/status', (req, res) => {
      try {
        const filePaths = req.query.files ? req.query.files.split(',') : [];
        const userId = getUserId(req);
        const history = loadWatchHistory();

        const status = {};
        if (history && history[userId]) {
          filePaths.forEach((filePath) => {try {
              if (!filePath) return;
              const fileKey = filePath.replace(/[\/\\]/g, '_');
              if (history[userId].watchHistory && history[userId].watchHistory[fileKey]) {
                status[filePath] = {
                  watched: history[userId].watchHistory[fileKey].watched || false,
                  progress: history[userId].watchHistory[fileKey].progress || 0,
                  lastWatched: history[userId].watchHistory[fileKey].lastWatched || null
                };
              } else {
                status[filePath] = { watched: false, progress: 0 };
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
        } else {
          filePaths.forEach((filePath) => {try {
              if (filePath) {
                status[filePath] = { watched: false, progress: 0 };
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
        }

        res.json({
          success: true,
          status: status
        });
      } catch (error) {
        console.error('❌ خطأ في جلب حالة المشاهدة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/watch/record', (req, res) => {
      try {
        const { filePath, progress, duration, categoryId, driveIndex } = req.body;

        if (!filePath) {
          console.error('❌ مسار الملف غير موجود في الطلب');
          return res.status(400).json({
            success: false,
            error: 'مسار الملف مطلوب'
          });
        }

        const userId = getUserId(req);

        let username = req.headers['x-username'] ? decodeURIComponent(req.headers['x-username']) : 'زائر';

        let history = loadWatchHistory();
        if (!history[userId]) {
          history[userId] = {
            username: username, // ← استخدام اسم المستخدم
            watchHistory: {},
            lastActive: Date.now()
          };
        }

        const fileKey = filePath.replace(/[\/\\]/g, '_');
        const currentProgress = Math.min(100, Math.floor(progress || 0));
        const isWatched = currentProgress >= 90;

        history[userId].watchHistory[fileKey] = {
          filePath: filePath,
          progress: currentProgress,
          duration: duration || 0,
          lastWatched: Date.now(),
          categoryId: categoryId || '',
          driveIndex: driveIndex || 0,
          watched: isWatched
        };
        history[userId].lastActive = Date.now();

        if (saveWatchHistory(history)) {
          res.json({
            success: true,
            message: 'تم تسجيل المشاهدة',
            watched: isWatched,
            progress: currentProgress,
            duration: duration || 0
          });
        } else {
          console.error('❌ فشل حفظ سجل المشاهدة');
          res.status(500).json({
            success: false,
            error: 'فشل حفظ سجل المشاهدة'
          });
        }
      } catch (error) {
        console.error('❌ خطأ في تسجيل المشاهدة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/watch/repair', (req, res) => {
      try {
        if (fs.existsSync(WATCH_HISTORY_FILE)) {
          fs.unlinkSync(WATCH_HISTORY_FILE);
        }
        saveWatchHistory({});
        res.json({
          success: true,
          message: '✅ تم إصلاح سجل المشاهدة بنجاح'
        });
      } catch (error) {
        console.error('❌ خطأ في الإصلاح:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/watch/check', (req, res) => {
      try {
        const history = loadWatchHistory();
        const isValid = history && typeof history === 'object';
        res.json({
          success: true,
          valid: isValid,
          users: isValid ? Object.keys(history).length : 0,
          message: isValid ? '✅ الملف صالح' : '❌ الملف غير صالح'
        });
      } catch (error) {
        res.json({
          success: false,
          valid: false,
          error: error.message
        });
      }
    });

    app.post('/api/watch/repair', (req, res) => {
      try {
        if (fs.existsSync(WATCH_HISTORY_FILE)) {
          fs.unlinkSync(WATCH_HISTORY_FILE);
        }
        saveWatchHistory({});
        res.json({
          success: true,
          message: '✅ تم إصلاح ملف سجل المشاهدة'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/watch/status-batch', (req, res) => {
      try {
        const { files } = req.body;

        if (!files || !Array.isArray(files) || files.length === 0) {
          return res.status(400).json({
            success: false,
            error: 'قائمة الملفات مطلوبة'
          });
        }

        if (files.length > 500) {
          return res.status(400).json({
            success: false,
            error: 'عدد الملفات كبير جداً (الحد الأقصى 500)'
          });
        }

        const userId = getUserId(req);
        const history = loadWatchHistory();
        const status = {};

        if (history && history[userId]) {
          files.forEach((filePath) => {try {
              if (!filePath) return;
              const fileKey = filePath.replace(/[\/\\]/g, '_');
              if (history[userId].watchHistory && history[userId].watchHistory[fileKey]) {
                status[filePath] = {
                  watched: history[userId].watchHistory[fileKey].watched || false,
                  progress: history[userId].watchHistory[fileKey].progress || 0,
                  lastWatched: history[userId].watchHistory[fileKey].lastWatched || null
                };
              } else {
                status[filePath] = { watched: false, progress: 0 };
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
        } else {
          files.forEach((filePath) => {try {
              if (filePath) {
                status[filePath] = { watched: false, progress: 0 };
              }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
          });
        }

        res.json({
          success: true,
          status: status
        });
      } catch (error) {
        console.error('❌ خطأ في جلب حالة المشاهدة (POST):', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/watch/debug', (req, res) => {
      try {
        const history = loadWatchHistory();
        const userId = getUserId(req);

        res.json({
          success: true,
          userId: userId,
          totalUsers: Object.keys(history).length,
          userData: history[userId] || null,
          allData: history
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/watch/test', (req, res) => {
      try {
        const { filePath, progress } = req.body;
        const userId = getUserId(req);

        let history = loadWatchHistory();
        if (!history || typeof history !== 'object') {
          history = {};
        }

        if (!history[userId]) {
          history[userId] = {
            username: 'test_user',
            watchHistory: {},
            lastActive: Date.now()
          };
        }

        const fileKey = (filePath || 'test_file').replace(/[\/\\]/g, '_');
        history[userId].watchHistory[fileKey] = {
          filePath: filePath || 'test_file',
          progress: Math.min(100, Math.floor(progress || 0)),
          duration: 0,
          lastWatched: Date.now(),
          categoryId: 'test',
          driveIndex: 0,
          watched: (progress || 0) >= 90
        };

        saveWatchHistory(history);

        res.json({
          success: true,
          message: 'تم تسجيل اختبار المشاهدة',
          userId: userId
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/watch/stats', (req, res) => {
      try {
        const history = loadWatchHistory();
        let totalUsers = 0;
        let totalWatched = 0;
        const usersList = [];

        if (history && typeof history === 'object') {
          for (const userId in history) {
            const userData = history[userId];
            if (userData && userData.watchHistory) {
              totalUsers++;
              const watchedCount = Object.values(userData.watchHistory).filter((w) => {try {return w.watched === true;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}).length;
              totalWatched += watchedCount;
              usersList.push({
                username: userData.username || 'زائر',
                watchedCount: watchedCount,
                lastActive: userData.lastActive || null
              });
            }
          }
        }

        usersList.sort((a, b) => {try {return b.watchedCount - a.watchedCount;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        res.json({
          success: true,
          totalUsers: totalUsers,
          totalWatched: totalWatched,
          users: usersList
        });
      } catch (error) {
        console.error('❌ خطأ في جلب إحصائيات المشاهدة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/watch/cleanup', (req, res) => {
      try {
        const history = loadWatchHistory();
        let cleaned = 0;

        if (history && typeof history === 'object') {
          const now = Date.now();
          const oneMonthAgo = now - 30 * 24 * 60 * 60 * 1000;

          for (const userId in history) {
            const userData = history[userId];
            if (userData) {
              if (userData.lastActive && userData.lastActive < oneMonthAgo) {
                delete history[userId];
                cleaned++;
              } else if (userData.watchHistory) {
                for (const fileKey in userData.watchHistory) {
                  const entry = userData.watchHistory[fileKey];
                  if (entry.lastWatched && entry.lastWatched < oneMonthAgo) {
                    delete userData.watchHistory[fileKey];
                  }
                }
              }
            }
          }
        }

        saveWatchHistory(history);

        res.json({
          success: true,
          message: `تم تنظيف ${cleaned} مستخدم غير نشط`,
          cleaned: cleaned
        });
      } catch (error) {
        console.error('❌ خطأ في تنظيف سجل المشاهدة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== 18. مسارات السرعة =====
    // ============================================

    app.get('/api/speed/config', (req, res) => {
      try {
        res.json({
          success: true,
          config: speedConfig,
          userLimits: Array.from(userSpeedLimits.entries()).map(([ip, speed]) => {try {return { ip, speed };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}})
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/speed/config', (req, res) => {
      try {
        const { defaultSpeed, maxSpeed, enabled, totalBandwidthLimit } = req.body;

        if (defaultSpeed !== undefined) {
          speedConfig.defaultSpeed = Math.max(0.1, Math.min(100, parseFloat(defaultSpeed)));
        }
        if (maxSpeed !== undefined) {
          speedConfig.maxSpeed = Math.max(0.1, Math.min(100, parseFloat(maxSpeed)));
        }
        if (enabled !== undefined) {
          speedConfig.enabled = enabled;
        }
        if (totalBandwidthLimit !== undefined) {
          speedConfig.totalBandwidthLimit = Math.max(0, parseFloat(totalBandwidthLimit));
        }

        if (saveSpeedConfig(speedConfig)) {
          res.json({
            success: true,
            message: 'تم تحديث إعدادات السرعة',
            config: speedConfig
          });
        } else {
          res.status(500).json({ success: false, error: 'فشل حفظ الإعدادات' });
        }
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/speed/user-limit', (req, res) => {
      try {
        const { ip, speed } = req.body;

        if (!ip) {
          return res.status(400).json({ success: false, error: 'IP مطلوب' });
        }

        if (speed !== undefined) {
          if (speed === 0 || speed === null) {
            userSpeedLimits.delete(ip);
          } else {
            const speedValue = Math.max(0.1, Math.min(100, parseFloat(speed)));
            userSpeedLimits.set(ip, speedValue);
          }
        }

        res.json({
          success: true,
          message: 'تم تحديث سرعة المستخدم',
          userLimits: Array.from(userSpeedLimits.entries()).map(([ip, speed]) => {try {return { ip, speed };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}})
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.get('/api/speed/current', (req, res) => {
      try {
        const online = activeSessions.filter((s) => {try {return Date.now() - s.lastActivity < 120000;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        const userSpeeds = online.map((s) => {try {
            const ip = s.ip;
            const speed = getUserSpeed(ip);
            return {
              userId: s.userId,
              ip: ip,
              username: s.username || 'زائر',
              speed: speed,
              currentSpeed: s.speed || 0,
              device: s.device,
              currentFile: s.currentFile
            };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
        });

        res.json({
          success: true,
          totalSpeed: online.reduce((sum, s) => {try {return sum + (s.speed || 0);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}, 0),
          users: userSpeeds,
          config: speedConfig
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // ============================================
    // ===== 19. مسارات المنع =====
    // ============================================
    app.get('/api/restrictions', (req, res) => {
      try {
        res.json({
          success: true,
          restrictions: restrictions
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/restrictions/path', (req, res) => {
      try {
        const { pathId, downloadEnabled } = req.body;

        if (!pathId) {
          return res.status(400).json({ success: false, error: 'معرف المسار مطلوب' });
        }

        const existingIndex = restrictions.pathRestrictions.findIndex((r) => {try {return r.pathId === pathId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (downloadEnabled === false) {
          if (existingIndex === -1) {
            restrictions.pathRestrictions.push({ pathId, download: false });
          } else {
            restrictions.pathRestrictions[existingIndex].download = false;
          }
        } else {
          if (existingIndex !== -1) {
            restrictions.pathRestrictions.splice(existingIndex, 1);
          }
        }

        if (saveRestrictions(restrictions)) {
          res.json({
            success: true,
            message: downloadEnabled === false ? 'تم منع التحميل للمسار' : 'تم السماح بالتحميل للمسار',
            restrictions: restrictions
          });
        } else {
          res.status(500).json({ success: false, error: 'فشل حفظ الإعدادات' });
        }
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.post('/api/restrictions/file', (req, res) => {
      try {
        const { pathId, filePath } = req.body;

        if (!pathId || !filePath) {
          return res.status(400).json({ success: false, error: 'معرف المسار ومسار الملف مطلوبان' });
        }

        const exists = restrictions.downloadBlocked.some((r) => {try {return r.pathId === pathId && r.filePath === filePath;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (!exists) {
          restrictions.downloadBlocked.push({ pathId, filePath, blockedAt: Date.now() });
        }

        if (saveRestrictions(restrictions)) {
          res.json({
            success: true,
            message: 'تم منع تحميل الملف',
            restrictions: restrictions
          });
        } else {
          res.status(500).json({ success: false, error: 'فشل حفظ الإعدادات' });
        }
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.delete('/api/restrictions/file', (req, res) => {
      try {
        const { pathId, filePath } = req.body;

        if (!pathId || !filePath) {
          return res.status(400).json({ success: false, error: 'معرف المسار ومسار الملف مطلوبان' });
        }

        restrictions.downloadBlocked = restrictions.downloadBlocked.filter(
          (r) => {try {return !(r.pathId === pathId && r.filePath === filePath);} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}
        );

        if (saveRestrictions(restrictions)) {
          res.json({
            success: true,
            message: 'تم السماح بتحميل الملف',
            restrictions: restrictions
          });
        } else {
          res.status(500).json({ success: false, error: 'فشل حفظ الإعدادات' });
        }
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    app.get('/api/restrictions/check', (req, res) => {
      try {
        const { pathId, filePath } = req.query;

        if (!pathId) {
          return res.status(400).json({ success: false, error: 'معرف المسار مطلوب' });
        }

        const isBlocked = !isDownloadAllowed(pathId, filePath || '');

        res.json({
          success: true,
          isBlocked: isBlocked,
          pathId: pathId,
          filePath: filePath || ''
        });
      } catch (error) {
        res.status(500).json({ success: false, error: error.message });
      }
    });

    // ============================================
    // ===== 20. مسارات النسخ الاحتياطي =====
    // ============================================

    app.post('/api/backup/create', (req, res) => {
      try {
        const success = createFullBackup();
        if (success) {
          const backup = JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf8'));
          res.json({
            success: true,
            message: 'تم إنشاء النسخة الاحتياطية بنجاح',
            backup: backup,
            fileSize: fs.statSync(BACKUP_FILE).size
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل إنشاء النسخة الاحتياطية'
          });
        }
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.post('/api/backup/restore', (req, res) => {
      try {
        const { backupData } = req.body;

        if (!backupData) {
          return res.status(400).json({
            success: false,
            error: 'بيانات النسخة الاحتياطية مطلوبة'
          });
        }

        if (!backupData.data) {
          return res.status(400).json({
            success: false,
            error: 'بيانات غير صالحة: missing data field'
          });
        }

        const success = restoreFullBackup(backupData);
        if (success) {
          // حساب عدد الملفات المستعادة (مع التحقق من وجودها)
          const restoredFiles = Object.keys(backupData.data).filter((key) => {try {return backupData.data[key] !== null && backupData.data[key] !== undefined;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

          res.json({
            success: true,
            message: 'تم استعادة النسخة الاحتياطية بنجاح',
            restoredFiles: restoredFiles,
            timestamp: backupData.timestamp
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل استعادة النسخة الاحتياطية'
          });
        }
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/backup/download', (req, res) => {
      try {
        if (!fs.existsSync(BACKUP_FILE)) {
          return res.status(404).json({
            success: false,
            error: 'لا توجد نسخة احتياطية'
          });
        }

        const backup = fs.readFileSync(BACKUP_FILE, 'utf8');
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename="media_backup_${Date.now()}.json"`);
        res.send(backup);
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/backup/info', (req, res) => {
      try {
        if (!fs.existsSync(BACKUP_FILE)) {
          return res.json({
            success: true,
            exists: false,
            message: 'لا توجد نسخة احتياطية'
          });
        }

        const data = fs.readFileSync(BACKUP_FILE, 'utf8');
        const backup = JSON.parse(data);
        const stats = fs.statSync(BACKUP_FILE);

        // حساب عدد العناصر في كل ملف مع التحقق من وجود البيانات
        const dataCounts = {};
        for (const [key, value] of Object.entries(backup.data || {})) {
          if (value !== null && value !== undefined) {
            if (Array.isArray(value)) {
              dataCounts[key] = value.length;
            } else if (typeof value === 'object') {
              dataCounts[key] = Object.keys(value).length;
            } else {
              dataCounts[key] = 1;
            }
          } else {
            dataCounts[key] = 0;
          }
        }

        res.json({
          success: true,
          exists: true,
          timestamp: backup.timestamp,
          date: new Date(backup.timestamp).toLocaleString('ar-EG'),
          fileSize: stats.size,
          version: backup.version || '1.0',
          dataCounts: dataCounts
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.delete('/api/backup/delete', (req, res) => {
      try {
        if (!fs.existsSync(BACKUP_FILE)) {
          return res.status(404).json({
            success: false,
            error: 'لا توجد نسخة احتياطية للحذف'
          });
        }

        fs.unlinkSync(BACKUP_FILE);

        res.json({
          success: true,
          message: 'تم حذف النسخة الاحتياطية بنجاح'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== 21. مسارات الرسائل (خاصة بكل مستخدم) =====
    // ============================================

    // 🔹 جلب رسائل المستخدم الحالي
    app.get('/api/messages', (req, res) => {
      try {
        const userId = getUserId(req);
        const messages = loadUserMessages(userId);
        res.json({
          success: true,
          messages: messages,
          userId: userId
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 🔹 إرسال رسالة من المستخدم الحالي
    app.post('/api/messages/send', (req, res) => {
      try {
        const { message } = req.body;
        const userId = getUserId(req);
        const ip = req.headers['x-forwarded-for'] || req.connection?.remoteAddress || 'unknown';

        if (!message || message.trim() === '') {
          return res.status(400).json({
            success: false,
            error: 'الرسالة مطلوبة'
          });
        }

        const newMessage = addUserMessage(userId, message.trim(), 'user', ip);

        res.json({
          success: true,
          message: 'تم إرسال الرسالة بنجاح',
          data: newMessage,
          userId: userId
        });
      } catch (error) {
        console.error('❌ خطأ في إرسال الرسالة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 🔹 الرد على رسالة (من الإدارة)
    app.post('/api/messages/reply', (req, res) => {
      try {
        const { messageId, reply } = req.body;

        if (!messageId || !reply || reply.trim() === '') {
          return res.status(400).json({
            success: false,
            error: 'معرف الرسالة والرد مطلوبان'
          });
        }

        const all = loadAllMessages();
        let targetUserId = null;

        for (const [userId, messages] of Object.entries(all)) {
          if (messages.some((m) => {try {return m.id === messageId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}})) {
            targetUserId = userId;
            break;
          }
        }

        if (!targetUserId) {
          return res.status(404).json({
            success: false,
            error: 'الرسالة غير موجودة'
          });
        }

        const userMessages = loadUserMessages(targetUserId);
        const msgIndex = userMessages.findIndex((m) => {try {return m.id === messageId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (msgIndex !== -1) {
          userMessages[msgIndex].reply = reply.trim();
          userMessages[msgIndex].read = true;
          saveUserMessages(targetUserId, userMessages);
        }

        const adminMsg = {
          id: 'msg_admin_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
          message: `📨 ${reply.trim()}`,
          sender: 'admin',
          timestamp: Date.now(),
          read: false,
          reply: null,
          ip: 'admin'
        };

        const targetMessages = loadUserMessages(targetUserId);
        targetMessages.push(adminMsg);
        saveUserMessages(targetUserId, targetMessages);

        res.json({
          success: true,
          message: 'تم إرسال الرد بنجاح',
          data: { messageId, reply: reply.trim() }
        });
      } catch (error) {
        console.error('❌ خطأ في الرد على الرسالة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 🔹 تحديث حالة القراءة
    app.post('/api/messages/read', (req, res) => {
      try {
        const { messageId } = req.body;
        const userId = getUserId(req);

        if (!messageId) {
          return res.status(400).json({
            success: false,
            error: 'معرف الرسالة مطلوب'
          });
        }

        const messages = loadUserMessages(userId);
        const msgIndex = messages.findIndex((m) => {try {return m.id === messageId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (msgIndex === -1) {
          return res.status(404).json({
            success: false,
            error: 'الرسالة غير موجودة'
          });
        }

        messages[msgIndex].read = true;
        saveUserMessages(userId, messages);

        res.json({
          success: true,
          message: 'تم تحديث حالة القراءة'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 🔹 حذف رسالة
    app.delete('/api/messages/delete/:id', (req, res) => {
      try {
        const id = req.params.id;
        const userId = getUserId(req);

        const messages = loadUserMessages(userId);
        const filtered = messages.filter((m) => {try {return m.id !== id;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        if (filtered.length === messages.length) {
          return res.status(404).json({
            success: false,
            error: 'الرسالة غير موجودة'
          });
        }

        saveUserMessages(userId, filtered);

        res.json({
          success: true,
          message: 'تم حذف الرسالة'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 🔹 جلب جميع الرسائل من جميع المستخدمين (للوحة التحكم فقط)
    app.get('/api/messages/all-users', (req, res) => {
      try {
        const all = loadAllMessages();
        const stats = getMessagesStats();

        const usersData = {};
        for (const [userId, messages] of Object.entries(all)) {
          usersData[userId] = {
            messages: messages,
            count: messages.length,
            unread: messages.filter((m) => {try {return !m.read && m.sender === 'user';} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}).length,
            lastMessage: messages.length > 0 ? messages[messages.length - 1] : null,
            firstMessage: messages.length > 0 ? messages[0] : null
          };
        }

        res.json({
          success: true,
          users: stats.users,
          stats: stats,
          usersData: usersData,
          allMessages: all
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 🔹 إرسال رسالة من الإدارة إلى مستخدم معين
    app.post('/api/messages/admin-send', (req, res) => {
      try {
        const { userId, message } = req.body;

        if (!userId || !message || message.trim() === '') {
          return res.status(400).json({
            success: false,
            error: 'معرف المستخدم والرسالة مطلوبان'
          });
        }

        const adminMsg = {
          id: 'msg_admin_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
          message: `📨 ${message.trim()}`,
          sender: 'admin',
          timestamp: Date.now(),
          read: false,
          reply: null,
          ip: 'admin'
        };

        const userMessages = loadUserMessages(userId);
        userMessages.push(adminMsg);
        saveUserMessages(userId, userMessages);

        res.json({
          success: true,
          message: 'تم إرسال الرسالة إلى المستخدم',
          data: adminMsg,
          userId: userId
        });
      } catch (error) {
        console.error('❌ خطأ في إرسال رسالة إدارة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 🔹 حذف جميع رسائل مستخدم معين
    app.delete('/api/messages/clear-user/:userId', (req, res) => {
      try {
        const userId = req.params.userId;
        const all = loadAllMessages();

        if (!all[userId]) {
          return res.status(404).json({
            success: false,
            error: 'المستخدم غير موجود'
          });
        }

        delete all[userId];
        fs.writeFileSync(MESSAGES_FILE, JSON.stringify(all, null, 2), 'utf8');

        res.json({
          success: true,
          message: 'تم حذف جميع رسائل المستخدم'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== 22. مسارات الإعدادات =====
    // ============================================

    app.post('/api/settings/port', (req, res) => {
      try {
        const { port } = req.body;
        const newPort = parseInt(port);

        if (isNaN(newPort) || newPort < 1 || newPort > 65535) {
          return res.status(400).json({
            success: false,
            error: 'منفذ غير صالح (1-65535)'
          });
        }

        if (savePortToConfig(newPort)) {
          res.json({
            success: true,
            message: `✅ تم تغيير المنفذ إلى ${newPort}`,
            port: newPort
          });
        } else {
          res.status(500).json({
            success: false,
            error: 'فشل حفظ الإعدادات'
          });
        }
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/settings/port', (req, res) => {
      try {
        const port = getPortFromConfig();
        res.json({
          success: true,
          port: port
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // ============================================
    // ===== 23. مسار البحث عن صورة الغلاف =====
    // ============================================

    app.get('/api/find-cover', async (req, res) => {
      try {
        const { folder, categoryId, driveIndex } = req.query;

        if (!folder || !categoryId) {
          return res.status(400).json({ error: 'المسار والقسم مطلوبان' });
        }

        const category = config.categories.find((c) => {try {return c.id === categoryId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (!category || !category.paths || !category.paths[driveIndex]) {
          return res.status(404).json({ error: 'القسم غير موجود' });
        }

        const drive = category.paths[driveIndex];
        const fullPath = path.join(drive.path, folder);

        if (!fs.existsSync(fullPath)) {
          return res.status(404).json({ error: 'المجلد غير موجود' });
        }

        const coverNames = ['cover', 'Cover', 'folder', 'Folder', 'album', 'Album', 'artwork', 'Artwork', 'front', 'Front', 'poster', 'Poster'];
        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];

        const files = fs.readdirSync(fullPath);

        for (const coverName of coverNames) {
          for (const ext of imageExtensions) {
            const testPath = path.join(fullPath, coverName + ext);
            if (fs.existsSync(testPath)) {
              const mimeType = mime.lookup(testPath) || 'image/jpeg';
              res.setHeader('Content-Type', mimeType);
              res.setHeader('Cache-Control', 'public, max-age=86400');
              res.setHeader('Access-Control-Allow-Origin', '*');
              return fs.createReadStream(testPath).pipe(res);
            }
          }
        }

        for (const file of files) {
          const ext = path.extname(file).toLowerCase();
          if (imageExtensions.includes(ext)) {
            const testPath = path.join(fullPath, file);
            const mimeType = mime.lookup(testPath) || 'image/jpeg';
            res.setHeader('Content-Type', mimeType);
            res.setHeader('Cache-Control', 'public, max-age=86400');
            res.setHeader('Access-Control-Allow-Origin', '*');
            return fs.createReadStream(testPath).pipe(res);
          }
        }

        const subFolders = ['covers', 'artwork', 'images', 'photos'];
        for (const sub of subFolders) {
          const subPath = path.join(fullPath, sub);
          if (fs.existsSync(subPath) && fs.statSync(subPath).isDirectory()) {
            const subFiles = fs.readdirSync(subPath);
            for (const file of subFiles) {
              const ext = path.extname(file).toLowerCase();
              if (imageExtensions.includes(ext)) {
                const testPath = path.join(subPath, file);
                const mimeType = mime.lookup(testPath) || 'image/jpeg';
                res.setHeader('Content-Type', mimeType);
                res.setHeader('Cache-Control', 'public, max-age=86400');
                res.setHeader('Access-Control-Allow-Origin', '*');
                return fs.createReadStream(testPath).pipe(res);
              }
            }
          }
        }

        res.status(404).json({ error: 'لا توجد صورة غلاف' });

      } catch (error) {
        console.error('Error finding cover:', error);
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== 24. مسارات المزامنة =====
    // ============================================

    app.post('/api/sync/start', async (req, res) => {
      try {
        if (!licenseValid || serverLocked) {
          return res.status(403).json({
            success: false,
            error: 'الترخيص غير صالح أو السيرفر مقفل'
          });
        }

        if (syncInProgress) {
          return res.status(409).json({
            success: false,
            error: 'جاري المزامنة بالفعل، انتظر حتى الانتهاء'
          });
        }

        syncInProgress = true;
        syncProgress = 0;
        syncStatus = 'جاري المزامنة...';

        const cache = await syncAllCategories();

        syncInProgress = false;
        syncProgress = 100;
        syncStatus = 'مكتمل';

        res.json({
          success: true,
          message: 'تمت المزامنة بنجاح',
          data: {
            lastSync: cache.lastSync,
            totalFiles: cache.totalFiles,
            totalPosters: cache.totalPosters || 0,
            categoriesCount: cache.categoriesCount,
            foldersScanned: cache.foldersScanned || 0,
            categoriesWithFiles: cache.categoriesWithFiles || 0,
            categories: Object.keys(cache.categories)
          }
        });
      } catch (error) {
        console.error('❌ خطأ في المزامنة:', error);
        syncInProgress = false;
        syncStatus = 'فشل';
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/sync/status', (req, res) => {
      try {
        const cache = loadSyncCache();
        const hasCache = cache && cache.lastSync && Object.keys(cache.categories || {}).length > 0;

        res.json({
          success: true,
          hasCache: hasCache,
          inProgress: syncInProgress,
          progress: syncProgress,
          status: syncStatus,
          lastSync: cache.lastSync || null,
          totalFiles: cache.totalFiles || 0,
          totalPosters: cache.totalPosters || 0,
          categoriesCount: cache.categoriesCount || 0,
          foldersScanned: cache.foldersScanned || 0,
          categoriesWithFiles: cache.categoriesWithFiles || 0,
          categories: Object.keys(cache.categories || {})
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/sync/cache', (req, res) => {
      try {
        const cache = loadSyncCache();
        res.json({
          success: true,
          cache: cache
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.delete('/api/sync/cache', (req, res) => {
      try {
        if (fs.existsSync(SYNC_CACHE_FILE)) {
          fs.unlinkSync(SYNC_CACHE_FILE);
        }
        res.json({
          success: true,
          message: 'تم حذف كاش المزامنة'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/sync/test-path', (req, res) => {
      try {
        const { path: testPath } = req.query;

        if (!testPath) {
          return res.json({ error: 'الرجاء إدخال مسار للاختبار' });
        }

        const decodedPath = decodeURIComponent(testPath);

        if (!fs.existsSync(decodedPath)) {
          return res.json({
            exists: false,
            path: decodedPath,
            error: 'المسار غير موجود'
          });
        }

        const stat = fs.statSync(decodedPath);
        if (!stat.isDirectory()) {
          return res.json({
            exists: true,
            isDirectory: false,
            path: decodedPath,
            size: stat.size,
            modified: stat.mtime
          });
        }

        const files = scanDirectoryForVideos(decodedPath, 'test', 0, decodedPath, 0, 3);

        res.json({
          success: true,
          path: decodedPath,
          exists: true,
          isDirectory: true,
          totalVideos: files.length,
          videos: files.slice(0, 20).map((f) => {try {return {
                name: f.name,
                path: f.path,
                size: f.size,
                modified: f.modified,
                hasPoster: !!f.posterPath,
                posterPath: f.posterPath
              };} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}})
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // ============================================
    // ===== مسار البوستر من الكاش (محسّن) =====
    // ============================================

    // ============================================
    // ===== مسار البوستر من الكاش (محسّن بالكامل) =====
    // ============================================

    app.get('/api/poster-cache', (req, res) => {
      try {
        const filePath = req.query.path || '';
        const categoryId = req.query.categoryId || '';

        if (!filePath || !categoryId) {
          console.warn('⚠️ poster-cache: الملف أو القسم غير موجود');
          return res.status(404).json({ error: 'المسار والقسم مطلوبان' });
        }

        let decodedPath = decodeURIComponent(filePath);
        decodedPath = decodedPath.replace(/\\/g, '/');

        ////console.log(`🔍 poster-cache: البحث عن صورة لـ ${decodedPath}`);

        let posterPath = null;

        // ✅ محاولة 1: البحث في الكاش
        try {
          const cache = loadSyncCache();
          if (cache && cache.categories) {
            for (const [catId, catData] of Object.entries(cache.categories)) {
              if (catId !== categoryId) continue;
              if (!catData.files) continue;

              for (const f of catData.files) {
                const fPath = (f.path || f.fullPath || '').replace(/\\/g, '/');
                // مقارنة مرنة للمسار
                if (fPath === decodedPath ||
                fPath.endsWith(decodedPath) ||
                decodedPath.endsWith(fPath) ||
                fPath.includes(decodedPath.split('/').pop())) {
                  if (f.posterPath && fs.existsSync(f.posterPath)) {
                    posterPath = f.posterPath;
                    ////console.log(`✅ poster-cache: تم العثور على صورة في الكاش: ${posterPath}`);
                    break;
                  }
                }
              }
              if (posterPath) break;
            }
          }
        } catch (e) {
          console.warn('⚠️ خطأ في قراءة الكاش:', e.message);
        }

        // ✅ محاولة 2: البحث المباشر في المجلد
        if (!posterPath) {
          ////console.log('🔍 poster-cache: البحث المباشر في المجلد...');

          // البحث عن المسار الفعلي للملف
          let fullPath = null;
          let foundDrive = null;

          // البحث في جميع الأقسام
          for (const cat of config.categories) {
            if (!cat.paths) continue;
            for (const drive of cat.paths) {
              // محاولة مسارات مختلفة
              const possiblePaths = [
              path.join(drive.path, decodedPath),
              path.join(drive.path, path.basename(decodedPath)),
              decodedPath];


              for (const testPath of possiblePaths) {
                try {
                  if (fs.existsSync(testPath)) {
                    fullPath = testPath;
                    foundDrive = drive;
                    ////console.log(`✅ poster-cache: تم العثور على الملف: ${fullPath}`);
                    break;
                  }
                } catch (e) {}
              }
              if (fullPath) break;
            }
            if (fullPath) break;
          }

          if (fullPath) {
            // البحث عن صورة في نفس المجلد
            const dirPath = path.dirname(fullPath);
            const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg', '.tiff', '.ico', '.cur'];

            // 1. صورة بنفس اسم الملف
            const fileName = path.basename(fullPath, path.extname(fullPath));
            for (const ext of imageExtensions) {
              const testPath = path.join(dirPath, fileName + ext);
              try {
                if (fs.existsSync(testPath)) {
                  posterPath = testPath;
                  ////console.log(`✅ poster-cache: تم العثور على صورة بنفس الاسم: ${posterPath}`);
                  break;
                }
              } catch (e) {}
            }

            // 2. صور بأسماء شائعة
            if (!posterPath) {
              const commonNames = ['poster', 'cover', 'folder', 'album', 'artwork', 'thumb', '1', '01', 'image', 'img'];
              for (const name of commonNames) {
                for (const ext of imageExtensions) {
                  const testPath = path.join(dirPath, name + ext);
                  try {
                    if (fs.existsSync(testPath)) {
                      posterPath = testPath;
                      ////console.log(`✅ poster-cache: تم العثور على صورة باسم ${name}: ${posterPath}`);
                      break;
                    }
                  } catch (e) {}
                }
                if (posterPath) break;
              }
            }

            // 3. أي صورة في المجلد
            if (!posterPath) {
              try {
                const files = fs.readdirSync(dirPath);
                for (const file of files) {
                  const ext = path.extname(file).toLowerCase();
                  if (imageExtensions.includes(ext)) {
                    posterPath = path.join(dirPath, file);
                    ////console.log(`✅ poster-cache: تم العثور على صورة عشوائية: ${posterPath}`);
                    break;
                  }
                }
              } catch (e) {}
            }

            // 4. البحث في المجلدات الفرعية
            if (!posterPath) {
              const subFolders = ['images', 'covers', 'artwork', 'posters', 'photos', 'thumbnails', 'icons', 'assets'];
              for (const sub of subFolders) {
                const subPath = path.join(dirPath, sub);
                try {
                  if (fs.existsSync(subPath) && fs.statSync(subPath).isDirectory()) {
                    const files = fs.readdirSync(subPath);
                    for (const file of files) {
                      const ext = path.extname(file).toLowerCase();
                      if (imageExtensions.includes(ext)) {
                        posterPath = path.join(subPath, file);
                        ////console.log(`✅ poster-cache: تم العثور على صورة في مجلد فرعي: ${posterPath}`);
                        break;
                      }
                    }
                  }
                } catch (e) {}
                if (posterPath) break;
              }
            }
          }
        }

        // ✅ إذا تم العثور على صورة، أرسلها
        if (posterPath && fs.existsSync(posterPath)) {
          const mimeType = mime.lookup(posterPath) || 'image/jpeg';
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Cache-Control', 'public, max-age=86400');
          res.setHeader('Access-Control-Allow-Origin', '*');
          return fs.createReadStream(posterPath).pipe(res);
        }

        // ❌ إذا لم يتم العثور على صورة، جرب استخدام poster-enhanced كبديل
        ////console.log(`🔄 poster-cache: لم يتم العثور على صورة، محاولة poster-enhanced...`);
        const encodedPath = encodeURIComponent(decodedPath);
        const posterEnhancedUrl = `/api/poster-enhanced?path=${encodedPath}&categoryId=${categoryId}`;

        // إعادة توجيه إلى poster-enhanced
        return res.redirect(posterEnhancedUrl);

      } catch (error) {
        console.error('❌ خطأ في poster-cache:', error);
        // ✅ في حالة الخطأ، حاول استخدام poster-enhanced
        try {
          const filePath = req.query.path || '';
          const categoryId = req.query.categoryId || '';
          const encodedPath = encodeURIComponent(decodeURIComponent(filePath));
          return res.redirect(`/api/poster-enhanced?path=${encodedPath}&categoryId=${categoryId}`);
        } catch (e) {
          res.status(404).json({ error: error.message });
        }
      }
    });
    // ============================================
    // ===== 26. مسارات إضافية =====
    // ============================================

    app.get('/api/auth/check', (req, res) => {try {
        res.json({
          success: true,
          message: 'مستخدم مصادق',
          user: 'admin'
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    app.get('/api/setup-default-user', (req, res) => {
      try {
        const defaultUser = {
          id: 'admin',
          username: 'admin',
          password: 'admin123',
          role: 'admin',
          created: Date.now(),
          lastLogin: null
        };

        res.json({
          success: true,
          message: 'تم إنشاء المستخدم الافتراضي',
          user: defaultUser
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/files', async (req, res) => {
      try {
        const requestedPath = req.query.path || '';
        const fullPath = path.join(BASE_DIR, requestedPath);

        const files = await fs.promises.readdir(fullPath);

        const result = files.map((file) => {
          try {
            const itemPath = path.join(fullPath, file);
            const stats = fs.statSync(itemPath);

            return {
              name: file,
              isFolder: stats.isDirectory(),
              size: stats.size,
              updatedAt: stats.mtime
            };
          } catch (e) {
            return null;
          }
        }).filter((item) => {try {return item !== null;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});

        res.json({
          success: true,
          path: fullPath,
          items: result,
          isRoot: fullPath === BASE_DIR
        });

      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    app.get('/api/video/:filename', (req, res) => {try {
        const filePath = path.join('/storage/videos/', req.params.filename);
        const stat = fs.statSync(filePath);
        const fileSize = stat.size;

        const range = req.headers.range;
        if (range) {
          const parts = range.replace(/bytes=/, "").split("-");
          const start = parseInt(parts[0], 10);
          const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
          const chunksize = end - start + 1;

          const file = createReadStream(filePath, { start, end });
          res.writeHead(206, {
            'Content-Range': `bytes ${start}-${end}/${fileSize}`,
            'Content-Length': chunksize,
            'Content-Type': 'video/mp4'
          });
          file.pipe(res);
        } else {
          res.writeHead(200, {
            'Content-Length': fileSize,
            'Content-Type': 'video/mp4'
          });
          createReadStream(filePath).pipe(res);
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // ============================================
    // ===== مسار الصفحة الرئيسية =====
    // ============================================

    app.get('/', (req, res) => {try {
        // ✅ إذا كان الترخيص غير صالح، نعرض license-expired.html بدلاً من splash.html
        if (!licenseValid || serverLocked) {
          const expiredPage = path.join(PUBLIC_DIR, 'license-expired.html');
          if (fs.existsSync(expiredPage)) {
            return res.sendFile(expiredPage);
          } else {
            createLicenseExpiredPage('الترخيص غير صالح');
            return res.sendFile(path.join(PUBLIC_DIR, 'license-expired.html'));
          }
        }

        // ✅ إذا كان الترخيص صالحاً، نعرض splash.html
        const splashPath = path.join(PUBLIC_DIR, 'splash.html');
        if (fs.existsSync(splashPath)) {
          res.sendFile(splashPath);
        } else {
          res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // ============================================
    // ===== مسار الصفحة الرئيسية المباشر (للتجاوز) =====
    // ============================================

    app.get('/main', (req, res) => {try {
        res.sendFile(path.join(PUBLIC_DIR, 'index.html'));} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });


    // ============================================
    // ===== 28. مسار الرجوع (Fallback) =====
    // ============================================

    app.get('*', (req, res, next) => {try {
        // تجاهل طلبات API
        if (req.path.startsWith('/api/')) return next();
        // تجاهل الملفات الثابتة
        if (req.path.match(/\.(js|css|png|jpg|jpeg|gif|svg|ico|webp|woff|woff2|ttf|eot|mp4|webm|json|xml)$/)) return next();

        const isRoute = req.path.startsWith('/category/') ||
        req.path.startsWith('/folder/') ||
        req.path.startsWith('/main') ||
        req.path === '/';

        if (isRoute || req.path === '/') {
          //////console.log(`🔄 Fallback: ${req.path} → index.html`);
          res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
        } else {
          next();
        }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });
    // ============================================
    // ===== 30. مسارات استخراج بيانات المحتوى (MetaData) - الإصدار النهائي =====
    // ============================================

    // 30.1 جلب كاش الميتاداتا بالكامل
    app.get('/api/metadata/cache', (req, res) => {
      try {
        const cache = loadMetadataCache();
        res.json({
          success: true,
          cache: cache,
          count: Object.keys(cache).length
        });
      } catch (error) {
        console.error('❌ خطأ في جلب كاش الميتاداتا:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 30.2 جلب بيانات مجلد محدد (مع البحث المتقدم)
    app.get('/api/metadata/folder', (req, res) => {
      try {
        const folderPath = req.query.path;
        const categoryId = req.query.categoryId;
        const driveIndex = parseInt(req.query.driveIndex) || 0;

        // ✅ التحقق من وجود المسار
        if (!folderPath || folderPath.trim() === '') {
          return res.status(400).json({
            success: false,
            error: 'المسار مطلوب'
          });
        }

        //////console.log(`🔍 البحث عن ميتاداتا للمسار: "${folderPath}"`);

        // قراءة الكاش
        const cache = loadMetadataCache();
        //////console.log(`📂 عدد العناصر في الكاش: ${Object.keys(cache).length}`);

        // تطبيع المسار للبحث
        const normalizedPath = folderPath.replace(/\\/g, '/').trim();
        let foundMetadata = null;
        let foundKey = null;

        // ============================================
        // 1. البحث المطابق التام
        // ============================================
        for (const [key, value] of Object.entries(cache)) {
          const normalizedKey = key.replace(/\\/g, '/').trim();
          if (normalizedKey === normalizedPath) {
            foundMetadata = value;
            foundKey = key;
            break;
          }
          // محاولة مطابقة إذا كان key ينتهي بالمسار
          if (normalizedKey.endsWith('/' + normalizedPath) || normalizedKey.endsWith('\\' + normalizedPath)) {
            foundMetadata = value;
            foundKey = key;
            break;
          }
        }

        // ============================================
        // 2. البحث عن تطابق جزئي (اسم المجلد)
        // ============================================
        if (!foundMetadata) {
          const folderName = normalizedPath.split('/').pop();
          //////console.log(`🔍 البحث باسم المجلد: "${folderName}"`);

          for (const [key, value] of Object.entries(cache)) {
            // مطابقة اسم المجلد
            if (value.folderName === folderName) {
              foundMetadata = value;
              foundKey = key;
              break;
            }
            // مطابقة في المسار
            const normalizedKey = key.replace(/\\/g, '/').trim();
            if (normalizedKey.includes('/' + folderName) || normalizedKey.includes('\\' + folderName)) {
              foundMetadata = value;
              foundKey = key;
              break;
            }
            // مطابقة في العنوان
            if (value.title && value.title.toLowerCase().includes(folderName.toLowerCase())) {
              foundMetadata = value;
              foundKey = key;
              break;
            }
          }
        }

        // ============================================
        // 3. البحث باستخدام categoryId
        // ============================================
        if (!foundMetadata && categoryId) {
          //////console.log(`🔍 البحث باستخدام categoryId: "${categoryId}"`);

          // البحث عن المسار الفعلي للقسم
          let drivePath = null;
          if (config.categories) {
            for (const cat of config.categories) {
              if (cat.id === categoryId && cat.paths && cat.paths[driveIndex]) {
                drivePath = cat.paths[driveIndex].path.replace(/\\/g, '/');
                break;
              }
            }
          }

          if (drivePath) {
            // محاولة بناء المسار الكامل
            const fullPath = drivePath + '/' + normalizedPath;
            //////console.log(`🔍 المسار الكامل المحتمل: "${fullPath}"`);

            for (const [key, value] of Object.entries(cache)) {
              const normalizedKey = key.replace(/\\/g, '/').trim();
              if (normalizedKey === fullPath || normalizedKey.endsWith('/' + normalizedPath)) {
                foundMetadata = value;
                foundKey = key;
                break;
              }
            }
          }
        }

        // ============================================
        // 4. البحث باستخدام أي تطابق في المحتوى
        // ============================================
        if (!foundMetadata) {
          const searchTerms = normalizedPath.split('/').filter((s) => {try {return s.length > 0;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
          for (const term of searchTerms) {
            if (term.length < 2) continue;
            for (const [key, value] of Object.entries(cache)) {
              const normalizedKey = key.replace(/\\/g, '/').trim();
              if (normalizedKey.includes(term) || value.folderName && value.folderName.includes(term)) {
                foundMetadata = value;
                foundKey = key;
                break;
              }
            }
            if (foundMetadata) break;
          }
        }

        if (foundMetadata) {
          //////console.log(`✅ تم العثور على ميتاداتا للمجلد: "${foundKey}"`);
          res.json({
            success: true,
            hasMetadata: true,
            metadata: foundMetadata,
            matchedKey: foundKey
          });
        } else {
          //////console.log(`ℹ️ لا توجد ميتاداتا للمجلد: "${folderPath}"`);
          res.json({
            success: true,
            hasMetadata: false,
            searchedPath: normalizedPath,
            cacheKeys: Object.keys(cache).slice(0, 10)
          });
        }
      } catch (error) {
        console.error('❌ خطأ في جلب الميتاداتا:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 30.3 تحديث بيانات مجلد (POST)
    app.post('/api/metadata/folder', (req, res) => {
      try {
        const { folderPath, metadata } = req.body;

        if (!folderPath || !metadata) {
          return res.status(400).json({
            success: false,
            error: 'المسار والبيانات مطلوبة'
          });
        }

        const cache = loadMetadataCache();
        const key = folderPath.replace(/\\/g, '/');

        cache[key] = {
          ...metadata,
          path: folderPath,
          folderName: folderPath.split('/').pop().split('\\').pop(),
          fetchedAt: Date.now()
        };

        saveMetadataCache(cache);

        res.json({
          success: true,
          message: 'تم تحديث الميتاداتا بنجاح'
        });
      } catch (error) {
        console.error('❌ خطأ في تحديث الميتاداتا:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 30.4 حذف بيانات مجلد (DELETE)
    app.delete('/api/metadata/folder', (req, res) => {
      try {
        const { folderPath } = req.body;

        if (!folderPath) {
          return res.status(400).json({
            success: false,
            error: 'المسار مطلوب'
          });
        }

        const cache = loadMetadataCache();
        const key = folderPath.replace(/\\/g, '/');
        delete cache[key];
        saveMetadataCache(cache);

        res.json({
          success: true,
          message: 'تم حذف الميتاداتا بنجاح'
        });
      } catch (error) {
        console.error('❌ خطأ في حذف الميتاداتا:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 30.5 بدء مزامنة البيانات (POST)
    app.post('/api/metadata/sync', async (req, res) => {
      try {
        const { pathId } = req.query || {};

        //////console.log('📥 طلب مزامنة البيانات - pathId:', pathId);

        if (!pathId) {
          return res.status(400).json({
            success: false,
            error: 'معرف المسار مطلوب'
          });
        }

        if (metadataSyncInProgress) {
          return res.status(409).json({
            success: false,
            error: 'جاري المزامنة بالفعل'
          });
        }

        if (!metadataEnabled) {
          return res.status(400).json({
            success: false,
            error: 'جلب البيانات غير مفعل'
          });
        }

        // التحقق من وجود المسار
        let pathExists = false;
        for (const cat of config.categories) {
          if (!cat.paths) continue;
          for (const p of cat.paths) {
            if (p.id === pathId) {
              pathExists = true;
              break;
            }
          }
          if (pathExists) break;
        }

        if (!pathExists) {
          return res.status(404).json({
            success: false,
            error: 'المسار غير موجود'
          });
        }

        // بدء المزامنة في الخلفية
        syncMetadataForPath(pathId);

        res.json({
          success: true,
          message: 'تم بدء المزامنة'
        });
      } catch (error) {
        console.error('❌ خطأ في بدء المزامنة:', error);
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // 30.6 جلب حالة المزامنة (GET)
    app.get('/api/metadata/status', (req, res) => {try {
        const cache = loadMetadataCache();
        const totalFolders = Object.keys(cache).length;
        const validEntries = Object.values(cache).filter((m) => {try {return !m.isFallback;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}).length;

        res.json({
          success: true,
          enabled: metadataEnabled,
          inProgress: metadataSyncInProgress,
          progress: metadataSyncProgress,
          current: metadataSyncCurrent,
          total: metadataSyncTotal,
          currentFolder: metadataSyncCurrentFolder,
          log: metadataSyncLog.slice(-50),
          cacheSize: totalFolders,
          validEntries: validEntries,
          cachedFolders: Object.keys(cache).slice(0, 20)
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // 30.7 جلب جميع البيانات (GET)
    app.get('/api/metadata/all', (req, res) => {try {
        const cache = loadMetadataCache();
        res.json({
          success: true,
          data: cache,
          count: Object.keys(cache).length
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    // 30.8 مسح الكاش (DELETE)
    app.delete('/api/metadata/cache', (req, res) => {
      try {
        if (fs.existsSync(METADATA_CACHE_FILE)) {
          fs.unlinkSync(METADATA_CACHE_FILE);
        }
        res.json({
          success: true,
          message: 'تم مسح كاش البيانات'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });
// خدمة player.html كملف ثابت
app.get('/player.html', (req, res) => {
    const playerPath = path.join(PUBLIC_DIR, 'player.html');
    if (fs.existsSync(playerPath)) {
        res.sendFile(playerPath);
    } else {
        res.status(404).send('player.html غير موجود');
    }
});
    //////console.log('✅ تم تحميل مسارات الميتاداتا بنجاح');
    // ============================================
    // ===== 29. 404 =====
    // ============================================
app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    // أضف .html إلى القائمة
    if (req.path.match(/\.(js|css|png|jpg|jpeg|gif|svg|ico|webp|woff|woff2|ttf|eot|mp4|webm|json|xml|html)$/)) return next();
    // ... باقي الكود
});
    app.use((req, res) => {try {
        res.status(404).json({
          success: false,
          error: 'المسار غير موجود'
        });} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
    });

    //////console.log('✅ تم إعداد جميع المسارات');
  } catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}}
// ============================================
// ===== 31. نظام كاش صور المجلدات =====
// ============================================



// دالة البحث عن أول صورة في مجلد (تشمل المخفية و .ico)
function findFirstImageInFolderIncludingHidden(folderPath) {
  try {
    if (!folderPath || !fs.existsSync(folderPath)) return null;
    const stat = fs.statSync(folderPath);
    if (!stat.isDirectory()) return null;

    const imageExtensions = [
    '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp',
    '.svg', '.tiff', '.ico', '.cur', '.heic', '.heif', '.avif'];


    const files = fs.readdirSync(folderPath, { withFileTypes: true });
    for (const entry of files) {
      if (entry.isFile()) {
        const ext = path.extname(entry.name).toLowerCase();
        if (imageExtensions.includes(ext)) {
          return path.join(folderPath, entry.name);
        }
      }
    }
    return null;
  } catch (error) {
    return null;
  }
}

// مسح مجلد وجمع جميع المجلدات الفرعية مع صورها (عمق حتى 10)
function scanFoldersRecursively(dir, depth = 0, maxDepth = 10, results = {}) {
  if (depth > maxDepth) return results;
  try {
    if (!fs.existsSync(dir)) return results;
    const stat = fs.statSync(dir);
    if (!stat.isDirectory()) return results;

    const posterPath = findFirstImageInFolderIncludingHidden(dir);
    const normalizedDir = dir.replace(/\\/g, '/');
    results[normalizedDir] = posterPath ? posterPath.replace(/\\/g, '/') : null;

    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.isDirectory()) {
        const subDir = path.join(dir, entry.name);
        scanFoldersRecursively(subDir, depth + 1, maxDepth, results);
      }
    }
  } catch (error) {/* تجاهل الأخطاء */}
  return results;
}

// توليد كاش صور جميع المجلدات من جميع المسارات المسجلة
// توليد كاش صور جميع المجلدات من جميع المسارات المسجلة (مع حذف البيانات القديمة)
function generateFolderImagesCache() {
  ////console.log('🔄 جاري توليد كاش صور المجلدات...');
  const startTime = Date.now();
  
  // ✅ حذف الكاش القديم بالكامل
  const oldCacheCount = Object.keys(folderImagesCache || {}).length;
  ////console.log(`🗑️ حذف ${oldCacheCount} مجلد من الكاش القديم...`);
  
  // ✅ إنشاء كائن جديد فارغ
  const allFolders = {};
  
  // ✅ إعادة تعيين الفهرس
  folderImagesIndex = new Map();
  folderImagesCache = {};
  
  // ✅ مسح جميع المجلدات من جديد
  if (config.categories) {
    for (const category of config.categories) {
      if (!category.paths) continue;
      for (const drive of category.paths) {
        const rootPath = drive.path;
        if (fs.existsSync(rootPath)) {
          scanFoldersRecursively(rootPath, 0, 10, allFolders);
        }
      }
    }
  }

  try {
    // ✅ كتابة البيانات الجديدة فقط (استبدال كامل)
    const data = JSON.stringify(allFolders, null, 2);
    fs.writeFileSync(FOLDER_IMAGES_CACHE_FILE, data, 'utf8');
    
    // ✅ تحديث المتغيرات العالمية
    folderImagesCache = allFolders;
    folderImagesCacheLoaded = true;
    folderImagesCacheTimestamp = Date.now();
    
    // ✅ إعادة بناء الفهرس
    for (const [fullPath, imagePath] of Object.entries(allFolders)) {
      const folderName = path.basename(fullPath);
      if (!folderImagesIndex.has(folderName)) {
        folderImagesIndex.set(folderName, fullPath);
      }
    }
    
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    ////console.log(`✅ تم توليد كاش صور المجلدات (${Object.keys(allFolders).length} مجلد) في ${elapsed} ثانية`);
    ////console.log(`🗑️ تم حذف ${oldCacheCount} مجلد قديم واستبدالهم بـ ${Object.keys(allFolders).length} مجلد جديد`);
    
    return { 
      success: true, 
      count: Object.keys(allFolders).length,
      deleted: oldCacheCount,
      added: Object.keys(allFolders).length
    };
  } catch (error) {
    console.error('❌ فشل حفظ كاش صور المجلدات:', error);
    return { success: false, error: error.message };
  }
}

function loadFolderImagesCacheWithIndex() {
  try {
    if (!fs.existsSync(FOLDER_IMAGES_CACHE_FILE)) {
      // الكاش غير موجود، نبدأ توليداً في الخلفية
      //console.log('⚠️ كاش صور المجلدات غير موجود، سيتم توليده في الخلفية...');
      // نستخدم setImmediate أو setTimeout لتجنب حظر بدء التشغيل
      setImmediate(() => {try {
          //console.log('🔄 بدء توليد كاش صور المجلدات في الخلفية...');
          const result = generateFolderImagesCache();
          if (result.success) {

            //console.log(`✅ تم توليد كاش الصور (${result.count} مجلد)`);
          } else {console.error('❌ فشل توليد الكاش:', result.error);
          }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
      });
      // نعيد كاشاً فارغاً حالياً، وسيتم تحديثه لاحقاً
      folderImagesCache = {};
      folderImagesIndex = new Map();
      folderImagesCacheLoaded = true;
      folderImagesCacheTimestamp = Date.now();
      return {};
    }

    const data = fs.readFileSync(FOLDER_IMAGES_CACHE_FILE, 'utf8');
    const cache = JSON.parse(data);

    // بناء الفهرس
    const index = new Map();
    for (const [fullPath, imagePath] of Object.entries(cache)) {
      const folderName = path.basename(fullPath);
      if (!index.has(folderName)) {
        index.set(folderName, fullPath);
      }
    }

    folderImagesCache = cache;
    folderImagesIndex = index;
    folderImagesCacheLoaded = true;
    folderImagesCacheTimestamp = Date.now();

    // بعد تحميل الكاش، إذا كان فارغاً (ولكنه موجود)، نبدأ توليداً في الخلفية أيضاً
    if (Object.keys(cache).length === 0) {
      //console.log('⚠️ كاش صور المجلدات فارغ، سيتم التوليد في الخلفية...');
      setImmediate(() => {try {
          //console.log('🔄 بدء توليد كاش صور المجلدات (فارغ) في الخلفية...');
          const result = generateFolderImagesCache();
          if (result.success) {

            //console.log(`✅ تم توليد كاش الصور (${result.count} مجلد)`);
          } else {console.error('❌ فشل توليد الكاش:', result.error);
          }} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
      });
    }

    return cache;
  } catch (error) {
    console.error('❌ خطأ في تحميل كاش صور المجلدات:', error);
    return {};
  }
}

// الحصول على صورة مجلد من الكاش (بحث سريع O(1))
function getFolderImageFromCacheFast(folderPath, categoryId = null, driveIndex = null) {try {
    // إعادة تحميل الكاش إذا انتهت صلاحيته
    if (!folderImagesCacheLoaded || Date.now() - folderImagesCacheTimestamp > FOLDER_CACHE_TTL) {
      loadFolderImagesCacheWithIndex();
    }

    if (!folderPath) return null;

    const normalized = folderPath.replace(/\\/g, '/').trim();
    const folderName = normalized.split('/').pop();

    // 1. بحث مباشر (O(1))
    if (folderImagesCache[normalized]) {
      return folderImagesCache[normalized];
    }

    // 2. بحث باسم المجلد (O(1) باستخدام Map)
    if (folderName && folderImagesIndex.has(folderName)) {
      const fullPath = folderImagesIndex.get(folderName);
      // التحقق من أن المسار متطابق (أو أن اسم المجلد كافٍ)
      if (fullPath && folderImagesCache[fullPath]) {
        return folderImagesCache[fullPath];
      }
    }

    // 3. محاولة مطابقة نهاية المسار (تجاوز سريع)
    for (const [fullPath, imagePath] of Object.entries(folderImagesCache)) {
      if (fullPath.endsWith('/' + normalized) || fullPath.endsWith('\\' + normalized)) {
        return imagePath;
      }
    }

    // 4. إذا توفر categoryId و driveIndex، نحاول بناء المسار الكامل
    if (categoryId && driveIndex !== null && driveIndex !== undefined) {
      try {
        const category = config.categories.find((c) => {try {return c.id === categoryId;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}});
        if (category && category.paths && category.paths[driveIndex]) {
          const drivePath = category.paths[driveIndex].path.replace(/\\/g, '/');
          const fullPath = (drivePath + '/' + normalized).replace(/\/+/g, '/');
          if (folderImagesCache[fullPath]) {
            return folderImagesCache[fullPath];
          }
          // محاولة باسم المجلد مرة أخرى مع المسار الكامل
          if (folderName && folderImagesIndex.has(folderName)) {
            const cachedPath = folderImagesIndex.get(folderName);
            if (cachedPath && folderImagesCache[cachedPath]) {
              return folderImagesCache[cachedPath];
            }
          }
        }
      } catch (e) {

        // تجاهل
      }}

    return null;} catch (error) {console.error("❌ خطأ في الدالة:", error);next(error);}
}

// الحصول على صورة مجلد من الكاش
// الحصول على صورة مجلد من الكاش مع دعم المسارات النسبية

//////console.log('✅ تم تحميل server.js بالكامل مع نظام إعادة التحقق عند عودة الإنترنت');